import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

try:
    import numpy as np
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.neural_network import MLPClassifier
    from hmmlearn.hmm import CategoricalHMM
    HAS_ML = True
except ImportError:
    HAS_ML = False
    print("Aviso: Bibliotecas ML não encontradas. O Motor funcionará no modo Estatístico Avançado. Instale com: pip install numpy scikit-learn hmmlearn")

from dados.persistencia import fabrica_historico_regras_zerado, fabrica_padrao_detalhado
from motor.regras import AnalisadorContextoAvancado, MotorContagensProjetivas
from matematica.engine import EngineMatematicoAvancado

class IAPreditivaV1:
    def __init__(self, dados_longo_prazo, dados_recencia=None):
        self.dados_longo = dados_longo_prazo
        self.dados_recencia = dados_recencia if dados_recencia else []
        self.modelo_transicao = defaultdict(list)
        self.modelo_transicao_profundo = defaultdict(list)
        self.modelo_numerico = defaultdict(list)
        self.bigramas_numericos = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0, "prox_numero": defaultdict(int)})
        self.saturacao_ciclica = defaultdict(lambda: {"ciclos_V": [], "ciclos_P": [], "historico_distancias": []})
        self.dna_padroes = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        
        self.padroes_fechamento_numerico = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        
        # Mapeadores Globais (Até G1)
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        
        self.probabilidades_globais = {"streak_v_5": 0.0, "streak_p_5": 0.0, "xadrez_5": 0.0}

        self.unidade_analise = {}
        for n in range(15):
            self.unidade_analise[n] = {
                "ocorrencias": 0, "V": 0, "P": 0, "B": 0,
                "freq_v": 0.0, "freq_p": 0.0, "freq_b": 0.0,
                "estabilidade": "NEUTRO", "saturacao": "NORMAL",
                "enfraquecimento": "ESTÁVEL", "comportamento_dominante": "NEUTRO",
                "pos_numero_V": 0, "pos_numero_P": 0, "pos_numero_B": 0,
                "pos_numero_freq_v": 0.0, "pos_numero_freq_p": 0.0, "pos_numero_freq_b": 0.0,
                "comportamento_pos_numero": "NEUTRO", "retencao_media": 0,
                "ultimas_cores": []
            }
            
        self.xadrez_stats = {"quebras": 0, "continuacoes": 0, "numeros_quebradores": defaultdict(int)}
        self.streak_breaker_stats = {"V": defaultdict(int), "P": defaultdict(int)}
        self.color_ngrams = {1: defaultdict(int), 2: defaultdict(int), 3: defaultdict(int)}
        self.padroes_xadrez_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.padroes_streak_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.padroes_gerais_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.memoria_padroes_vencedores = []
        self.historico_regras = defaultdict(fabrica_historico_regras_zerado)
        self.controladores_fortes = defaultdict(int)
        self.padroes_fortes = []
        self.analise_recencia = {}
        self.regime_recencia = None
        
        self.ml_ready = False
        self.ml_gb = None
        self.ml_mlp = None
        self.ml_hmm = None
        self.q_table = {}
        
        self._treinar_modelo_profundo()

    def __getstate__(self):
        state = self.__dict__.copy()
        if 'modelo_transicao' in state: state['modelo_transicao'] = dict(state['modelo_transicao'])
        if 'modelo_transicao_profundo' in state: state['modelo_transicao_profundo'] = dict(state['modelo_transicao_profundo'])
        if 'modelo_numerico' in state: state['modelo_numerico'] = dict(state['modelo_numerico'])
            
        if 'bigramas_numericos' in state:
            bn_save = {}
            for k, v in state['bigramas_numericos'].items():
                v_copy = v.copy()
                if 'prox_numero' in v_copy:
                    v_copy['prox_numero'] = dict(v_copy['prox_numero'])
                bn_save[k] = v_copy
            state['bigramas_numericos'] = bn_save
            
        if 'saturacao_ciclica' in state: state['saturacao_ciclica'] = {k: dict(v) for k, v in state['saturacao_ciclica'].items()}
        if 'dna_padroes' in state: state['dna_padroes'] = {k: dict(v) for k, v in state['dna_padroes'].items()}
        if 'padroes_fechamento_numerico' in state: state['padroes_fechamento_numerico'] = {k: dict(v) for k, v in state['padroes_fechamento_numerico'].items()}
        
        if 'estatisticas_projecoes_globais' in state: state['estatisticas_projecoes_globais'] = {k: dict(v) for k, v in state['estatisticas_projecoes_globais'].items()}
        if 'estatisticas_bigramas_globais' in state: state['estatisticas_bigramas_globais'] = dict(state['estatisticas_bigramas_globais'])
        if 'estatisticas_trigramas_globais' in state: state['estatisticas_trigramas_globais'] = dict(state['estatisticas_trigramas_globais'])
        
        if 'controladores_fortes' in state: state['controladores_fortes'] = dict(state['controladores_fortes'])
        if 'historico_regras' in state: state['historico_regras'] = dict(state['historico_regras'])
        if 'color_ngrams' in state: state['color_ngrams'] = {k: dict(v) for k, v in state['color_ngrams'].items()}
        
        if 'xadrez_stats' in state and isinstance(state['xadrez_stats'], dict):
            xs = state['xadrez_stats'].copy()
            if 'numeros_quebradores' in xs: xs['numeros_quebradores'] = dict(xs['numeros_quebradores'])
            state['xadrez_stats'] = xs
            
        if 'streak_breaker_stats' in state and isinstance(state['streak_breaker_stats'], dict):
            ss = state['streak_breaker_stats'].copy()
            for cor_k in ss: ss[cor_k] = dict(ss[cor_k])
            state['streak_breaker_stats'] = ss
            
        for d_name in ['padroes_xadrez_detalhado', 'padroes_streak_detalhado', 'padroes_gerais_detalhado']:
            if d_name in state:
                pd_dict = {}
                for k, v in state[d_name].items():
                    v_copy = v.copy()
                    if 'quebradores' in v_copy: v_copy['quebradores'] = dict(v_copy['quebradores'])
                    pd_dict[k] = v_copy
                state[d_name] = pd_dict
                
        if 'q_table' in state: state['q_table'] = dict(state['q_table'])
        
        if 'ml_gb' in state: del state['ml_gb']
        if 'ml_mlp' in state: del state['ml_mlp']
        if 'ml_hmm' in state: del state['ml_hmm']
        
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self.modelo_transicao = defaultdict(list, state.get('modelo_transicao', {}))
        self.modelo_transicao_profundo = defaultdict(list, state.get('modelo_transicao_profundo', {}))
        self.modelo_numerico = defaultdict(list, state.get('modelo_numerico', {}))
        
        bigramas_loaded = state.get('bigramas_numericos', {})
        self.bigramas_numericos = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0, "prox_numero": defaultdict(int)})
        for k, v in bigramas_loaded.items():
            self.bigramas_numericos[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0), "prox_numero": defaultdict(int, v.get("prox_numero", {}))}

        saturacao_loaded = state.get('saturacao_ciclica', {})
        self.saturacao_ciclica = defaultdict(lambda: {"ciclos_V": [], "ciclos_P": [], "historico_distancias": []})
        for k, v in saturacao_loaded.items(): self.saturacao_ciclica[k] = {"ciclos_V": v.get("ciclos_V", []), "ciclos_P": v.get("ciclos_P", []), "historico_distancias": v.get("historico_distancias", [])}
            
        dna_loaded = state.get('dna_padroes', {})
        self.dna_padroes = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        for k, v in dna_loaded.items(): self.dna_padroes[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0)}
            
        pfn_loaded = state.get('padroes_fechamento_numerico', {})
        self.padroes_fechamento_numerico = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        for k, v in pfn_loaded.items(): self.padroes_fechamento_numerico[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0)}
            
        epg_loaded = state.get('estatisticas_projecoes_globais', {})
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        for k, v in epg_loaded.items(): self.estatisticas_projecoes_globais[int(k)] = {"total": v.get("total",0), "g0": v.get("g0",0), "g1": v.get("g1",0), "falha": v.get("falha",0)}
            
        ebg_loaded = state.get('estatisticas_bigramas_globais', {})
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        for k, v in ebg_loaded.items(): self.estatisticas_bigramas_globais[k] = {"total": v.get("total",0), "V_g0": v.get("V_g0",0), "V_g1": v.get("V_g1",0), "P_g0": v.get("P_g0",0), "P_g1": v.get("P_g1",0)}

        etg_loaded = state.get('estatisticas_trigramas_globais', {})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        for k, v in etg_loaded.items(): self.estatisticas_trigramas_globais[k] = {"total": v.get("total",0), "V_g0": v.get("V_g0",0), "V_g1": v.get("V_g1",0), "P_g0": v.get("P_g0",0), "P_g1": v.get("P_g1",0)}
            
        self.probabilidades_globais = state.get('probabilidades_globais', {"streak_v_5": 0.0, "streak_p_5": 0.0, "xadrez_5": 0.0})
        self.controladores_fortes = defaultdict(int, state.get('controladores_fortes', {}))
        self.historico_regras = defaultdict(fabrica_historico_regras_zerado)
        for k, v in state.get('historico_regras', {}).items(): self.historico_regras[k] = {"acertos": v.get("acertos", 0), "total": v.get("total", 0)}
        c_grams = state.get('color_ngrams', {1: {}, 2: {}, 3: {}})
        self.color_ngrams = {k: defaultdict(int, v) for k, v in c_grams.items()}
        
        x_st = state.get('xadrez_stats', {})
        self.xadrez_stats = {"quebras": x_st.get("quebras", 0), "continuacoes": x_st.get("continuacoes", 0), "numeros_quebradores": defaultdict(int, x_st.get("numeros_quebradores", {}))}
        
        s_st = state.get('streak_breaker_stats', {"V": {}, "P": {}})
        self.streak_breaker_stats = {"V": defaultdict(int, s_st.get("V", {})), "P": defaultdict(int, s_st.get("P", {}))}
        
        for d_name in ['padroes_xadrez_detalhado', 'padroes_streak_detalhado', 'padroes_gerais_detalhado']:
            if d_name in state:
                pd_dict = {}
                for k, v in state[d_name].items():
                    v_copy = v.copy()
                    if 'quebradores' in v_copy: v_copy['quebradores'] = dict(v_copy['quebradores'])
                    pd_dict[k] = v_copy
                state[d_name] = pd_dict
                
        if 'q_table' in state: state['q_table'] = dict(state['q_table'])
        
        if 'ml_gb' in state: del state['ml_gb']
        if 'ml_mlp' in state: del state['ml_mlp']
        if 'ml_hmm' in state: del state['ml_hmm']
        
        return state

    def _treinar_modelo_profundo(self):
        if self.dados_longo and len(self.dados_longo) >= 5:
            self._processar_bloco_dados(self.dados_longo, 1, True)
            self._calcular_probabilidades_globais_cache()
        if self.dados_recencia and len(self.dados_recencia) >= 5:
            self._processar_bloco_dados(self.dados_recencia, 4, True)
            
        todos_dados = (self.dados_longo or []) + (self.dados_recencia or [])
        if todos_dados:
            self._mapear_projecoes_globais(todos_dados)
            self._treinar_ml_avancado(todos_dados)

    def _treinar_ml_avancado(self, dados):
        if not HAS_ML or len(dados) < 50:
            return
            
        X = []
        y = []
        seq_hmm = []
        
        c_map = {'P': 0, 'V': 1, 'B': 2}
        for d in dados:
            seq_hmm.append([c_map.get(d['cor'], 2)])
            
        try:
            self.ml_hmm = CategoricalHMM(n_components=3, n_iter=100)
            if len(seq_hmm) > 50:
                self.ml_hmm.fit(np.array(seq_hmm))
        except:
            self.ml_hmm = None

        for i in range(len(dados) - 12):
            janela = dados[i:i+12]
            alvo = dados[i+12]['cor']
            pol = [d['cor'] for d in janela]
            num = [d['numero'] for d in janela]

            if alvo in ['V', 'P']:
                entropia = EngineMatematicoAvancado.calcular_entropia_shannon(pol)
                prob_markov = self.calcular_probabilidade_exata_markov(pol)
                freq_v = pol.count('V')/12.0
                
                # --- SUPERCÉREBRO UNIFICADO: Ingestão de Heurística ---
                geometria = AnalisadorContextoAvancado.mapear_padroes_geometria(pol)
                geo_val = 1 if geometria == "CICLO_FECHADO_PVVP" else (-1 if geometria == "CICLO_FECHADO_VPPV" else 0)
                
                expectativas = MotorContagensProjetivas.mapear_janela(num, pol, geometria, self)
                peso_v = sum(3 if any(k in e["tipo_regra"] for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e["direcao"] == "VERMELHO")
                peso_p = sum(3 if any(k in e["tipo_regra"] for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e["direcao"] == "PRETO")
                regra_val = peso_v - peso_p
                
                quebrador_val = 0
                if hasattr(self, 'verificar_quebrador_historico'):
                    eh_q, dir_q, _ = self.verificar_quebrador_historico(num, pol)
                    if eh_q:
                        quebrador_val = 1 if dir_q == "VERMELHO" else -1

                features = [entropia, prob_markov['V'], prob_markov['P'], num[-1], num[-2], freq_v, geo_val, regra_val, quebrador_val]
                X.append(features)
                y.append(1 if alvo == 'V' else 0)

        if len(X) > 20:
            try:
                self.ml_gb = GradientBoostingClassifier(n_estimators=150, learning_rate=0.05, max_depth=4)
                self.ml_gb.fit(X, y)

                self.ml_mlp = MLPClassifier(hidden_layer_sizes=(64, 32), activation='relu', max_iter=800)
                self.ml_mlp.fit(X, y)

                self.ml_ready = True
            except Exception as e:
                print(f"Erro no treino das Redes Neurais/XGBoost: {e}")
                self.ml_ready = False

    def atualizar_q_learning(self, estado_str, acao, recompensa):
        if not hasattr(self, 'q_table'):
            self.q_table = {}
        if estado_str not in self.q_table:
            self.q_table[estado_str] = {"APOSTAR": 0.0, "NO_CALL": 0.0}
            
        alpha = 0.1
        current_q = self.q_table[estado_str][acao]
        self.q_table[estado_str][acao] = current_q + alpha * (recompensa - current_q)

    def _mapear_projecoes_globais(self, dados):
        if not dados or len(dados) < 10: return
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        
        total_dados = len(dados)
        for i in range(total_dados):
            num = dados[i]['numero']
            
            # 1. Projeções Volume 3 (1 a 7) - Sempre alvo Vermelho (até G1)
            if 1 <= num <= 7:
                passo = num
                alvo_idx = i + passo
                if alvo_idx + 1 < total_dados:
                    caminho_tem_branco = False
                    for k in range(i + 1, alvo_idx):
                        if dados[k]['cor'] == 'B':
                            caminho_tem_branco = True
                            break
                    if not caminho_tem_branco:
                        cor_alvo = dados[alvo_idx]['cor']
                        if cor_alvo in ['V', 'B']:
                            self.estatisticas_projecoes_globais[num]["g0"] += 1
                            self.estatisticas_projecoes_globais[num]["total"] += 1
                        else:
                            cor_g1 = dados[alvo_idx + 1]['cor']
                            if cor_g1 in ['V', 'B']:
                                self.estatisticas_projecoes_globais[num]["g1"] += 1
                                self.estatisticas_projecoes_globais[num]["total"] += 1
                            else:
                                self.estatisticas_projecoes_globais[num]["falha"] += 1
                                self.estatisticas_projecoes_globais[num]["total"] += 1

            # 2. Bigramas Globais (Até G1 para ambas as cores)
            if i >= 1 and i + 2 < total_dados:
                bigrama = f"{dados[i-1]['numero']}-{dados[i]['numero']}"
                c0 = dados[i+1]['cor']
                c1 = dados[i+2]['cor']
                self.estatisticas_bigramas_globais[bigrama]["total"] += 1
                if c0 in ['V', 'B']: self.estatisticas_bigramas_globais[bigrama]["V_g0"] += 1
                elif c1 in ['V', 'B']: self.estatisticas_bigramas_globais[bigrama]["V_g1"] += 1
                
                if c0 in ['P', 'B']: self.estatisticas_bigramas_globais[bigrama]["P_g0"] += 1
                elif c1 in ['P', 'B']: self.estatisticas_bigramas_globais[bigrama]["P_g1"] += 1

            # 3. Trigramas Globais (Até G1 para ambas as cores)
            if i >= 2 and i + 2 < total_dados:
                trigrama = f"{dados[i-2]['numero']}-{dados[i-1]['numero']}-{dados[i]['numero']}"
                c0 = dados[i+1]['cor']
                c1 = dados[i+2]['cor']
                self.estatisticas_trigramas_globais[trigrama]["total"] += 1
                if c0 in ['V', 'B']: self.estatisticas_trigramas_globais[trigrama]["V_g0"] += 1
                elif c1 in ['V', 'B']: self.estatisticas_trigramas_globais[trigrama]["V_g1"] += 1
                
                if c0 in ['P', 'B']: self.estatisticas_trigramas_globais[trigrama]["P_g0"] += 1
                elif c1 in ['P', 'B']: self.estatisticas_trigramas_globais[trigrama]["P_g1"] += 1

    def _calcular_probabilidades_globais_cache(self):
        self.probabilidades_globais["streak_v_5"] = self.calcular_probabilidade_streak_empirica('V', 5)
        self.probabilidades_globais["streak_p_5"] = self.calcular_probabilidade_streak_empirica('P', 5)
        self.probabilidades_globais["xadrez_5"] = self.calcular_probabilidade_xadrez_empirica(5)

    def mapear_padroes_avancados(self, dados):
        if not dados or len(dados) < 10: return
        cores = [d['cor'] for d in dados]
        numeros = [d['numero'] for d in dados]
        rastreio_numeros = {}
        for i in range(len(dados) - 1):
            num = numeros[i]
            cor_post = cores[i+1]
            if num not in rastreio_numeros:
                rastreio_numeros[num] = {"sequencia_atual": cor_post, "contagem": 1}
            else:
                if rastreio_numeros[num]["sequencia_atual"] == cor_post:
                    rastreio_numeros[num]["contagem"] += 1
                else:
                    cor_quebrada = rastreio_numeros[num]["sequencia_atual"]
                    tamanho_ciclo = rastreio_numeros[num]["contagem"]
                    if cor_quebrada == "V": self.saturacao_ciclica[num]["ciclos_V"].append(tamanho_ciclo)
                    elif cor_quebrada == "P": self.saturacao_ciclica[num]["ciclos_P"].append(tamanho_ciclo)
                    rastreio_numeros[num] = {"sequencia_atual": cor_post, "contagem": 1}

        i = 0
        while i < len(cores) - 4:
            janela = cores[i:i+4]
            if all(janela[j] != janela[j-1] for j in range(1, 4)) and 'B' not in janela:
                if i + 4 < len(cores):
                    proximo_cor = cores[i+4]
                    num_quebra = numeros[i+3]
                    chave = "XADREZ_4"
                    self.padroes_xadrez_detalhado[chave]["total"] += 1
                    self.padroes_xadrez_detalhado[chave][f"apos_{proximo_cor}"] += 1
                    if proximo_cor != janela[-1]: self.padroes_xadrez_detalhado[chave]["quebradores"][num_quebra] += 1
                    c1 = cores[i+4] if i+4 < len(cores) else None
                    c2 = cores[i+5] if i+5 < len(cores) else None
                    c3 = cores[i+6] if i+6 < len(cores) else None
                    if "_futuros" not in self.padroes_xadrez_detalhado[chave]: self.padroes_xadrez_detalhado[chave]["_futuros"] = []
                    self.padroes_xadrez_detalhado[chave]["_futuros"].append((c1, c2, c3))
            i += 1
        i = 0
        while i < len(cores) - 3:
            if cores[i] == cores[i+1] == cores[i+2] and cores[i] != 'B':
                if i + 3 < len(cores):
                    proximo_cor = cores[i+3]
                    num_quebra = numeros[i+3]
                    chave = "STREAK_3"
                    self.padroes_streak_detalhado[chave]["total"] += 1
                    self.padroes_streak_detalhado[chave][f"apos_{proximo_cor}"] += 1
                    if proximo_cor != cores[i]: self.padroes_streak_detalhado[chave]["quebradores"][num_quebra] += 1
                    c1 = cores[i+3] if i+3 < len(cores) else None
                    c2 = cores[i+4] if i+4 < len(cores) else None
                    c3 = cores[i+5] if i+5 < len(cores) else None
                    if "_futuros" not in self.padroes_streak_detalhado[chave]: self.padroes_streak_detalhado[chave]["_futuros"] = []
                    self.padroes_streak_detalhado[chave]["_futuros"].append((c1, c2, c3))
            i += 1
        for tam in range(3, 11):
            i = 0
            while i <= len(cores) - tam - 1:
                janela_cores = cores[i:i+tam]
                janela_nums = numeros[i:i+tam]
                if 'B' in janela_cores:
                    i += 1
                    continue
                proxima_cor = cores[i+tam]
                num_quebra = numeros[i+tam-1]
                janela_str = "-".join(janela_cores)
                
                chave_dna = "-".join(map(str, janela_nums))
                self.dna_padroes[chave_dna]["total"] += 1
                self.dna_padroes[chave_dna][proxima_cor] += 1
                
                eh_streak = len(set(janela_cores)) == 1
                eh_xadrez = all(janela_cores[j] != janela_cores[j-1] for j in range(1, tam))
                eh_duplo = False
                if tam >= 4 and tam % 2 == 0:
                    metade = tam // 2
                    if len(set(janela_cores[:metade])) == 1 and len(set(janela_cores[metade:])) == 1 and janela_cores[0] != janela_cores[metade]:
                        eh_duplo = True
                eh_espelho_normal = all(janela_cores[j] == janela_cores[tam-1-j] for j in range(tam)) and not eh_streak
                eh_espelho_invertido = all(janela_cores[j] != janela_cores[tam-1-j] for j in range(tam)) and not eh_xadrez
                if eh_streak: tipo_prefix = f"STREAK_{tam}"
                elif eh_xadrez: tipo_prefix = f"XADREZ_{tam}"
                elif eh_duplo: tipo_prefix = f"DUPLO_{tam}"
                elif eh_espelho_normal: tipo_prefix = f"ESPELHO_NORMAL_{tam}"
                elif eh_espelho_invertido: tipo_prefix = f"ESPELHO_INVERTIDO_{tam}"
                else: tipo_prefix = f"PADRAO_GERAL_{tam}"
                
                chave = f"{tipo_prefix} [{janela_str}]"
                self.padroes_gerais_detalhado[chave]["total"] += 1
                self.padroes_gerais_detalhado[chave][f"apos_{proxima_cor}"] += 1
                if eh_streak and proxima_cor != janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                elif eh_xadrez and proxima_cor == janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                elif (eh_duplo or eh_espelho_normal or eh_espelho_invertido) and proxima_cor != janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                
                c1 = cores[i+tam] if i+tam < len(cores) else None
                c2 = cores[i+tam+1] if i+tam+1 < len(cores) else None
                c3 = cores[i+tam+2] if i+tam+2 < len(cores) else None
                if "_futuros" not in self.padroes_gerais_detalhado[chave]: self.padroes_gerais_detalhado[chave]["_futuros"] = []
                self.padroes_gerais_detalhado[chave]["_futuros"].append((c1, c2, c3))
                i += 1
        for i in range(len(cores)):
            self.color_ngrams[1][cores[i]] += 1
            if i + 1 < len(cores): self.color_ngrams[2][f"{cores[i]}-{cores[i+1]}"] += 1
            if i + 2 < len(cores): self.color_ngrams[3][f"{cores[i]}-{cores[i+1]}-{cores[i+2]}"] += 1
        for dic in [self.padroes_xadrez_detalhado, self.padroes_streak_detalhado, self.padroes_gerais_detalhado]:
            for chave, info in list(dic.items()):
                v = info.get("apos_V", 0)
                p = info.get("apos_P", 0)
                if v == 0 and p == 0: continue
                cor_alvo = "V" if v >= p else "P"
                for c1, c2, c3 in info.get("_futuros", []):
                    if c1 == cor_alvo or c1 == "B": info["g0"] += 1
                    elif c2 == cor_alvo or c2 == "B": info["g1"] += 1
                if "_futuros" in info: del info["_futuros"]

    def _processar_bloco_dados(self, dados, multiplicador_peso, treinamento_profundo=False):
        if not dados or len(dados) < 3: return
        total_dados = len(dados)
        
        for i in range(total_dados - 4):
            estado_2 = (dados[i+2]['cor'], dados[i+3]['cor'])
            estado_4 = (dados[i]['cor'], dados[i+1]['cor'], dados[i+2]['cor'], dados[i+3]['cor'])
            prox = dados[i+4]['cor']
            num = dados[i+3]['numero']
            fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
            peso_final = max(1, int(multiplicador_peso * fator_temporal))
            for _ in range(peso_final):
                self.modelo_transicao[estado_2].append(prox)
                self.modelo_transicao_profundo[estado_4].append(prox)
                self.modelo_numerico[num].append(prox)

        for i in range(total_dados - 1):
            num = int(dados[i]['numero'])
            cor_post = str(dados[i+1]['cor']).upper()
            if 0 <= num <= 14 and cor_post in ['V', 'P', 'B']:
                self.unidade_analise[num]["ocorrencias"] += multiplicador_peso
                self.unidade_analise[num][cor_post] += multiplicador_peso
                self.unidade_analise[num][f"pos_numero_{cor_post}"] += multiplicador_peso
                self.unidade_analise[num]["ultimas_cores"].append(cor_post)
                if len(self.unidade_analise[num]["ultimas_cores"]) > 10:
                    self.unidade_analise[num]["ultimas_cores"].pop(0)
                    
        for i in range(total_dados - 2):
            num1 = int(dados[i]['numero'])
            num2 = int(dados[i+1]['numero'])
            prox_num = int(dados[i+2]['numero'])
            if num1 != num2 and 0 <= num1 <= 14 and 0 <= num2 <= 14:
                cor_proxima = str(dados[i+2]['cor']).upper()
                if cor_proxima in ['V', 'P', 'B']:
                    chave_dupla = f"{num1}-{num2}"
                    fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
                    peso_final = max(1, int(multiplicador_peso * fator_temporal))
                    self.bigramas_numericos[chave_dupla]["total"] += peso_final
                    self.bigramas_numericos[chave_dupla][cor_proxima] += peso_final
                    self.bigramas_numericos[chave_dupla]["prox_numero"][prox_num] += peso_final
                    
        for tam_padrao in [3, 4, 5]:
            for i in range(total_dados - tam_padrao):
                janela_cores = [dados[k]['cor'] for k in range(i, i+tam_padrao)]
                if 'B' not in janela_cores:
                    padrao_str = "".join(janela_cores)
                    ultimo_num = dados[i+tam_padrao-1]['numero']
                    penultimo_num = dados[i+tam_padrao-2]['numero']
                    cor_post = dados[i+tam_padrao]['cor']
                    chave_num = f"PADRAO_{padrao_str}_{ultimo_num}"
                    chave_bigrama = f"PADRAO_{padrao_str}_{penultimo_num}-{ultimo_num}"
                    fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
                    peso_final = max(1, int(multiplicador_peso * fator_temporal))
                    self.padroes_fechamento_numerico[chave_num]["total"] += peso_final
                    self.padroes_fechamento_numerico[chave_num][cor_post] += peso_final
                    self.padroes_fechamento_numerico[chave_bigrama]["total"] += peso_final
                    self.padroes_fechamento_numerico[chave_bigrama][cor_post] += peso_final
                    
        for n in range(15):
            total = self.unidade_analise[n]["ocorrencias"]
            if total > 0:
                self.unidade_analise[n]["freq_v"] = round((self.unidade_analise[n]["V"] / total) * 100, 2)
                self.unidade_analise[n]["freq_p"] = round((self.unidade_analise[n]["P"] / total) * 100, 2)
                self.unidade_analise[n]["freq_b"] = round((self.unidade_analise[n]["B"] / total) * 100, 2)
                self.unidade_analise[n]["comportamento_dominante"] = self._calcular_comportamento_dominante(n)
                self.unidade_analise[n]["estabilidade"] = self._calcular_estabilidade(n)
                self.unidade_analise[n]["enfraquecimento"] = self._calcular_enfraquecimento(n)
                self.unidade_analise[n]["saturacao"] = self._calcular_saturacao(n)

    def _calcular_comportamento_dominante(self, num):
        freq_v = self.unidade_analise[num]["freq_v"]
        freq_p = self.unidade_analise[num]["freq_p"]
        if freq_v > freq_p + 8: return "VERMELHO"
        elif freq_p > freq_v + 8: return "PRETO"
        return "NEUTRO"

    def _calcular_estabilidade(self, num):
        ultimas = self.unidade_analise[num]["ultimas_cores"]
        if len(ultimas) < 5: return "NEUTRO"
        dominante = self.unidade_analise[num]["comportamento_dominante"]
        if dominante == "NEUTRO": return "NEUTRO"
        count = sum(1 for c in ultimas if c == ('V' if dominante == "VERMELHO" else 'P'))
        taxa = count / len(ultimas)
        if taxa >= 0.7: return "ESTÁVEL"
        elif taxa <= 0.4: return "INSTÁVEL"
        return "NEUTRO"

    def _calcular_enfraquecimento(self, num):
        return "ENFRAQUECIDO" if self.unidade_analise[num]["estabilidade"] == "INSTÁVEL" else "ESTÁVEL"

    def _calcular_saturacao(self, num):
        total = self.unidade_analise[num]["ocorrencias"]
        if total > 800: return "ALTA"
        elif total > 400: return "MÉDIA"
        return "BAIXA"

    def injetar_aprendizado_imediato(self, sub_dados, multiplicador_peso=4, analise_contexto=None, salvar_na_recencia=True):
        if salvar_na_recencia:
            self.dados_recencia.extend(sub_dados)
        self._processar_bloco_dados(sub_dados, multiplicador_peso, True)
        if analise_contexto:
            for regra in analise_contexto.get("regras_posicionais", []):
                self.historico_regras[regra.get("tipo_regra", "DESCONHEVIDO")]["total"] += 1

    def registrar_padrao_vencedor(self, analise_contexto, resultado):
        if resultado not in ["G0", "G1"]: return
        padrao = {
            "geometria": analise_contexto.get("geometria"),
            "regras_ativas": [r.get("tipo_regra") for r in analise_contexto.get("regras_posicionais", [])],
            "controlador_dominante": analise_contexto.get("controlador_retardador", {}).get("dominancia"),
            "modo_mercado": analise_contexto.get("contexto_avancado", {}).get("modo_mercado"),
            "entropia_shannon": analise_contexto.get("entropia_shannon", 0.0),
            "monte_carlo_indicou": analise_contexto.get("monte_carlo_indicou"),
            "resultado": resultado,
            "peso": 1
        }
        if padrao not in self.memoria_padroes_vencedores:
            self.memoria_padroes_vencedores.append(padrao)
        if len(self.memoria_padroes_vencedores) > 50:
            self.memoria_padroes_vencedores.pop(0)

    def calcular_bonus_memoria(self, analise_contexto):
        bonus = 0
        entropia_atual = analise_contexto.get("entropia_shannon", 0.0)
        for padrao in self.memoria_padroes_vencedores:
            match = 0
            if padrao.get("geometria") == analise_contexto.get("geometria"): match += 8
            comuns = set(padrao.get("regras_ativas", [])) & set([r.get("tipo_regra") for r in analise_contexto.get("regras_posicionais", [])])
            match += len(comuns) * 3
            if padrao.get("entropia_shannon", 0.0) > 0:
                if abs(padrao.get("entropia_shannon", 0.0) - entropia_atual) <= 0.2: match += 5
            if match >= 12: bonus += 4
        return min(bonus, 22)
        
    def calcular_probabilidade_exata_markov(self, ultimas_cores):
        if not ultimas_cores or len(ultimas_cores) < 2:
            return {"V": 0.0, "P": 0.0, "B": 0.0}
            
        estado_inicial_2 = (ultimas_cores[-2], ultimas_cores[-1])
        estado_inicial_4 = tuple(ultimas_cores[-4:]) if len(ultimas_cores) >= 4 else None
        
        transicoes_4 = self.modelo_transicao_profundo.get(estado_inicial_4, []) if estado_inicial_4 else []
        transicoes_2 = self.modelo_transicao.get(estado_inicial_2, [])
        
        resultados = {'V': 0, 'P': 0, 'B': 0}
        if transicoes_4:
            for cor in transicoes_4: resultados[cor] += 2 
        if transicoes_2:
             for cor in transicoes_2: resultados[cor] += 1 
                
        total = sum(resultados.values())
        if total == 0: return {"V": 0.0, "P": 0.0, "B": 0.0}
        
        return {
            "V": round((resultados['V'] / total) * 100, 2),
            "P": round((resultados['P'] / total) * 100, 2),
            "B": round((resultados['B'] / total) * 100, 2)
        }

    def _calcular_z_score(self, sucessos, tentativas, probabilidade_esperada=0.4667):
        if tentativas == 0: return 0.0
        proporcao_real = sucessos / tentativas
        desvio_padrao = math.sqrt((probabilidade_esperada * (1 - probabilidade_esperada)) / tentativas)
        if desvio_padrao == 0: return 0.0
        z_score = (proporcao_real - probabilidade_esperada) / desvio_padrao
        return z_score

    def verificar_quebrador_historico(self, sub_num, sub_pol):
        if len(sub_num) < 3: return False, "NEUTRO", ""
        ultimo_num = sub_num[-1]
        for tam in range(10, 2, -1):
            if len(sub_pol) < tam: continue
            janela_cores = sub_pol[-tam:]
            janela_str = "-".join(janela_cores)
            eh_streak = len(set(janela_cores)) == 1
            eh_xadrez = all(janela_cores[j] != janela_cores[j-1] for j in range(1, tam))
            eh_duplo = False
            if tam >= 4 and tam % 2 == 0:
                metade = tam // 2
                if len(set(janela_cores[:metade])) == 1 and len(set(janela_cores[metade:])) == 1 and janela_cores[0] != janela_cores[metade]:
                    eh_duplo = True
            eh_espelho_normal = all(janela_cores[j] == janela_cores[tam-1-j] for j in range(tam)) and not eh_streak
            eh_espelho_invertido = all(janela_cores[j] != janela_cores[tam-1-j] for j in range(tam)) and not eh_xadrez
            if eh_streak: tipo_prefix = f"STREAK_{tam}"
            elif eh_xadrez: tipo_prefix = f"XADREZ_{tam}"
            elif eh_duplo: tipo_prefix = f"DUPLO_{tam}"
            elif eh_espelho_normal: tipo_prefix = f"ESPELHO_NORMAL_{tam}"
            elif eh_espelho_invertido: tipo_prefix = f"ESPELHO_INVERTIDO_{tam}"
            else: tipo_prefix = f"PADRAO_GERAL_{tam}"
            chave = f"{tipo_prefix} [{janela_str}]"
            info = self.padroes_gerais_detalhado.get(chave)
            if info and info["total"] >= 2:
                quebras = info["quebradores"].get(ultimo_num, 0)
                if quebras >= 2 and (quebras / info["total"]) >= 0.4:
                    direcao_inversao = "PRETO" if janela_cores[-1] == "V" else "VERMELHO"
                    return True, direcao_inversao, f"Quebrador Histórico Detectado: Número {ultimo_num} rompe o {chave}"
        return False, "NEUTRO", ""

    def predizer_proxima_casa(self, sub_num, sub_pol, analise_contexto=None):
        if len(sub_num) < 12:
            return "NEUTRO", 0.0, "Janela insuficiente"
        
        ultimo_num = sub_num[-1]
        penultimo_num = sub_num[-2]
        
        ultimas_cores_2 = (sub_pol[-2], sub_pol[-1])
        ultimas_cores_4 = tuple(sub_pol[-4:]) if len(sub_pol) >= 4 else None
        
        trans_2 = self.modelo_transicao.get(ultimas_cores_2, [])
        trans_4 = self.modelo_transicao_profundo.get(ultimas_cores_4, []) if hasattr(self, 'modelo_transicao_profundo') else []
        
        por_num = self.modelo_numerico.get(ultimo_num, [])
        stats = self.unidade_analise.get(ultimo_num, {"freq_v": 0, "freq_p": 0})
        
        v_bonus = stats.get("freq_v", 0) * 3.5
        p_bonus = stats.get("freq_p", 0) * 3.5

        if hasattr(self, 'estatisticas_trigramas_globais') and len(sub_num) >= 3:
            trigrama_atual = f"{sub_num[-3]}-{sub_num[-2]}-{sub_num[-1]}"
            stats_tri = self.estatisticas_trigramas_globais.get(trigrama_atual)
            if stats_tri and stats_tri["total"] >= 5:
                taxa_v_tri = ((stats_tri["V_g0"] + stats_tri["V_g1"]) / stats_tri["total"]) * 100
                taxa_p_tri = ((stats_tri["P_g0"] + stats_tri["P_g1"]) / stats_tri["total"]) * 100
                if taxa_v_tri >= 60.0: v_bonus += 25
                elif taxa_v_tri < 45.0: v_bonus -= 15
                if taxa_p_tri >= 60.0: p_bonus += 25
                elif taxa_p_tri < 45.0: p_bonus -= 15

        if hasattr(self, 'estatisticas_bigramas_globais') and len(sub_num) >= 2:
            bigrama_atual = f"{sub_num[-2]}-{sub_num[-1]}"
            stats_bi = self.estatisticas_bigramas_globais.get(bigrama_atual)
            if stats_bi and stats_bi["total"] >= 5:
                taxa_v_bi = ((stats_bi["V_g0"] + stats_bi["V_g1"]) / stats_bi["total"]) * 100
                taxa_p_bi = ((stats_bi["P_g0"] + stats_bi["P_g1"]) / stats_bi["total"]) * 100
                if taxa_v_bi >= 55.0: v_bonus += 18
                elif taxa_v_bi < 45.0: v_bonus -= 10
                if taxa_p_bi >= 55.0: p_bonus += 18
                elif taxa_p_bi < 45.0: p_bonus -= 10
        
        if hasattr(self, 'estatisticas_projecoes_globais') and analise_contexto:
            regras_ativas = analise_contexto.get("regras_posicionais", [])
            for r in regras_ativas:
                if r.get("tipo_regra", "").startswith("V3_ATIVADOR_"):
                    try:
                        num_projetivo = int(r["tipo_regra"].split("_")[-1])
                        stats_proj = self.estatisticas_projecoes_globais.get(num_projetivo)
                        if stats_proj and stats_proj["total"] >= 10:
                            taxa_global = ((stats_proj["g0"] + stats_proj["g1"]) / stats_proj["total"]) * 100
                            if taxa_global >= 55.0: v_bonus += 20
                            elif taxa_global < 45.0: v_bonus -= 20
                    except: pass
        
        dna_3 = "-".join(map(str, sub_num[-3:]))
        if hasattr(self, 'dna_padroes') and dna_3 in self.dna_padroes:
            dna_stats = self.dna_padroes[dna_3]
            if dna_stats["total"] >= 5: 
                prob_dna_v = (dna_stats["V"] / dna_stats["total"]) * 100
                prob_dna_p = (dna_stats["P"] / dna_stats["total"]) * 100
                z_score_v = self._calcular_z_score(dna_stats["V"], dna_stats["total"])
                z_score_p = self._calcular_z_score(dna_stats["P"], dna_stats["total"])
                if prob_dna_v >= 60.0 and z_score_v > 1.64: v_bonus += 25
                elif prob_dna_p >= 60.0 and z_score_p > 1.64: p_bonus += 25

        if penultimo_num != ultimo_num:
            chave_dupla = f"{penultimo_num}-{ultimo_num}"
            stats_dupla = self.bigramas_numericos.get(chave_dupla)
            if stats_dupla and stats_dupla["total"] >= 5:
                prob_v_dupla = (stats_dupla["V"] / stats_dupla["total"]) * 100
                prob_p_dupla = (stats_dupla["P"] / stats_dupla["total"]) * 100
                z_score_v = self._calcular_z_score(stats_dupla["V"], stats_dupla["total"])
                z_score_p = self._calcular_z_score(stats_dupla["P"], stats_dupla["total"])
                if prob_v_dupla > 55.0 and z_score_v > 1.64: v_bonus += 18
                elif prob_p_dupla > 55.0 and z_score_p > 1.64: p_bonus += 18

        if hasattr(self, 'padroes_fechamento_numerico'):
            aplicou_destrinchador = False
            for tam in [5, 4, 3]:
                if len(sub_pol) >= tam and not aplicou_destrinchador:
                    padrao_atual = "".join(sub_pol[-tam:])
                    if 'B' not in padrao_atual:
                        chave_num = f"PADRAO_{padrao_atual}_{ultimo_num}"
                        chave_bigrama = f"PADRAO_{padrao_atual}_{penultimo_num}-{ultimo_num}"
                        stats_bigrama = self.padroes_fechamento_numerico.get(chave_bigrama)
                        if stats_bigrama and stats_bigrama["total"] >= 3:
                            prob_v = (stats_bigrama["V"] / stats_bigrama["total"]) * 100
                            prob_p = (stats_bigrama["P"] / stats_bigrama["total"]) * 100
                            z_score_v = self._calcular_z_score(stats_bigrama["V"], stats_bigrama["total"])
                            z_score_p = self._calcular_z_score(stats_bigrama["P"], stats_bigrama["total"])
                            if prob_v >= 55.0 and z_score_v > 1.28:
                                v_bonus += 45
                                aplicou_destrinchador = True
                            elif prob_p >= 55.0 and z_score_p > 1.28:
                                p_bonus += 45
                                aplicou_destrinchador = True
                        if not aplicou_destrinchador:
                            stats_num = self.padroes_fechamento_numerico.get(chave_num)
                            if stats_num and stats_num["total"] >= 3:
                                prob_v = (stats_num["V"] / stats_num["total"]) * 100
                                prob_p = (stats_num["P"] / stats_num["total"]) * 100
                                z_score_v = self._calcular_z_score(stats_num["V"], stats_num["total"])
                                z_score_p = self._calcular_z_score(stats_num["P"], stats_num["total"])
                                if prob_v >= 55.0 and z_score_v > 1.28:
                                    v_bonus += 35
                                    aplicou_destrinchador = True
                                elif prob_p >= 55.0 and z_score_p > 1.28:
                                    p_bonus += 35
                                    aplicou_destrinchador = True

        comportamento = stats.get("comportamento_dominante", "NEUTRO")
        estabilidade = stats.get("estabilidade", "NEUTRO")
        enfraquecimento = stats.get("enfraquecimento", "ESTÁVEL")
        if comportamento == "VERMELHO": v_bonus += 12
        elif comportamento == "PRETO": p_bonus += 12
        if estabilidade == "ESTÁVEL":
            if comportamento == "VERMELHO": v_bonus += 10
            elif comportamento == "PRETO": p_bonus += 10
        elif estabilidade == "INSTÁVEL":
            v_bonus -= 8
            p_bonus -= 8
            
        has_rec = len(self.dados_recencia) > 0
        p_trans_4 = 0.30 if has_rec else 0.25
        p_trans_2 = 0.12 if has_rec else 0.10
        p_num = 0.15 if has_rec else 0.14
        
        v_deep = (trans_4.count('V') * p_trans_4) if trans_4 else 0
        p_deep = (trans_4.count('P') * p_trans_4) if trans_4 else 0
        
        total_v = v_deep + (trans_2.count('V') * p_trans_2) + (por_num.count('V') * p_num) + v_bonus
        total_p = p_deep + (trans_2.count('P') * p_trans_2) + (por_num.count('P') * p_num) + p_bonus
        
        prob_v_heuristica = (total_v / (total_v + total_p)) * 100 if (total_v + total_p) > 0 else 0
        prob_p_heuristica = (total_p / (total_v + total_p)) * 100 if (total_v + total_p) > 0 else 0

        if getattr(self, 'ml_ready', False) and HAS_ML:
            try:
                entropia = EngineMatematicoAvancado.calcular_entropia_shannon(sub_pol)
                prob_markov = self.calcular_probabilidade_exata_markov(sub_pol)
                freq_v = sub_pol.count('V') / 12.0
                
                # Supercérebro Unificado: Injeção de Features Heurísticas e de Padrões
                geo_val = 0
                regra_val = 0
                quebrador_val = 0
                
                if analise_contexto:
                    geometria = analise_contexto.get("geometria", "ESTÁVEL")
                    geo_val = 1 if geometria == "CICLO_FECHADO_PVVP" else (-1 if geometria == "CICLO_FECHADO_VPPV" else 0)
                    
                    expectativas = analise_contexto.get("regras_posicionais", [])
                    peso_v = sum(3 if any(k in e.get("tipo_regra", "") for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e.get("direcao") == "VERMELHO")
                    peso_p = sum(3 if any(k in e.get("tipo_regra", "") for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e.get("direcao") == "PRETO")
                    regra_val = peso_v - peso_p

                if hasattr(self, 'verificar_quebrador_historico'):
                    eh_q, dir_q, _ = self.verificar_quebrador_historico(sub_num, sub_pol)
                    if eh_q:
                        quebrador_val = 1 if dir_q == "VERMELHO" else -1

                features = [[entropia, prob_markov['V'], prob_markov['P'], sub_num[-1], sub_num[-2], freq_v, geo_val, regra_val, quebrador_val]]
                
                prob_gb = self.ml_gb.predict_proba(features)[0]
                prob_mlp = self.ml_mlp.predict_proba(features)[0]
                
                ml_v_val = ((prob_gb[1] + prob_mlp[1]) / 2.0) * 100
                ml_p_val = ((prob_gb[0] + prob_mlp[0]) / 2.0) * 100
                
                BARREIRA = 52.5
                if ml_v_val >= BARREIRA and ml_v_val > ml_p_val:
                    return "VERMELHO", round(ml_v_val, 1), f"Supercérebro Unificado (Deep Learning + Heurística): Detectou Padrão para V ({ml_v_val:.1f}%)"
                elif ml_p_val >= BARREIRA and ml_p_val > ml_v_val:
                    return "PRETO", round(ml_p_val, 1), f"Supercérebro Unificado (Deep Learning + Heurística): Detectou Padrão para P ({ml_p_val:.1f}%)"
                else:
                    return "NEUTRO", round(max(ml_v_val, ml_p_val), 1), "Supercérebro Unificado: Conflito multidimensional. Risco elevado, abortar entrada."
            except Exception as e:
                pass

        BARREIRA = 52.5
        if prob_v_heuristica >= BARREIRA and prob_v_heuristica > prob_p_heuristica + 4:
            return "VERMELHO", round(prob_v_heuristica, 1), f"Confluência de Heurística e Z-Score ({prob_v_heuristica:.1f}%)"
        elif prob_p_heuristica >= BARREIRA and prob_p_heuristica > prob_v_heuristica + 4:
            return "PRETO", round(prob_p_heuristica, 1), f"Confluência de Heurística e Z-Score ({prob_p_heuristica:.1f}%)"
        return "NEUTRO", round(max(prob_v_heuristica, prob_p_heuristica), 1), "Sem confluência clara"

    def calcular_probabilidade_streak_empirica(self, cor, k):
        todos = (self.dados_longo or []) + (self.dados_recencia or [])
        if len(todos) < k + 1: return 0.0
        total = len(todos) - k
        count = sum(1 for i in range(total) if all(d['cor'] == cor for d in todos[i:i+k]))
        return round((count / total) * 100, 2) if total > 0 else 0.0

    def calcular_probabilidade_xadrez_empirica(self, k):
        todos = (self.dados_longo or []) + (self.dados_recencia or [])
        if len(todos) < k + 1: return 0.0
        total = len(todos) - k
        count = 0
        for i in range(total):
            janela = [d['cor'] for d in todos[i:i+k]]
            if all(janela[j] != janela[j-1] for j in range(1, len(janela))):
                count += 1
        return round((count / total) * 100, 2) if total > 0 else 0.0

    def analisar_comportamento_pos_numero_recencia(self, dados_recencia):
        if not dados_recencia or len(dados_recencia) < 30: return {"mensagem": "Base muito pequena"}
        relatorio = {}
        contagem = {n: {"total": 0, "pos_V": 0, "pos_P": 0, "pos_B": 0} for n in range(15)}
        for i in range(len(dados_recencia) - 1):
            num = dados_recencia[i]['numero']
            cor_proxima = dados_recencia[i + 1]['cor']
            contagem[num]["total"] += 1
            if cor_proxima == "V": contagem[num]["pos_V"] += 1
            elif cor_proxima == "P": contagem[num]["pos_P"] += 1
            else: contagem[num]["pos_B"] += 1
        for num in range(15):
            dados = contagem[num]
            if dados["total"] == 0: continue
            total = dados["total"]
            cores = {"VERMELHO": dados["pos_V"], "PRETO": dados["pos_P"], "BRANCO": dados["pos_B"]}
            cor_dominante = max(cores, key=cores.get)
            freq = round((cores[cor_dominante] / total) * 100, 2)
            relatorio[num] = {
                "total_aparicoes_recencia": total, "cor_mais_frequente_apos": cor_dominante,
                "frequencia_cor_dominante_%": freq, "tendencia_recente": "FORTE" if freq >= 65 else ("MODERADA" if freq >= 55 else "FRACA")
            }
        return relatorio

    def analisar_comportamento_pos_numero(self):
        relatorio = {}
        for num in range(15):
            dados = self.unidade_analise[num]
            total = dados["ocorrencias"]
            if total == 0: continue
            cores_pos = {"VERMELHO": dados["pos_numero_V"], "PRETO": dados["pos_numero_P"], "BRANCO": dados["pos_numero_B"]}
            cor_dominante = max(cores_pos, key=cores_pos.get)
            freq_dominante = round((cores_pos[cor_dominante] / total) * 100, 2)
            ultimas = dados["ultimas_cores"]
            if len(ultimas) >= 8:
                ultimas_dominantes = sum(1 for c in ultimas if c == ('V' if cor_dominante == "VERMELHO" else 'P'))
                taxa_ultimas = ultimas_dominantes / len(ultimas)
                if taxa_ultimas < 0.5: tendencia = "EM MUDANÇA / SATURAÇÃO POSSÍVEL"
                elif taxa_ultimas >= 0.75: tendencia = "ESTÁVEL"
                else: tendencia = "MODERADO"
            else: tendencia = "DADOS INSUFICIENTES"
            relatorio[num] = {
                "total_aparicoes": total, "cor_mais_frequente_apos": cor_dominante,
                "frequencia_cor_dominante_%": freq_dominante, "distribuicao_pos": cores_pos,
                "comportamento_dominante": dados["comportamento_dominante"], "estabilidade": dados["estabilidade"],
                "saturacao": dados["saturacao"], "tendencia_recente": tendencia
            }
        return relatorio
