import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

# ============================================================
# INTEGRAÇÃO DE MACHINE LEARNING E DEEP LEARNING
# ============================================================
try:
    import numpy as np
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.neural_network import MLPClassifier
    from hmmlearn.hmm import CategoricalHMM
    HAS_ML = True
except ImportError:
    HAS_ML = False
    print("Aviso: Bibliotecas ML não encontradas. O Motor funcionará no modo Estatístico Avançado. Instale com: pip install numpy scikit-learn hmmlearn")

NOME_BASE_DEFINITIVA = "resultados_blaze.xlsx"

# ============================================================
# Funções de Fábrica Globais
# ============================================================
def fabrica_padrao_detalhado():
    return {
        "total": 0, "apos_V": 0, "apos_P": 0, "apos_B": 0,
        "quebradores": defaultdict(int), "g0": 0, "g1": 0,
        "_futuros": []
    }

def fabrica_historico_regras_zerado():
    return {"acertos": 0, "total": 0}

def fabrica_historico_regras_auditado():
    return {"acertos": 1, "total": 1}

def salvar_log_json(dados, nome_arquivo="logs/sinais_tipo_b.jsonl"):
    os.makedirs("logs", exist_ok=True)
    dados["timestamp"] = datetime.now().isoformat()
    with open(nome_arquivo, "a", encoding="utf-8") as f:
        f.write(json.dumps(dados, ensure_ascii=False) + "\n")

def salvar_modelo_longo_prazo(ia, caminho="modelo_longo_prazo.pkl"):
    try:
        pasta = os.path.dirname(caminho)
        if pasta:
            os.makedirs(pasta, exist_ok=True)
        dir_alvo = pasta if pasta else "."
        for tentativa in range(5):
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.pkl', dir=dir_alvo) as tmp:
                    tmp_path = tmp.name
                    pickle.dump(ia, tmp, protocol=pickle.HIGHEST_PROTOCOL)
                    tmp.flush()
                    os.fsync(tmp.fileno())
                if os.path.exists(caminho):
                    os.remove(caminho)
                os.replace(tmp_path, caminho)
                return True
            except Exception as e:
                print(f"Tentativa {tentativa + 1} de salvar o modelo falhou: {e}")
                if tmp_path and os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except:
                        pass
                time.sleep(0.7)
        return False
    except Exception as e:
        print(f"Erro crítico ao salvar modelo: {e}")
        return False

def carregar_modelo_longo_prazo(caminho="modelo_longo_prazo.pkl"):
    if os.path.exists(caminho):
        try:
            with open(caminho, "rb") as f:
                return pickle.load(f)
        except Exception as e:
            print(f"Erro ao carregar modelo: {e}")
            return None
    return None

def analisar_regime_recencia(dados_recencia):
    if not dados_recencia or len(dados_recencia) < 20:
        return {
            "viés_atual": "INDEFINIDO",
            "modo_dominante": "NEUTRO",
            "xadrez_frequencia": 0.0,
            "streak_medio": 0,
            "confianca_regime": 0
        }
    
    janela_termometro = min(len(dados_recencia), 100)
    recorte_termometro = dados_recencia[-janela_termometro:]
    
    cores = [d['cor'] for d in recorte_termometro]
    total = len(cores)
    
    if total == 0:
        return {
            "viés_atual": "INDEFINIDO",
            "modo_dominante": "NEUTRO",
            "xadrez_frequencia": 0.0,
            "streak_medio": 0,
            "confianca_regime": 0
        }
        
    v = cores.count('V')
    p = cores.count('P')
    pct_v = (v / total) * 100
    pct_p = (p / total) * 100
    
    if pct_v >= 52.5:
        viés = "VERMELHO"
    elif pct_p >= 52.5:
        viés = "PRETO"
    else:
        viés = "EQUILIBRADO"
        
    alternancias = sum(1 for i in range(1, total) if cores[i] != cores[i-1] and cores[i] != 'B' and cores[i-1] != 'B')
    xadrez_freq = (alternancias / (total - 1)) * 100 if total > 1 else 0
    
    streaks = []
    atual = 1
    for i in range(1, total):
        if cores[i] == cores[i-1] and cores[i] != 'B':
            atual += 1
        else:
            if atual >= 2:
                streaks.append(atual)
            atual = 1
            
    streak_medio = sum(streaks) / len(streaks) if streaks else 0
    
    if xadrez_freq >= 55.0:
        modo = "XADREZ_DOMINANTE"
    elif streak_medio >= 3.0:
        modo = "STREAK_DOMINANTE"
    else:
        modo = "MISTO"
        
    confianca = min(85, int(abs(pct_v - 50) + abs(pct_p - 50)))
    
    return {
        "viés_atual": viés,
        "modo_dominante": modo,
        "xadrez_frequencia": round(xadrez_freq, 1),
        "streak_medio": round(streak_medio, 1),
        "confianca_regime": confianca,
        "pct_vermelho_recencia": round(pct_v, 1),
        "pct_preto_recencia": round(pct_p, 1)
    }

def integrar_recencia_no_modelo(dados_recencia, multiplicador=5):
    ia = carregar_modelo_longo_prazo()
    if ia is None:
        ia = IAPreditivaV1([], dados_recencia)
    else:
        ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=multiplicador)
    ia.analise_recencia = ia.analisar_comportamento_pos_numero_recencia(dados_recencia)
    ia.regime_recencia = analisar_regime_recencia(dados_recencia)
    salvar_modelo_longo_prazo(ia)
    return ia

def adicionar_a_base_longo_prazo(novos_dados):
    if not novos_dados:
        return {"sucesso": False, "mensagem": "Nenhum dado novo foi fornecido."}
    base_existente = []
    if os.path.exists(NOME_BASE_DEFINITIVA):
        try:
            base_existente = LeitorXLS(NOME_BASE_DEFINITIVA).ler_e_validar() or []
        except:
            return {"sucesso": False, "mensagem": "Não foi possível ler a base antiga."}
    dados_combinados = base_existente + novos_dados
    if os.path.exists(NOME_BASE_DEFINITIVA):
        try:
            backup_name = NOME_BASE_DEFINITIVA.replace(".xlsx", f"_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            os.rename(NOME_BASE_DEFINITIVA, backup_name)
        except:
            pass
    try:
        df = pd.DataFrame([{"numero": d["numero"], "cor": d["cor"]} for d in dados_combinados])
        df.to_excel(NOME_BASE_DEFINITIVA, index=False)
    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro ao salvar o arquivo: {e}"}
    return treinar_base_longo_prazo_com_janelas(dados_combinados)

def reforcar_aprendizado_tipo_d(ia):
    for padrao, qtd in ia.controladores_fortes.items():
        if qtd >= 8:
            ia.padroes_fortes.append({"tipo": "CONTROLADOR_MUITO_FORTE", "padrao": padrao, "peso": qtd * 2})
    ia.padroes_fortes = sorted(ia.padroes_fortes, key=lambda x: x.get("peso", 0), reverse=True)[:30]

def treinar_base_longo_prazo_com_janelas(dados_completos):
    if not dados_completos or len(dados_completos) < 30:
        return {"sucesso": False, "mensagem": "Base muito pequena para treinamento profundo."}
    motor = MotorV1Completo(dados_completos)
    motor.processar_auditoria()
    reforcar_aprendizado_tipo_d(motor.ia)
    motor.ia.mapear_padroes_avancados(dados_completos)
    seen = set()
    unique_patterns = []
    for p in motor.ia.memoria_padroes_vencedores:
        try:
            key = json.dumps(p, sort_keys=True)
            if key not in seen:
                seen.add(key)
                unique_patterns.append(p)
        except:
            unique_patterns.append(p)
    motor.ia.memoria_padroes_vencedores = unique_patterns
    sucesso_salvar = False
    for _ in range(3):
        sucesso_salvar = salvar_modelo_longo_prazo(motor.ia)
        if sucesso_salvar:
            ia_verif = carregar_modelo_longo_prazo()
            if ia_verif is not None:
                break
            else:
                sucesso_salvar = False
        time.sleep(0.6)
    stats = getattr(motor, 'stats', {"G0": 0, "G1": 0, "G2": 0, "FALHA": 0, "NO CALL": 0})
    total_janelas = sum(stats.values()) if stats else 0
    regras_boas = 0
    for regra, dados in motor.historico_regras.items():
        if dados["total"] >= 5 and (dados["acertos"] / dados["total"]) >= 0.55:
            regras_boas += 1
    taxa_g0_g1 = ((stats.get("G0", 0) + stats.get("G1", 0)) / total_janelas * 100) if total_janelas > 0 else 0
    analise_numeros = motor.ia.analisar_comportamento_pos_numero()
    return {
        "sucesso": True,
        "registros_processados": len(dados_completos),
        "janelas_analisadas": total_janelas,
        "G0": stats.get("G0", 0),
        "G1": stats.get("G1", 0),
        "G2": stats.get("G2", 0),
        "FALHA": stats.get("FALHA", 0),
        "NO CALL": stats.get("NO CALL", 0),
        "regras_com_boa_performance": regras_boas,
        "assertividade_g0_g1_percent": round(taxa_g0_g1, 2),
        "modelo_salvo_com_sucesso": sucesso_salvar,
        "analise_comportamento_numeros": analise_numeros,
        "ia_treinada": motor.ia,
        "mensagem": "Treinamento profundo concluído com sucesso."
    }

# ============================================================
# CLASSES PRINCIPAIS
# ============================================================

class MotorAnalise:
    @staticmethod
    def analisar_janela(sub_num, sub_pol, ia_modelo, base_longa=None, eh_sinal_real=False):
        resultado = {
            "camadas": [],
            "no_call": None,
            "geometria": None,
            "regras_posicionais": [],
            "contexto_avancado": {},
            "ia": {},
            "contexto_reversao": {},
            "controlador_retardador": {}
        }
        
        nc_ativo, motivo_nc = MotorNoCall.checar_no_call(sub_num, sub_pol)
        
        if eh_sinal_real and not nc_ativo and len(sub_num) >= 2:
            risco_ativo, motivo_risco = MotorNoCall.checar_risco_preditivo_g0(sub_num, ia_modelo)
            if risco_ativo:
                nc_ativo = True
                motivo_nc = motivo_risco
        
        entropia = 0.0
        if eh_sinal_real:
            entropia = EngineMatematicoAvancado.calcular_entropia_shannon(sub_pol)
            resultado["entropia"] = entropia
            if entropia > 1.52 and not nc_ativo:
                nc_ativo = True
                motivo_nc = f"Bloqueio de Segurança HMM: Entropia de Shannon em Nível Crítico de Caos ({entropia} Bits). O Mercado está Aleatório."
            
        resultado["no_call"] = {"ativo": nc_ativo, "motivo": motivo_nc}
        resultado["camadas"].append({
            "camada": 1, "nome": "Segurança e Proteção de Saldo (NO CALL)",
            "resultado": f"Ativo={nc_ativo}", "detalhe": motivo_nc,
            "impacto": "BLOQUEIO" if nc_ativo else "APROVADO"
        })
        
        if nc_ativo:
            resultado["probabilidade_markov"] = ia_modelo.calcular_probabilidade_exata_markov(sub_pol)
            return resultado
            
        modo_mercado = AnalisadorContextoAvancado.detectar_modo_mercado(sub_pol, eh_sinal_real, ia_modelo)
        geometria = AnalisadorContextoAvancado.mapear_padroes_geometria(sub_pol)
        
        resultado["geometria"] = geometria
        resultado["camadas"].append({
            "camada": 2, "nome": "Geometria de Mercado",
            "resultado": geometria, "detalhe": "Padrão geométrico detectado no gráfico",
            "impacto": "FORTE" if geometria in ["CICLO_FECHADO_VPPV", "CICLO_FECHADO_PVVP"] else "NEUTRO"
        })
        
        expectativas = MotorContagensProjetivas.mapear_janela(sub_num, sub_pol, geometria, ia_modelo)
        resultado["regras_posicionais"] = expectativas
        resultado["camadas"].append({
            "camada": 3, "nome": "Regras Posicionais Ativadas (Volumes 2 e 3)",
            "resultado": f"{len(expectativas)} regras ativas",
            "detalhe": [e["tipo_regra"] for e in expectativas] if expectativas else "Nenhuma detecção volumétrica",
            "impacto": "ALTO" if expectativas else "BAIXO"
        })
        
        resultado["contexto_avancado"] = {"modo_mercado": modo_mercado}
        resultado["camadas"].append({
            "camada": 4, "nome": "Contexto Avançado HMM (Hidden Markov Model)",
            "resultado": f"Modo: {modo_mercado}", "detalhe": "Detecção matemática de fase do algoritmo", "impacto": "MÉDIO"
        })
        
        contexto_para_ia = {
            "geometria": geometria,
            "regras_posicionais": expectativas,
            "controlador_retardador": {},
            "contexto_avancado": resultado["contexto_avancado"]
        }
        
        direcao_ia, conf_ia, raciocinio_ia = ia_modelo.predizer_proxima_casa(sub_num, sub_pol, contexto_para_ia)
        resultado["ia"] = {
            "direcao": direcao_ia,
            "confianca": conf_ia,
            "raciocinio": raciocinio_ia
        }
        resultado["camadas"].append({
            "camada": 5, "nome": "IA Preditiva Híbrida (XGBoost, LSTM, Z-Score)",
            "resultado": f"{direcao_ia} ({conf_ia}%)",
            "detalhe": raciocinio_ia,
            "impacto": "ALTO" if conf_ia >= 52 else "MÉDIO"
        })
        
        probabilidade_markov = ia_modelo.calcular_probabilidade_exata_markov(sub_pol)
        resultado["probabilidade_markov"] = probabilidade_markov
        
        if eh_sinal_real:
            resultado["camadas"].append({
                "camada": 5.5, "nome": "Validação Determinística (Cadeia de Markov Exata)",
                "resultado": f"V: {probabilidade_markov['V']}% | P: {probabilidade_markov['P']}%",
                "detalhe": "Cálculo matemático fechado do arquivo base (sem simulações aleatórias)",
                "impacto": "ALTO"
            })
            
        streak, xadrez_len, xadrez_quebrou, exaustao = MotorAnalise._calcular_contexto_reversao(sub_pol)
        resultado["contexto_reversao"] = {
            "streak": streak, "xadrez_len": xadrez_len,
            "xadrez_quebrou": xadrez_quebrou, "exaustao": exaustao
        }
        resultado["camadas"].append({
            "camada": 6, "nome": "Contexto de Reversão e Exaustão",
            "resultado": f"Streak atual: {streak}x | Tamanho do Xadrez: {xadrez_len}",
            "detalhe": f"Sinal de Exaustão de Padrão: {exaustao}",
            "impacto": "ALTO" if exaustao else "BAIXO"
        })
        
        ctrl_ret = MotorAnalise._detectar_controlador_retardador(
            sub_num, sub_pol, expectativas, geometria, modo_mercado, eh_sinal_real
        )
        resultado["controlador_retardador"] = ctrl_ret
        resultado["camadas"].append({
            "camada": 7, "nome": "Balança de Forças Operacionais (Controlador vs Retardador)",
            "resultado": ctrl_ret["dominancia"],
            "detalhe": f"Forças de Controle: {ctrl_ret['controladores']} | Forças de Retardo: {ctrl_ret['retardadores']}",
            "impacto": "ALTO"
        })
        return resultado

    @staticmethod
    def _calcular_contexto_reversao(sub_pol):
        streak = 0
        if sub_pol:
            ultima_cor = sub_pol[-1]
            for c in reversed(sub_pol):
                if c == ultima_cor:
                    streak += 1
                else:
                    break
        
        xadrez_len = 0
        for i in range(len(sub_pol)-1, 0, -1):
            if sub_pol[i] != sub_pol[i-1]:
                xadrez_len += 1
            else:
                break
        xadrez_quebrou = (sub_pol[-1] == sub_pol[-2]) if len(sub_pol) >= 2 else False
        exaustao = (streak >= 5) or (xadrez_len >= 5 and xadrez_quebrou)
        return streak, xadrez_len, xadrez_quebrou, exaustao

    @staticmethod
    def _detectar_controlador_retardador(sub_num, sub_pol, expectativas, geometria, modo_mercado, eh_sinal_real=False):
        controladores = []
        retardadores = []
        if geometria in ["CICLO_FECHADO_VPPV", "CICLO_FECHADO_PVVP"]:
            controladores.append("Geometria forte")
        if expectativas:
            controladores.append("Regras posicionais ativas")
            
        if eh_sinal_real:
            if "RECOLHIMENTO" in modo_mercado or "CAOS" in modo_mercado:
                retardadores.append("HMM Oculto detecta alta aleatoriedade (Modo Recolhimento da Máquina)")
        else:
            if "CHUVA" in modo_mercado:
                retardadores.append("Alta alternância (modo Chuva clássico)")
                
        if len(controladores) > len(retardadores):
            dominancia = "CONTROLADOR"
        elif len(retardadores) > len(controladores):
            dominancia = "RETARDADOR"
        else:
            dominancia = "NEUTRO"
        return {
            "controladores": controladores,
            "retardadores": retardadores,
            "dominancia": dominancia
        }


class IAPreditivaV1:
    def __init__(self, dados_longo_prazo, dados_recencia=None):
        self.dados_longo = dados_longo_prazo
        self.dados_recencia = dados_recencia if dados_recencia else []
        self.modelo_transicao = defaultdict(list)
        self.modelo_transicao_profundo = defaultdict(list)
        self.modelo_numerico = defaultdict(list)
        self.bigramas_numericos = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0, "prox_numero": defaultdict(int)})
        self.saturacao_ciclica = defaultdict(lambda: {"ciclos_V": [], "ciclos_P": [], "historico_distancias": []})
        self.dna_padroes = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        
        self.padroes_fechamento_numerico = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        
        # Mapeadores Globais (Até G1)
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        
        self.probabilidades_globais = {"streak_v_5": 0.0, "streak_p_5": 0.0, "xadrez_5": 0.0}

        self.unidade_analise = {}
        for n in range(15):
            self.unidade_analise[n] = {
                "ocorrencias": 0, "V": 0, "P": 0, "B": 0,
                "freq_v": 0.0, "freq_p": 0.0, "freq_b": 0.0,
                "estabilidade": "NEUTRO", "saturacao": "NORMAL",
                "enfraquecimento": "ESTÁVEL", "comportamento_dominante": "NEUTRO",
                "pos_numero_V": 0, "pos_numero_P": 0, "pos_numero_B": 0,
                "pos_numero_freq_v": 0.0, "pos_numero_freq_p": 0.0, "pos_numero_freq_b": 0.0,
                "comportamento_pos_numero": "NEUTRO", "retencao_media": 0,
                "ultimas_cores": []
            }
            
        self.xadrez_stats = {"quebras": 0, "continuacoes": 0, "numeros_quebradores": defaultdict(int)}
        self.streak_breaker_stats = {"V": defaultdict(int), "P": defaultdict(int)}
        self.color_ngrams = {1: defaultdict(int), 2: defaultdict(int), 3: defaultdict(int)}
        self.padroes_xadrez_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.padroes_streak_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.padroes_gerais_detalhado = defaultdict(fabrica_padrao_detalhado)
        self.memoria_padroes_vencedores = []
        self.historico_regras = defaultdict(fabrica_historico_regras_zerado)
        self.controladores_fortes = defaultdict(int)
        self.padroes_fortes = []
        self.analise_recencia = {}
        self.regime_recencia = None
        
        self.ml_ready = False
        self.ml_gb = None
        self.ml_mlp = None
        self.ml_hmm = None
        self.q_table = {}
        
        self._treinar_modelo_profundo()

    def __getstate__(self):
        state = self.__dict__.copy()
        if 'modelo_transicao' in state: state['modelo_transicao'] = dict(state['modelo_transicao'])
        if 'modelo_transicao_profundo' in state: state['modelo_transicao_profundo'] = dict(state['modelo_transicao_profundo'])
        if 'modelo_numerico' in state: state['modelo_numerico'] = dict(state['modelo_numerico'])
            
        if 'bigramas_numericos' in state:
            bn_save = {}
            for k, v in state['bigramas_numericos'].items():
                v_copy = v.copy()
                if 'prox_numero' in v_copy:
                    v_copy['prox_numero'] = dict(v_copy['prox_numero'])
                bn_save[k] = v_copy
            state['bigramas_numericos'] = bn_save
            
        if 'saturacao_ciclica' in state: state['saturacao_ciclica'] = {k: dict(v) for k, v in state['saturacao_ciclica'].items()}
        if 'dna_padroes' in state: state['dna_padroes'] = {k: dict(v) for k, v in state['dna_padroes'].items()}
        if 'padroes_fechamento_numerico' in state: state['padroes_fechamento_numerico'] = {k: dict(v) for k, v in state['padroes_fechamento_numerico'].items()}
        
        if 'estatisticas_projecoes_globais' in state: state['estatisticas_projecoes_globais'] = {k: dict(v) for k, v in state['estatisticas_projecoes_globais'].items()}
        if 'estatisticas_bigramas_globais' in state: state['estatisticas_bigramas_globais'] = dict(state['estatisticas_bigramas_globais'])
        if 'estatisticas_trigramas_globais' in state: state['estatisticas_trigramas_globais'] = dict(state['estatisticas_trigramas_globais'])
        
        if 'controladores_fortes' in state: state['controladores_fortes'] = dict(state['controladores_fortes'])
        if 'historico_regras' in state: state['historico_regras'] = dict(state['historico_regras'])
        if 'color_ngrams' in state: state['color_ngrams'] = {k: dict(v) for k, v in state['color_ngrams'].items()}
        
        if 'xadrez_stats' in state and isinstance(state['xadrez_stats'], dict):
            xs = state['xadrez_stats'].copy()
            if 'numeros_quebradores' in xs: xs['numeros_quebradores'] = dict(xs['numeros_quebradores'])
            state['xadrez_stats'] = xs
            
        if 'streak_breaker_stats' in state and isinstance(state['streak_breaker_stats'], dict):
            ss = state['streak_breaker_stats'].copy()
            for cor_k in ss: ss[cor_k] = dict(ss[cor_k])
            state['streak_breaker_stats'] = ss
            
        for d_name in ['padroes_xadrez_detalhado', 'padroes_streak_detalhado', 'padroes_gerais_detalhado']:
            if d_name in state:
                pd_dict = {}
                for k, v in state[d_name].items():
                    v_copy = v.copy()
                    if 'quebradores' in v_copy: v_copy['quebradores'] = dict(v_copy['quebradores'])
                    pd_dict[k] = v_copy
                state[d_name] = pd_dict
                
        if 'q_table' in state: state['q_table'] = dict(state['q_table'])
        
        if 'ml_gb' in state: del state['ml_gb']
        if 'ml_mlp' in state: del state['ml_mlp']
        if 'ml_hmm' in state: del state['ml_hmm']
        
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self.modelo_transicao = defaultdict(list, state.get('modelo_transicao', {}))
        self.modelo_transicao_profundo = defaultdict(list, state.get('modelo_transicao_profundo', {}))
        self.modelo_numerico = defaultdict(list, state.get('modelo_numerico', {}))
        
        bigramas_loaded = state.get('bigramas_numericos', {})
        self.bigramas_numericos = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0, "prox_numero": defaultdict(int)})
        for k, v in bigramas_loaded.items():
            self.bigramas_numericos[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0), "prox_numero": defaultdict(int, v.get("prox_numero", {}))}

        saturacao_loaded = state.get('saturacao_ciclica', {})
        self.saturacao_ciclica = defaultdict(lambda: {"ciclos_V": [], "ciclos_P": [], "historico_distancias": []})
        for k, v in saturacao_loaded.items(): self.saturacao_ciclica[k] = {"ciclos_V": v.get("ciclos_V", []), "ciclos_P": v.get("ciclos_P", []), "historico_distancias": v.get("historico_distancias", [])}
            
        dna_loaded = state.get('dna_padroes', {})
        self.dna_padroes = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        for k, v in dna_loaded.items(): self.dna_padroes[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0)}
            
        pfn_loaded = state.get('padroes_fechamento_numerico', {})
        self.padroes_fechamento_numerico = defaultdict(lambda: {"V": 0, "P": 0, "B": 0, "total": 0})
        for k, v in pfn_loaded.items(): self.padroes_fechamento_numerico[k] = {"V": v.get("V",0), "P": v.get("P",0), "B": v.get("B",0), "total": v.get("total",0)}
            
        epg_loaded = state.get('estatisticas_projecoes_globais', {})
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        for k, v in epg_loaded.items(): self.estatisticas_projecoes_globais[int(k)] = {"total": v.get("total",0), "g0": v.get("g0",0), "g1": v.get("g1",0), "falha": v.get("falha",0)}
            
        ebg_loaded = state.get('estatisticas_bigramas_globais', {})
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        for k, v in ebg_loaded.items(): self.estatisticas_bigramas_globais[k] = {"total": v.get("total",0), "V_g0": v.get("V_g0",0), "V_g1": v.get("V_g1",0), "P_g0": v.get("P_g0",0), "P_g1": v.get("P_g1",0)}

        etg_loaded = state.get('estatisticas_trigramas_globais', {})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        for k, v in etg_loaded.items(): self.estatisticas_trigramas_globais[k] = {"total": v.get("total",0), "V_g0": v.get("V_g0",0), "V_g1": v.get("V_g1",0), "P_g0": v.get("P_g0",0), "P_g1": v.get("P_g1",0)}
            
        self.probabilidades_globais = state.get('probabilidades_globais', {"streak_v_5": 0.0, "streak_p_5": 0.0, "xadrez_5": 0.0})
        self.controladores_fortes = defaultdict(int, state.get('controladores_fortes', {}))
        self.historico_regras = defaultdict(fabrica_historico_regras_zerado)
        for k, v in state.get('historico_regras', {}).items(): self.historico_regras[k] = {"acertos": v.get("acertos", 0), "total": v.get("total", 0)}
        c_grams = state.get('color_ngrams', {1: {}, 2: {}, 3: {}})
        self.color_ngrams = {k: defaultdict(int, v) for k, v in c_grams.items()}
        
        x_st = state.get('xadrez_stats', {})
        self.xadrez_stats = {"quebras": x_st.get("quebras", 0), "continuacoes": x_st.get("continuacoes", 0), "numeros_quebradores": defaultdict(int, x_st.get("numeros_quebradores", {}))}
        
        s_st = state.get('streak_breaker_stats', {"V": {}, "P": {}})
        self.streak_breaker_stats = {"V": defaultdict(int, s_st.get("V", {})), "P": defaultdict(int, s_st.get("P", {}))}
        
        for d_name in ['padroes_xadrez_detalhado', 'padroes_streak_detalhado', 'padroes_gerais_detalhado']:
            if d_name in state:
                pd_dict = {}
                for k, v in state[d_name].items():
                    v_copy = v.copy()
                    if 'quebradores' in v_copy: v_copy['quebradores'] = dict(v_copy['quebradores'])
                    pd_dict[k] = v_copy
                state[d_name] = pd_dict
                
        if 'q_table' in state: state['q_table'] = dict(state['q_table'])
        
        if 'ml_gb' in state: del state['ml_gb']
        if 'ml_mlp' in state: del state['ml_mlp']
        if 'ml_hmm' in state: del state['ml_hmm']
        
        return state

    def _treinar_modelo_profundo(self):
        if self.dados_longo and len(self.dados_longo) >= 5:
            self._processar_bloco_dados(self.dados_longo, 1, True)
            self._calcular_probabilidades_globais_cache()
        if self.dados_recencia and len(self.dados_recencia) >= 5:
            self._processar_bloco_dados(self.dados_recencia, 4, True)
            
        todos_dados = (self.dados_longo or []) + (self.dados_recencia or [])
        if todos_dados:
            self._mapear_projecoes_globais(todos_dados)
            self._treinar_ml_avancado(todos_dados)

    def _treinar_ml_avancado(self, dados):
        if not HAS_ML or len(dados) < 50:
            return
            
        X = []
        y = []
        seq_hmm = []
        
        c_map = {'P': 0, 'V': 1, 'B': 2}
        for d in dados:
            seq_hmm.append([c_map.get(d['cor'], 2)])
            
        try:
            self.ml_hmm = CategoricalHMM(n_components=3, n_iter=100)
            if len(seq_hmm) > 50:
                self.ml_hmm.fit(np.array(seq_hmm))
        except:
            self.ml_hmm = None

        for i in range(len(dados) - 12):
            janela = dados[i:i+12]
            alvo = dados[i+12]['cor']
            pol = [d['cor'] for d in janela]
            num = [d['numero'] for d in janela]

            if alvo in ['V', 'P']:
                entropia = EngineMatematicoAvancado.calcular_entropia_shannon(pol)
                prob_markov = self.calcular_probabilidade_exata_markov(pol)
                freq_v = pol.count('V')/12.0
                
                # --- SUPERCÉREBRO UNIFICADO: Ingestão de Heurística ---
                geometria = AnalisadorContextoAvancado.mapear_padroes_geometria(pol)
                geo_val = 1 if geometria == "CICLO_FECHADO_PVVP" else (-1 if geometria == "CICLO_FECHADO_VPPV" else 0)
                
                expectativas = MotorContagensProjetivas.mapear_janela(num, pol, geometria, self)
                peso_v = sum(3 if any(k in e["tipo_regra"] for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e["direcao"] == "VERMELHO")
                peso_p = sum(3 if any(k in e["tipo_regra"] for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e["direcao"] == "PRETO")
                regra_val = peso_v - peso_p
                
                quebrador_val = 0
                if hasattr(self, 'verificar_quebrador_historico'):
                    eh_q, dir_q, _ = self.verificar_quebrador_historico(num, pol)
                    if eh_q:
                        quebrador_val = 1 if dir_q == "VERMELHO" else -1

                features = [entropia, prob_markov['V'], prob_markov['P'], num[-1], num[-2], freq_v, geo_val, regra_val, quebrador_val]
                X.append(features)
                y.append(1 if alvo == 'V' else 0)

        if len(X) > 20:
            try:
                self.ml_gb = GradientBoostingClassifier(n_estimators=150, learning_rate=0.05, max_depth=4)
                self.ml_gb.fit(X, y)

                self.ml_mlp = MLPClassifier(hidden_layer_sizes=(64, 32), activation='relu', max_iter=800)
                self.ml_mlp.fit(X, y)

                self.ml_ready = True
            except Exception as e:
                print(f"Erro no treino das Redes Neurais/XGBoost: {e}")
                self.ml_ready = False

    def atualizar_q_learning(self, estado_str, acao, recompensa):
        if not hasattr(self, 'q_table'):
            self.q_table = {}
        if estado_str not in self.q_table:
            self.q_table[estado_str] = {"APOSTAR": 0.0, "NO_CALL": 0.0}
            
        alpha = 0.1
        current_q = self.q_table[estado_str][acao]
        self.q_table[estado_str][acao] = current_q + alpha * (recompensa - current_q)

    def _mapear_projecoes_globais(self, dados):
        if not dados or len(dados) < 10: return
        self.estatisticas_projecoes_globais = {n: {"total": 0, "g0": 0, "g1": 0, "falha": 0} for n in range(1, 8)}
        self.estatisticas_bigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        self.estatisticas_trigramas_globais = defaultdict(lambda: {"total": 0, "V_g0": 0, "V_g1": 0, "P_g0": 0, "P_g1": 0})
        
        total_dados = len(dados)
        for i in range(total_dados):
            num = dados[i]['numero']
            
            # 1. Projeções Volume 3 (1 a 7) - Sempre alvo Vermelho (até G1)
            if 1 <= num <= 7:
                passo = num
                alvo_idx = i + passo
                if alvo_idx + 1 < total_dados:
                    caminho_tem_branco = False
                    for k in range(i + 1, alvo_idx):
                        if dados[k]['cor'] == 'B':
                            caminho_tem_branco = True
                            break
                    if not caminho_tem_branco:
                        cor_alvo = dados[alvo_idx]['cor']
                        if cor_alvo in ['V', 'B']:
                            self.estatisticas_projecoes_globais[num]["g0"] += 1
                            self.estatisticas_projecoes_globais[num]["total"] += 1
                        else:
                            cor_g1 = dados[alvo_idx + 1]['cor']
                            if cor_g1 in ['V', 'B']:
                                self.estatisticas_projecoes_globais[num]["g1"] += 1
                                self.estatisticas_projecoes_globais[num]["total"] += 1
                            else:
                                self.estatisticas_projecoes_globais[num]["falha"] += 1
                                self.estatisticas_projecoes_globais[num]["total"] += 1

            # 2. Bigramas Globais (Até G1 para ambas as cores)
            if i >= 1 and i + 2 < total_dados:
                bigrama = f"{dados[i-1]['numero']}-{dados[i]['numero']}"
                c0 = dados[i+1]['cor']
                c1 = dados[i+2]['cor']
                self.estatisticas_bigramas_globais[bigrama]["total"] += 1
                if c0 in ['V', 'B']: self.estatisticas_bigramas_globais[bigrama]["V_g0"] += 1
                elif c1 in ['V', 'B']: self.estatisticas_bigramas_globais[bigrama]["V_g1"] += 1
                
                if c0 in ['P', 'B']: self.estatisticas_bigramas_globais[bigrama]["P_g0"] += 1
                elif c1 in ['P', 'B']: self.estatisticas_bigramas_globais[bigrama]["P_g1"] += 1

            # 3. Trigramas Globais (Até G1 para ambas as cores)
            if i >= 2 and i + 2 < total_dados:
                trigrama = f"{dados[i-2]['numero']}-{dados[i-1]['numero']}-{dados[i]['numero']}"
                c0 = dados[i+1]['cor']
                c1 = dados[i+2]['cor']
                self.estatisticas_trigramas_globais[trigrama]["total"] += 1
                if c0 in ['V', 'B']: self.estatisticas_trigramas_globais[trigrama]["V_g0"] += 1
                elif c1 in ['V', 'B']: self.estatisticas_trigramas_globais[trigrama]["V_g1"] += 1
                
                if c0 in ['P', 'B']: self.estatisticas_trigramas_globais[trigrama]["P_g0"] += 1
                elif c1 in ['P', 'B']: self.estatisticas_trigramas_globais[trigrama]["P_g1"] += 1

    def _calcular_probabilidades_globais_cache(self):
        self.probabilidades_globais["streak_v_5"] = self.calcular_probabilidade_streak_empirica('V', 5)
        self.probabilidades_globais["streak_p_5"] = self.calcular_probabilidade_streak_empirica('P', 5)
        self.probabilidades_globais["xadrez_5"] = self.calcular_probabilidade_xadrez_empirica(5)

    def mapear_padroes_avancados(self, dados):
        if not dados or len(dados) < 10: return
        cores = [d['cor'] for d in dados]
        numeros = [d['numero'] for d in dados]
        rastreio_numeros = {}
        for i in range(len(dados) - 1):
            num = numeros[i]
            cor_post = cores[i+1]
            if num not in rastreio_numeros:
                rastreio_numeros[num] = {"sequencia_atual": cor_post, "contagem": 1}
            else:
                if rastreio_numeros[num]["sequencia_atual"] == cor_post:
                    rastreio_numeros[num]["contagem"] += 1
                else:
                    cor_quebrada = rastreio_numeros[num]["sequencia_atual"]
                    tamanho_ciclo = rastreio_numeros[num]["contagem"]
                    if cor_quebrada == "V": self.saturacao_ciclica[num]["ciclos_V"].append(tamanho_ciclo)
                    elif cor_quebrada == "P": self.saturacao_ciclica[num]["ciclos_P"].append(tamanho_ciclo)
                    rastreio_numeros[num] = {"sequencia_atual": cor_post, "contagem": 1}

        i = 0
        while i < len(cores) - 4:
            janela = cores[i:i+4]
            if all(janela[j] != janela[j-1] for j in range(1, 4)) and 'B' not in janela:
                if i + 4 < len(cores):
                    proximo_cor = cores[i+4]
                    num_quebra = numeros[i+3]
                    chave = "XADREZ_4"
                    self.padroes_xadrez_detalhado[chave]["total"] += 1
                    self.padroes_xadrez_detalhado[chave][f"apos_{proximo_cor}"] += 1
                    if proximo_cor != janela[-1]: self.padroes_xadrez_detalhado[chave]["quebradores"][num_quebra] += 1
                    c1 = cores[i+4] if i+4 < len(cores) else None
                    c2 = cores[i+5] if i+5 < len(cores) else None
                    c3 = cores[i+6] if i+6 < len(cores) else None
                    if "_futuros" not in self.padroes_xadrez_detalhado[chave]: self.padroes_xadrez_detalhado[chave]["_futuros"] = []
                    self.padroes_xadrez_detalhado[chave]["_futuros"].append((c1, c2, c3))
            i += 1
        i = 0
        while i < len(cores) - 3:
            if cores[i] == cores[i+1] == cores[i+2] and cores[i] != 'B':
                if i + 3 < len(cores):
                    proximo_cor = cores[i+3]
                    num_quebra = numeros[i+3]
                    chave = "STREAK_3"
                    self.padroes_streak_detalhado[chave]["total"] += 1
                    self.padroes_streak_detalhado[chave][f"apos_{proximo_cor}"] += 1
                    if proximo_cor != cores[i]: self.padroes_streak_detalhado[chave]["quebradores"][num_quebra] += 1
                    c1 = cores[i+3] if i+3 < len(cores) else None
                    c2 = cores[i+4] if i+4 < len(cores) else None
                    c3 = cores[i+5] if i+5 < len(cores) else None
                    if "_futuros" not in self.padroes_streak_detalhado[chave]: self.padroes_streak_detalhado[chave]["_futuros"] = []
                    self.padroes_streak_detalhado[chave]["_futuros"].append((c1, c2, c3))
            i += 1
        for tam in range(3, 11):
            i = 0
            while i <= len(cores) - tam - 1:
                janela_cores = cores[i:i+tam]
                janela_nums = numeros[i:i+tam]
                if 'B' in janela_cores:
                    i += 1
                    continue
                proxima_cor = cores[i+tam]
                num_quebra = numeros[i+tam-1]
                janela_str = "-".join(janela_cores)
                
                chave_dna = "-".join(map(str, janela_nums))
                self.dna_padroes[chave_dna]["total"] += 1
                self.dna_padroes[chave_dna][proxima_cor] += 1
                
                eh_streak = len(set(janela_cores)) == 1
                eh_xadrez = all(janela_cores[j] != janela_cores[j-1] for j in range(1, tam))
                eh_duplo = False
                if tam >= 4 and tam % 2 == 0:
                    metade = tam // 2
                    if len(set(janela_cores[:metade])) == 1 and len(set(janela_cores[metade:])) == 1 and janela_cores[0] != janela_cores[metade]:
                        eh_duplo = True
                eh_espelho_normal = all(janela_cores[j] == janela_cores[tam-1-j] for j in range(tam)) and not eh_streak
                eh_espelho_invertido = all(janela_cores[j] != janela_cores[tam-1-j] for j in range(tam)) and not eh_xadrez
                if eh_streak: tipo_prefix = f"STREAK_{tam}"
                elif eh_xadrez: tipo_prefix = f"XADREZ_{tam}"
                elif eh_duplo: tipo_prefix = f"DUPLO_{tam}"
                elif eh_espelho_normal: tipo_prefix = f"ESPELHO_NORMAL_{tam}"
                elif eh_espelho_invertido: tipo_prefix = f"ESPELHO_INVERTIDO_{tam}"
                else: tipo_prefix = f"PADRAO_GERAL_{tam}"
                
                chave = f"{tipo_prefix} [{janela_str}]"
                self.padroes_gerais_detalhado[chave]["total"] += 1
                self.padroes_gerais_detalhado[chave][f"apos_{proxima_cor}"] += 1
                if eh_streak and proxima_cor != janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                elif eh_xadrez and proxima_cor == janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                elif (eh_duplo or eh_espelho_normal or eh_espelho_invertido) and proxima_cor != janela_cores[-1]: self.padroes_gerais_detalhado[chave]["quebradores"][num_quebra] += 1
                
                c1 = cores[i+tam] if i+tam < len(cores) else None
                c2 = cores[i+tam+1] if i+tam+1 < len(cores) else None
                c3 = cores[i+tam+2] if i+tam+2 < len(cores) else None
                if "_futuros" not in self.padroes_gerais_detalhado[chave]: self.padroes_gerais_detalhado[chave]["_futuros"] = []
                self.padroes_gerais_detalhado[chave]["_futuros"].append((c1, c2, c3))
                i += 1
        for i in range(len(cores)):
            self.color_ngrams[1][cores[i]] += 1
            if i + 1 < len(cores): self.color_ngrams[2][f"{cores[i]}-{cores[i+1]}"] += 1
            if i + 2 < len(cores): self.color_ngrams[3][f"{cores[i]}-{cores[i+1]}-{cores[i+2]}"] += 1
        for dic in [self.padroes_xadrez_detalhado, self.padroes_streak_detalhado, self.padroes_gerais_detalhado]:
            for chave, info in list(dic.items()):
                v = info.get("apos_V", 0)
                p = info.get("apos_P", 0)
                if v == 0 and p == 0: continue
                cor_alvo = "V" if v >= p else "P"
                for c1, c2, c3 in info.get("_futuros", []):
                    if c1 == cor_alvo or c1 == "B": info["g0"] += 1
                    elif c2 == cor_alvo or c2 == "B": info["g1"] += 1
                if "_futuros" in info: del info["_futuros"]

    def _processar_bloco_dados(self, dados, multiplicador_peso, treinamento_profundo=False):
        if not dados or len(dados) < 3: return
        total_dados = len(dados)
        
        for i in range(total_dados - 4):
            estado_2 = (dados[i+2]['cor'], dados[i+3]['cor'])
            estado_4 = (dados[i]['cor'], dados[i+1]['cor'], dados[i+2]['cor'], dados[i+3]['cor'])
            prox = dados[i+4]['cor']
            num = dados[i+3]['numero']
            fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
            peso_final = max(1, int(multiplicador_peso * fator_temporal))
            for _ in range(peso_final):
                self.modelo_transicao[estado_2].append(prox)
                self.modelo_transicao_profundo[estado_4].append(prox)
                self.modelo_numerico[num].append(prox)

        for i in range(total_dados - 1):
            num = int(dados[i]['numero'])
            cor_post = str(dados[i+1]['cor']).upper()
            if 0 <= num <= 14 and cor_post in ['V', 'P', 'B']:
                self.unidade_analise[num]["ocorrencias"] += multiplicador_peso
                self.unidade_analise[num][cor_post] += multiplicador_peso
                self.unidade_analise[num][f"pos_numero_{cor_post}"] += multiplicador_peso
                self.unidade_analise[num]["ultimas_cores"].append(cor_post)
                if len(self.unidade_analise[num]["ultimas_cores"]) > 10:
                    self.unidade_analise[num]["ultimas_cores"].pop(0)
                    
        for i in range(total_dados - 2):
            num1 = int(dados[i]['numero'])
            num2 = int(dados[i+1]['numero'])
            prox_num = int(dados[i+2]['numero'])
            if num1 != num2 and 0 <= num1 <= 14 and 0 <= num2 <= 14:
                cor_proxima = str(dados[i+2]['cor']).upper()
                if cor_proxima in ['V', 'P', 'B']:
                    chave_dupla = f"{num1}-{num2}"
                    fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
                    peso_final = max(1, int(multiplicador_peso * fator_temporal))
                    self.bigramas_numericos[chave_dupla]["total"] += peso_final
                    self.bigramas_numericos[chave_dupla][cor_proxima] += peso_final
                    self.bigramas_numericos[chave_dupla]["prox_numero"][prox_num] += peso_final
                    
        for tam_padrao in [3, 4, 5]:
            for i in range(total_dados - tam_padrao):
                janela_cores = [dados[k]['cor'] for k in range(i, i+tam_padrao)]
                if 'B' not in janela_cores:
                    padrao_str = "".join(janela_cores)
                    ultimo_num = dados[i+tam_padrao-1]['numero']
                    penultimo_num = dados[i+tam_padrao-2]['numero']
                    cor_post = dados[i+tam_padrao]['cor']
                    chave_num = f"PADRAO_{padrao_str}_{ultimo_num}"
                    chave_bigrama = f"PADRAO_{padrao_str}_{penultimo_num}-{ultimo_num}"
                    fator_temporal = 1.0 + ((i / total_dados) * 1.5) if treinamento_profundo and total_dados > 1000 else 1.0
                    peso_final = max(1, int(multiplicador_peso * fator_temporal))
                    self.padroes_fechamento_numerico[chave_num]["total"] += peso_final
                    self.padroes_fechamento_numerico[chave_num][cor_post] += peso_final
                    self.padroes_fechamento_numerico[chave_bigrama]["total"] += peso_final
                    self.padroes_fechamento_numerico[chave_bigrama][cor_post] += peso_final
                    
        for n in range(15):
            total = self.unidade_analise[n]["ocorrencias"]
            if total > 0:
                self.unidade_analise[n]["freq_v"] = round((self.unidade_analise[n]["V"] / total) * 100, 2)
                self.unidade_analise[n]["freq_p"] = round((self.unidade_analise[n]["P"] / total) * 100, 2)
                self.unidade_analise[n]["freq_b"] = round((self.unidade_analise[n]["B"] / total) * 100, 2)
                self.unidade_analise[n]["comportamento_dominante"] = self._calcular_comportamento_dominante(n)
                self.unidade_analise[n]["estabilidade"] = self._calcular_estabilidade(n)
                self.unidade_analise[n]["enfraquecimento"] = self._calcular_enfraquecimento(n)
                self.unidade_analise[n]["saturacao"] = self._calcular_saturacao(n)

    def _calcular_comportamento_dominante(self, num):
        freq_v = self.unidade_analise[num]["freq_v"]
        freq_p = self.unidade_analise[num]["freq_p"]
        if freq_v > freq_p + 8: return "VERMELHO"
        elif freq_p > freq_v + 8: return "PRETO"
        return "NEUTRO"

    def _calcular_estabilidade(self, num):
        ultimas = self.unidade_analise[num]["ultimas_cores"]
        if len(ultimas) < 5: return "NEUTRO"
        dominante = self.unidade_analise[num]["comportamento_dominante"]
        if dominante == "NEUTRO": return "NEUTRO"
        count = sum(1 for c in ultimas if c == ('V' if dominante == "VERMELHO" else 'P'))
        taxa = count / len(ultimas)
        if taxa >= 0.7: return "ESTÁVEL"
        elif taxa <= 0.4: return "INSTÁVEL"
        return "NEUTRO"

    def _calcular_enfraquecimento(self, num):
        return "ENFRAQUECIDO" if self.unidade_analise[num]["estabilidade"] == "INSTÁVEL" else "ESTÁVEL"

    def _calcular_saturacao(self, num):
        total = self.unidade_analise[num]["ocorrencias"]
        if total > 800: return "ALTA"
        elif total > 400: return "MÉDIA"
        return "BAIXA"

    def injetar_aprendizado_imediato(self, sub_dados, multiplicador_peso=4, analise_contexto=None, salvar_na_recencia=True):
        if salvar_na_recencia:
            self.dados_recencia.extend(sub_dados)
        self._processar_bloco_dados(sub_dados, multiplicador_peso, True)
        if analise_contexto:
            for regra in analise_contexto.get("regras_posicionais", []):
                self.historico_regras[regra.get("tipo_regra", "DESCONHEVIDO")]["total"] += 1

    def registrar_padrao_vencedor(self, analise_contexto, resultado):
        if resultado not in ["G0", "G1"]: return
        padrao = {
            "geometria": analise_contexto.get("geometria"),
            "regras_ativas": [r.get("tipo_regra") for r in analise_contexto.get("regras_posicionais", [])],
            "controlador_dominante": analise_contexto.get("controlador_retardador", {}).get("dominancia"),
            "modo_mercado": analise_contexto.get("contexto_avancado", {}).get("modo_mercado"),
            "entropia_shannon": analise_contexto.get("entropia_shannon", 0.0),
            "monte_carlo_indicou": analise_contexto.get("monte_carlo_indicou"),
            "resultado": resultado,
            "peso": 1
        }
        if padrao not in self.memoria_padroes_vencedores:
            self.memoria_padroes_vencedores.append(padrao)
        if len(self.memoria_padroes_vencedores) > 50:
            self.memoria_padroes_vencedores.pop(0)

    def calcular_bonus_memoria(self, analise_contexto):
        bonus = 0
        entropia_atual = analise_contexto.get("entropia_shannon", 0.0)
        for padrao in self.memoria_padroes_vencedores:
            match = 0
            if padrao.get("geometria") == analise_contexto.get("geometria"): match += 8
            comuns = set(padrao.get("regras_ativas", [])) & set([r.get("tipo_regra") for r in analise_contexto.get("regras_posicionais", [])])
            match += len(comuns) * 3
            if padrao.get("entropia_shannon", 0.0) > 0:
                if abs(padrao.get("entropia_shannon", 0.0) - entropia_atual) <= 0.2: match += 5
            if match >= 12: bonus += 4
        return min(bonus, 22)
        
    def calcular_probabilidade_exata_markov(self, ultimas_cores):
        if not ultimas_cores or len(ultimas_cores) < 2:
            return {"V": 0.0, "P": 0.0, "B": 0.0}
            
        estado_inicial_2 = (ultimas_cores[-2], ultimas_cores[-1])
        estado_inicial_4 = tuple(ultimas_cores[-4:]) if len(ultimas_cores) >= 4 else None
        
        transicoes_4 = self.modelo_transicao_profundo.get(estado_inicial_4, []) if estado_inicial_4 else []
        transicoes_2 = self.modelo_transicao.get(estado_inicial_2, [])
        
        resultados = {'V': 0, 'P': 0, 'B': 0}
        if transicoes_4:
            for cor in transicoes_4: resultados[cor] += 2 
        if transicoes_2:
             for cor in transicoes_2: resultados[cor] += 1 
                
        total = sum(resultados.values())
        if total == 0: return {"V": 0.0, "P": 0.0, "B": 0.0}
        
        return {
            "V": round((resultados['V'] / total) * 100, 2),
            "P": round((resultados['P'] / total) * 100, 2),
            "B": round((resultados['B'] / total) * 100, 2)
        }

    def _calcular_z_score(self, sucessos, tentativas, probabilidade_esperada=0.4667):
        if tentativas == 0: return 0.0
        proporcao_real = sucessos / tentativas
        desvio_padrao = math.sqrt((probabilidade_esperada * (1 - probabilidade_esperada)) / tentativas)
        if desvio_padrao == 0: return 0.0
        z_score = (proporcao_real - probabilidade_esperada) / desvio_padrao
        return z_score

    def verificar_quebrador_historico(self, sub_num, sub_pol):
        if len(sub_num) < 3: return False, "NEUTRO", ""
        ultimo_num = sub_num[-1]
        for tam in range(10, 2, -1):
            if len(sub_pol) < tam: continue
            janela_cores = sub_pol[-tam:]
            janela_str = "-".join(janela_cores)
            eh_streak = len(set(janela_cores)) == 1
            eh_xadrez = all(janela_cores[j] != janela_cores[j-1] for j in range(1, tam))
            eh_duplo = False
            if tam >= 4 and tam % 2 == 0:
                metade = tam // 2
                if len(set(janela_cores[:metade])) == 1 and len(set(janela_cores[metade:])) == 1 and janela_cores[0] != janela_cores[metade]:
                    eh_duplo = True
            eh_espelho_normal = all(janela_cores[j] == janela_cores[tam-1-j] for j in range(tam)) and not eh_streak
            eh_espelho_invertido = all(janela_cores[j] != janela_cores[tam-1-j] for j in range(tam)) and not eh_xadrez
            if eh_streak: tipo_prefix = f"STREAK_{tam}"
            elif eh_xadrez: tipo_prefix = f"XADREZ_{tam}"
            elif eh_duplo: tipo_prefix = f"DUPLO_{tam}"
            elif eh_espelho_normal: tipo_prefix = f"ESPELHO_NORMAL_{tam}"
            elif eh_espelho_invertido: tipo_prefix = f"ESPELHO_INVERTIDO_{tam}"
            else: tipo_prefix = f"PADRAO_GERAL_{tam}"
            chave = f"{tipo_prefix} [{janela_str}]"
            info = self.padroes_gerais_detalhado.get(chave)
            if info and info["total"] >= 2:
                quebras = info["quebradores"].get(ultimo_num, 0)
                if quebras >= 2 and (quebras / info["total"]) >= 0.4:
                    direcao_inversao = "PRETO" if janela_cores[-1] == "V" else "VERMELHO"
                    return True, direcao_inversao, f"Quebrador Histórico Detectado: Número {ultimo_num} rompe o {chave}"
        return False, "NEUTRO", ""

    def predizer_proxima_casa(self, sub_num, sub_pol, analise_contexto=None):
        if len(sub_num) < 12:
            return "NEUTRO", 0.0, "Janela insuficiente"
        
        ultimo_num = sub_num[-1]
        penultimo_num = sub_num[-2]
        
        ultimas_cores_2 = (sub_pol[-2], sub_pol[-1])
        ultimas_cores_4 = tuple(sub_pol[-4:]) if len(sub_pol) >= 4 else None
        
        trans_2 = self.modelo_transicao.get(ultimas_cores_2, [])
        trans_4 = self.modelo_transicao_profundo.get(ultimas_cores_4, []) if hasattr(self, 'modelo_transicao_profundo') else []
        
        por_num = self.modelo_numerico.get(ultimo_num, [])
        stats = self.unidade_analise.get(ultimo_num, {"freq_v": 0, "freq_p": 0})
        
        v_bonus = stats.get("freq_v", 0) * 3.5
        p_bonus = stats.get("freq_p", 0) * 3.5

        if hasattr(self, 'estatisticas_trigramas_globais') and len(sub_num) >= 3:
            trigrama_atual = f"{sub_num[-3]}-{sub_num[-2]}-{sub_num[-1]}"
            stats_tri = self.estatisticas_trigramas_globais.get(trigrama_atual)
            if stats_tri and stats_tri["total"] >= 5:
                taxa_v_tri = ((stats_tri["V_g0"] + stats_tri["V_g1"]) / stats_tri["total"]) * 100
                taxa_p_tri = ((stats_tri["P_g0"] + stats_tri["P_g1"]) / stats_tri["total"]) * 100
                if taxa_v_tri >= 60.0: v_bonus += 25
                elif taxa_v_tri < 45.0: v_bonus -= 15
                if taxa_p_tri >= 60.0: p_bonus += 25
                elif taxa_p_tri < 45.0: p_bonus -= 15

        if hasattr(self, 'estatisticas_bigramas_globais') and len(sub_num) >= 2:
            bigrama_atual = f"{sub_num[-2]}-{sub_num[-1]}"
            stats_bi = self.estatisticas_bigramas_globais.get(bigrama_atual)
            if stats_bi and stats_bi["total"] >= 5:
                taxa_v_bi = ((stats_bi["V_g0"] + stats_bi["V_g1"]) / stats_bi["total"]) * 100
                taxa_p_bi = ((stats_bi["P_g0"] + stats_bi["P_g1"]) / stats_bi["total"]) * 100
                if taxa_v_bi >= 55.0: v_bonus += 18
                elif taxa_v_bi < 45.0: v_bonus -= 10
                if taxa_p_bi >= 55.0: p_bonus += 18
                elif taxa_p_bi < 45.0: p_bonus -= 10
        
        if hasattr(self, 'estatisticas_projecoes_globais') and analise_contexto:
            regras_ativas = analise_contexto.get("regras_posicionais", [])
            for r in regras_ativas:
                if r.get("tipo_regra", "").startswith("V3_ATIVADOR_"):
                    try:
                        num_projetivo = int(r["tipo_regra"].split("_")[-1])
                        stats_proj = self.estatisticas_projecoes_globais.get(num_projetivo)
                        if stats_proj and stats_proj["total"] >= 10:
                            taxa_global = ((stats_proj["g0"] + stats_proj["g1"]) / stats_proj["total"]) * 100
                            if taxa_global >= 55.0: v_bonus += 20
                            elif taxa_global < 45.0: v_bonus -= 20
                    except: pass
        
        dna_3 = "-".join(map(str, sub_num[-3:]))
        if hasattr(self, 'dna_padroes') and dna_3 in self.dna_padroes:
            dna_stats = self.dna_padroes[dna_3]
            if dna_stats["total"] >= 5: 
                prob_dna_v = (dna_stats["V"] / dna_stats["total"]) * 100
                prob_dna_p = (dna_stats["P"] / dna_stats["total"]) * 100
                z_score_v = self._calcular_z_score(dna_stats["V"], dna_stats["total"])
                z_score_p = self._calcular_z_score(dna_stats["P"], dna_stats["total"])
                if prob_dna_v >= 60.0 and z_score_v > 1.64: v_bonus += 25
                elif prob_dna_p >= 60.0 and z_score_p > 1.64: p_bonus += 25

        if penultimo_num != ultimo_num:
            chave_dupla = f"{penultimo_num}-{ultimo_num}"
            stats_dupla = self.bigramas_numericos.get(chave_dupla)
            if stats_dupla and stats_dupla["total"] >= 5:
                prob_v_dupla = (stats_dupla["V"] / stats_dupla["total"]) * 100
                prob_p_dupla = (stats_dupla["P"] / stats_dupla["total"]) * 100
                z_score_v = self._calcular_z_score(stats_dupla["V"], stats_dupla["total"])
                z_score_p = self._calcular_z_score(stats_dupla["P"], stats_dupla["total"])
                if prob_v_dupla > 55.0 and z_score_v > 1.64: v_bonus += 18
                elif prob_p_dupla > 55.0 and z_score_p > 1.64: p_bonus += 18

        if hasattr(self, 'padroes_fechamento_numerico'):
            aplicou_destrinchador = False
            for tam in [5, 4, 3]:
                if len(sub_pol) >= tam and not aplicou_destrinchador:
                    padrao_atual = "".join(sub_pol[-tam:])
                    if 'B' not in padrao_atual:
                        chave_num = f"PADRAO_{padrao_atual}_{ultimo_num}"
                        chave_bigrama = f"PADRAO_{padrao_atual}_{penultimo_num}-{ultimo_num}"
                        stats_bigrama = self.padroes_fechamento_numerico.get(chave_bigrama)
                        if stats_bigrama and stats_bigrama["total"] >= 3:
                            prob_v = (stats_bigrama["V"] / stats_bigrama["total"]) * 100
                            prob_p = (stats_bigrama["P"] / stats_bigrama["total"]) * 100
                            z_score_v = self._calcular_z_score(stats_bigrama["V"], stats_bigrama["total"])
                            z_score_p = self._calcular_z_score(stats_bigrama["P"], stats_bigrama["total"])
                            if prob_v >= 55.0 and z_score_v > 1.28:
                                v_bonus += 45
                                aplicou_destrinchador = True
                            elif prob_p >= 55.0 and z_score_p > 1.28:
                                p_bonus += 45
                                aplicou_destrinchador = True
                        if not aplicou_destrinchador:
                            stats_num = self.padroes_fechamento_numerico.get(chave_num)
                            if stats_num and stats_num["total"] >= 3:
                                prob_v = (stats_num["V"] / stats_num["total"]) * 100
                                prob_p = (stats_num["P"] / stats_num["total"]) * 100
                                z_score_v = self._calcular_z_score(stats_num["V"], stats_num["total"])
                                z_score_p = self._calcular_z_score(stats_num["P"], stats_num["total"])
                                if prob_v >= 55.0 and z_score_v > 1.28:
                                    v_bonus += 35
                                    aplicou_destrinchador = True
                                elif prob_p >= 55.0 and z_score_p > 1.28:
                                    p_bonus += 35
                                    aplicou_destrinchador = True

        comportamento = stats.get("comportamento_dominante", "NEUTRO")
        estabilidade = stats.get("estabilidade", "NEUTRO")
        enfraquecimento = stats.get("enfraquecimento", "ESTÁVEL")
        if comportamento == "VERMELHO": v_bonus += 12
        elif comportamento == "PRETO": p_bonus += 12
        if estabilidade == "ESTÁVEL":
            if comportamento == "VERMELHO": v_bonus += 10
            elif comportamento == "PRETO": p_bonus += 10
        elif estabilidade == "INSTÁVEL":
            v_bonus -= 8
            p_bonus -= 8
            
        has_rec = len(self.dados_recencia) > 0
        p_trans_4 = 0.30 if has_rec else 0.25
        p_trans_2 = 0.12 if has_rec else 0.10
        p_num = 0.15 if has_rec else 0.14
        
        v_deep = (trans_4.count('V') * p_trans_4) if trans_4 else 0
        p_deep = (trans_4.count('P') * p_trans_4) if trans_4 else 0
        
        total_v = v_deep + (trans_2.count('V') * p_trans_2) + (por_num.count('V') * p_num) + v_bonus
        total_p = p_deep + (trans_2.count('P') * p_trans_2) + (por_num.count('P') * p_num) + p_bonus
        
        prob_v_heuristica = (total_v / (total_v + total_p)) * 100 if (total_v + total_p) > 0 else 0
        prob_p_heuristica = (total_p / (total_v + total_p)) * 100 if (total_v + total_p) > 0 else 0

        if getattr(self, 'ml_ready', False) and HAS_ML:
            try:
                entropia = EngineMatematicoAvancado.calcular_entropia_shannon(sub_pol)
                prob_markov = self.calcular_probabilidade_exata_markov(sub_pol)
                freq_v = sub_pol.count('V') / 12.0
                
                # Supercérebro Unificado: Injeção de Features Heurísticas e de Padrões
                geo_val = 0
                regra_val = 0
                quebrador_val = 0
                
                if analise_contexto:
                    geometria = analise_contexto.get("geometria", "ESTÁVEL")
                    geo_val = 1 if geometria == "CICLO_FECHADO_PVVP" else (-1 if geometria == "CICLO_FECHADO_VPPV" else 0)
                    
                    expectativas = analise_contexto.get("regras_posicionais", [])
                    peso_v = sum(3 if any(k in e.get("tipo_regra", "") for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e.get("direcao") == "VERMELHO")
                    peso_p = sum(3 if any(k in e.get("tipo_regra", "") for k in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]) else 1 for e in expectativas if e.get("direcao") == "PRETO")
                    regra_val = peso_v - peso_p

                if hasattr(self, 'verificar_quebrador_historico'):
                    eh_q, dir_q, _ = self.verificar_quebrador_historico(sub_num, sub_pol)
                    if eh_q:
                        quebrador_val = 1 if dir_q == "VERMELHO" else -1

                features = [[entropia, prob_markov['V'], prob_markov['P'], sub_num[-1], sub_num[-2], freq_v, geo_val, regra_val, quebrador_val]]
                
                prob_gb = self.ml_gb.predict_proba(features)[0]
                prob_mlp = self.ml_mlp.predict_proba(features)[0]
                
                ml_v_val = ((prob_gb[1] + prob_mlp[1]) / 2.0) * 100
                ml_p_val = ((prob_gb[0] + prob_mlp[0]) / 2.0) * 100
                
                BARREIRA = 52.5
                if ml_v_val >= BARREIRA and ml_v_val > ml_p_val:
                    return "VERMELHO", round(ml_v_val, 1), f"Supercérebro Unificado (Deep Learning + Heurística): Detectou Padrão para V ({ml_v_val:.1f}%)"
                elif ml_p_val >= BARREIRA and ml_p_val > ml_v_val:
                    return "PRETO", round(ml_p_val, 1), f"Supercérebro Unificado (Deep Learning + Heurística): Detectou Padrão para P ({ml_p_val:.1f}%)"
                else:
                    return "NEUTRO", round(max(ml_v_val, ml_p_val), 1), "Supercérebro Unificado: Conflito multidimensional. Risco elevado, abortar entrada."
            except Exception as e:
                pass

        BARREIRA = 52.5
        if prob_v_heuristica >= BARREIRA and prob_v_heuristica > prob_p_heuristica + 4:
            return "VERMELHO", round(prob_v_heuristica, 1), f"Confluência de Heurística e Z-Score ({prob_v_heuristica:.1f}%)"
        elif prob_p_heuristica >= BARREIRA and prob_p_heuristica > prob_v_heuristica + 4:
            return "PRETO", round(prob_p_heuristica, 1), f"Confluência de Heurística e Z-Score ({prob_p_heuristica:.1f}%)"
        return "NEUTRO", round(max(prob_v_heuristica, prob_p_heuristica), 1), "Sem confluência clara"

    def calcular_probabilidade_streak_empirica(self, cor, k):
        todos = (self.dados_longo or []) + (self.dados_recencia or [])
        if len(todos) < k + 1: return 0.0
        total = len(todos) - k
        count = sum(1 for i in range(total) if all(d['cor'] == cor for d in todos[i:i+k]))
        return round((count / total) * 100, 2) if total > 0 else 0.0

    def calcular_probabilidade_xadrez_empirica(self, k):
        todos = (self.dados_longo or []) + (self.dados_recencia or [])
        if len(todos) < k + 1: return 0.0
        total = len(todos) - k
        count = 0
        for i in range(total):
            janela = [d['cor'] for d in todos[i:i+k]]
            if all(janela[j] != janela[j-1] for j in range(1, len(janela))):
                count += 1
        return round((count / total) * 100, 2) if total > 0 else 0.0

    def analisar_comportamento_pos_numero_recencia(self, dados_recencia):
        if not dados_recencia or len(dados_recencia) < 30: return {"mensagem": "Base muito pequena"}
        relatorio = {}
        contagem = {n: {"total": 0, "pos_V": 0, "pos_P": 0, "pos_B": 0} for n in range(15)}
        for i in range(len(dados_recencia) - 1):
            num = dados_recencia[i]['numero']
            cor_proxima = dados_recencia[i + 1]['cor']
            contagem[num]["total"] += 1
            if cor_proxima == "V": contagem[num]["pos_V"] += 1
            elif cor_proxima == "P": contagem[num]["pos_P"] += 1
            else: contagem[num]["pos_B"] += 1
        for num in range(15):
            dados = contagem[num]
            if dados["total"] == 0: continue
            total = dados["total"]
            cores = {"VERMELHO": dados["pos_V"], "PRETO": dados["pos_P"], "BRANCO": dados["pos_B"]}
            cor_dominante = max(cores, key=cores.get)
            freq = round((cores[cor_dominante] / total) * 100, 2)
            relatorio[num] = {
                "total_aparicoes_recencia": total, "cor_mais_frequente_apos": cor_dominante,
                "frequencia_cor_dominante_%": freq, "tendencia_recente": "FORTE" if freq >= 65 else ("MODERADA" if freq >= 55 else "FRACA")
            }
        return relatorio

    def analisar_comportamento_pos_numero(self):
        relatorio = {}
        for num in range(15):
            dados = self.unidade_analise[num]
            total = dados["ocorrencias"]
            if total == 0: continue
            cores_pos = {"VERMELHO": dados["pos_numero_V"], "PRETO": dados["pos_numero_P"], "BRANCO": dados["pos_numero_B"]}
            cor_dominante = max(cores_pos, key=cores_pos.get)
            freq_dominante = round((cores_pos[cor_dominante] / total) * 100, 2)
            ultimas = dados["ultimas_cores"]
            if len(ultimas) >= 8:
                ultimas_dominantes = sum(1 for c in ultimas if c == ('V' if cor_dominante == "VERMELHO" else 'P'))
                taxa_ultimas = ultimas_dominantes / len(ultimas)
                if taxa_ultimas < 0.5: tendencia = "EM MUDANÇA / SATURAÇÃO POSSÍVEL"
                elif taxa_ultimas >= 0.75: tendencia = "ESTÁVEL"
                else: tendencia = "MODERADO"
            else: tendencia = "DADOS INSUFICIENTES"
            relatorio[num] = {
                "total_aparicoes": total, "cor_mais_frequente_apos": cor_dominante,
                "frequencia_cor_dominante_%": freq_dominante, "distribuicao_pos": cores_pos,
                "comportamento_dominante": dados["comportamento_dominante"], "estabilidade": dados["estabilidade"],
                "saturacao": dados["saturacao"], "tendencia_recente": tendencia
            }
        return relatorio


class MotorNoCall:
    @staticmethod
    def checar_no_call(sub_num, sub_pol):
        cenarios_duplas = [(7, 8), (8, 9), (9, 10), (10, 11)]
        for idx1, idx2 in cenarios_duplas:
            if sub_num[idx1] == sub_num[idx2]:
                return True, "Volume 2 Cap 6: Trava das Duplas Ativa"
        posicoes_criticas_6 = [5, 8, 9, 10, 11]
        for pos in posicoes_criticas_6:
            if sub_num[pos] == 6:
                return True, "Volume 2 Cap 4: Trava Número 6 (Posição de No Call Ativa)"
        posicoes_criticas_2 = [8, 9, 10, 11]
        for pos in posicoes_criticas_2:
            if sub_num[pos] == 2:
                return True, "Volume 2 Cap 3: Trava Número 2"
        posicoes_criticas_b = [5, 8, 9, 10, 11]
        for pos in posicoes_criticas_b:
            if sub_pol[pos] == "B":
                return True, "Volume 2 Cap 5: Trava do Branco"
        return False, "Evento Neutro Operacional"

    @staticmethod
    def checar_risco_preditivo_g0(sub_num, ia_modelo):
        if len(sub_num) < 2 or not hasattr(ia_modelo, 'bigramas_numericos'): return False, ""
        penultimo_num, ultimo_num = sub_num[-2], sub_num[-1]
        chave_dupla = f"{penultimo_num}-{ultimo_num}"
        stats_dupla = ia_modelo.bigramas_numericos.get(chave_dupla)
        if not stats_dupla or stats_dupla["total"] == 0: return False, ""
        total_ocorrencias = stats_dupla["total"]
        prox_numeros_historico = stats_dupla.get("prox_numero", {})
        chance_6 = (prox_numeros_historico.get(6, 0) / total_ocorrencias) * 100
        chance_2 = (prox_numeros_historico.get(2, 0) / total_ocorrencias) * 100
        chance_repeticao = (prox_numeros_historico.get(ultimo_num, 0) / total_ocorrencias) * 100
        LIMITE_RISCO = 15.0
        if chance_6 >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco crítico de {chance_6:.1f}% do número 6 cair no G0."
        if chance_2 >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco crítico de {chance_2:.1f}% do número 2 cair no G0."
        if chance_repeticao >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco de {chance_repeticao:.1f}% de dupla repetida."
        return False, ""


class JuizHierarquicoModificado:
    @staticmethod
    def arbitrar_sinal(no_call_ativo, motivo_nc, expectations, inclinacao_num, geometria_mercado, 
                       previsao_ia, status_inversao, historico_regras,
                       modo_mercado="NEUTRO", 
                       streak_atual=0, xadrez_len=0, xadrez_quebrou=False,
                       contexto_exaustao=False, sintese_evidencias=None,
                       probabilidade_markov=None, ia_modelo=None, entropia_shannon=0.0):
        if no_call_ativo:
            return "NO CALL", motivo_nc, "SISTEMA_TRAVADO"
            
        if ia_modelo and hasattr(ia_modelo, 'q_table'):
            estado_rl = f"HMM_{modo_mercado}_Entropia_{round(entropia_shannon, 1)}"
            if estado_rl in ia_modelo.q_table:
                q_apostar = ia_modelo.q_table[estado_rl]["APOSTAR"]
                q_no_call = ia_modelo.q_table[estado_rl]["NO_CALL"]
                if q_no_call > q_apostar + 0.3:
                    return "NO CALL", f"Agente RL Autônomo VETOU: Operar nesse cenário tem ROI negativo histórico (Q-Value: {q_apostar:.2f})", "VETO_RL"

        direcao_ia, confianca_ia, raciocinio_ia = previsao_ia
        
        # TRATAMENTO DA COLISÃO DE MOTORES (NO CALL) DO CONSENSO DINÂMICO
        if direcao_ia == "NO CALL":
            return "NO CALL", raciocinio_ia, "COLISAO_MOTORES"
        
        bonus_memoria = 0
        if direcao_ia == "NEUTRO" and ia_modelo and hasattr(ia_modelo, 'calcular_bonus_memoria'):
            contexto_memoria = {
                "geometria": geometria_mercado,
                "regras_posicionais": expectations,
                "entropia_shannon": entropia_shannon
            }
            bonus_memoria = ia_modelo.calcular_bonus_memoria(contexto_memoria)

        sinal_preliminar = "NEUTRO"
        motivo_preliminar = ""
        regra_preliminar = ""
        
        tem_quebrador_historico = any("QUEBRADOR" in e.get("tipo_regra", "") for e in expectations)
        
        if direcao_ia != "NEUTRO" and confianca_ia >= 52.5:
            sinal_preliminar = direcao_ia
            motivo_preliminar = raciocinio_ia
            regra_preliminar = "IA_PREDITIVA"
        elif tem_quebrador_historico:
            dir_inversao = next((e["direcao"] for e in expectations if "QUEBRADOR" in e["tipo_regra"] and e["direcao"] != "NEUTRO"), "NO CALL")
            if dir_inversao != "NO CALL":
                sinal_preliminar = dir_inversao
                motivo_preliminar = "Ação de Quebrador Histórico (O número rompe o padrão atual)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "QUEBRADOR_HISTORICO"
        elif geometria_mercado == "CICLO_FECHADO_VPPV":
            sinal_preliminar = "PRETO"
            motivo_preliminar = "Geometria VPPV Clássica"
            if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
            regra_preliminar = "GEOMETRIA_FORTE"
        elif geometria_mercado == "CICLO_FECHADO_PVVP":
            sinal_preliminar = "VERMELHO"
            motivo_preliminar = "Geometria PVVP Clássica"
            if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
            regra_preliminar = "GEOMETRIA_FORTE"
        elif expectations:
            peso_v = 0
            peso_p = 0
            for item in expectations:
                peso_regra = 1
                if any(key in item["tipo_regra"] for key in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]):
                    peso_regra = 3
                
                if item["direcao"] == "VERMELHO":
                    peso_v += peso_regra
                elif item["direcao"] == "PRETO":
                    peso_p += peso_regra

            if peso_v > peso_p:
                sinal_preliminar = "VERMELHO"
                motivo_preliminar = "Regra posicional majoritária (Ponderada)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "REGRA_POSICIONAL"
            elif peso_p > peso_v:
                sinal_preliminar = "PRETO"
                motivo_preliminar = "Regra posicional majoritária (Ponderada)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "REGRA_POSICIONAL"
                
        if sinal_preliminar == "NEUTRO":
            return "NO CALL", "Ausência de dominância clara. Sistema abortou a entrada por neutralidade.", "FALLBACK_NO_CALL"
            
        return sinal_preliminar, motivo_preliminar, regra_preliminar


class MotorContagensProjetivas:
    @staticmethod
    def mapear_janela(sub_num, sub_pol, geometry_mercado, ia_modelo=None):
        lista_bruta = []
        REGRAS_PROJECAO = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7}
        for i in range(12):
            num_atual = sub_num[i]
            if num_atual in REGRAS_PROJECAO:
                passo = REGRAS_PROJECAO[num_atual]
                alvo_idx = i + passo
                if alvo_idx in (11, 12) and not any(sub_num[k] == 0 for k in range(i, 12)):
                    lista_bruta.append({"direcao": "VERMELHO", "tipo_regra": f"V3_ATIVADOR_{num_atual}", "origem": f"Volume 3"})
        par_fechamento = (sub_num[10], sub_num[11])
        continuidade_preta_validas = [(8,9), (9,10), (10,11), (11,12), (12,13), (13,14), (14,13), (13,12), (12,11), (11,10)]
        continuidade_vermelha_validas = [(1,2), (2,3), (3,4), (4,5), (5,6), (6,7), (7,6), (6,5), (5,4), (4,3)]
        if par_fechamento in continuidade_preta_validas: lista_bruta.append({"direcao": "PRETO", "tipo_regra": "V2_CONTINUIDADE_PRETA", "origem": "Volume 2"})
        elif par_fechamento in continuidade_vermelha_validas: lista_bruta.append({"direcao": "VERMELHO", "tipo_regra": "V2_CONTINUIDADE_VERMELHA", "origem": "Volume 2"})
        if sub_num[11] in [3, 4, 5] and sub_pol[10] == sub_pol[11]:
            direcao = "VERMELHO" if sub_pol[11] == "V" else "PRETO"
            lista_bruta.append({"direcao": direcao, "tipo_regra": "ASSUNCAO_CONTAGEM_FINAL", "origem": "Assunção"})
        
        if ia_modelo and hasattr(ia_modelo, 'verificar_quebrador_historico'):
            eh_quebrador, dir_quebra, motivo_quebra = ia_modelo.verificar_quebrador_historico(sub_num, sub_pol)
            if eh_quebrador:
                lista_bruta.append({"direcao": dir_quebra, "tipo_regra": "QUEBRADOR_HISTORICO_ATIVO", "origem": "IA_Quebradores"})
        
        return lista_bruta


class AnalisadorContextoAvancado:
    @staticmethod
    def mapear_padroes_geometria(sub_pol):
        texto = "".join(sub_pol)
        if texto.endswith("VPPV"): return "CICLO_FECHADO_VPPV"
        if texto.endswith("PVVP"): return "CICLO_FECHADO_PVVP"
        if "VVVV" in texto: return "SATURAÇÃO ESTRUTURAL (V)"
        if "PPPP" in texto: return "SATURAÇÃO ESTRUTURAL (P)"
        if "VPVP" in texto or "PVPV" in texto: return "XADREZ ATIVO"
        return "ESTÁVEL"

    @staticmethod
    def detectar_modo_mercado(sub_pol, eh_sinal_real=False, ia_modelo=None):
        if ia_modelo and getattr(ia_modelo, 'ml_ready', False) and HAS_ML and getattr(ia_modelo, 'ml_hmm', None):
            try:
                c_map = {'P': 0, 'V': 1, 'B': 2}
                seq = [[c_map.get(c, 2)] for c in sub_pol]
                estado_oculto = ia_modelo.ml_hmm.predict(seq)[-1]
                regimes = {0: "HMM_CONSOLIDACAO (Estável)", 1: "HMM_TENDENCIA (Surfe)", 2: "HMM_CAOS (Recolhimento)"}
                return regimes.get(estado_oculto, "NEUTRO")
            except: pass

        texto = "".join(sub_pol)
        alternancias = sum(1 for i in range(len(texto)-1) if texto[i] != texto[i+1])
        if eh_sinal_real:
            if alternancias >= 7: return "REGIME_RECOLHIMENTO"
            elif alternancias <= 3: return "REGIME_PAGADOR"
            return "NEUTRO"
        else:
            if alternancias >= 7: return "CHUVA"
            elif alternancias <= 3: return "RECUPERACAO"
            return "NEUTRO"


class LeitorXLS:
    def __init__(self, caminho_arquivo):
        self.caminho = caminho_arquivo

    def ler_e_validar(self):
        if not os.path.exists(self.caminho): return None
        try:
            df = pd.read_excel(self.caminho)
            df.columns = [str(col).strip().lower() for col in df.columns]
            col_num = None
            for possible in ['número', 'numero', 'num', 'number', 'result']:
                if possible in df.columns:
                    col_num = possible
                    break
            if col_num is None:
                for col in df.columns:
                    if df[col].dtype in ['int64', 'float64']:
                        col_num = col
                        break
            if col_num is None: return None
            df = df.rename(columns={col_num: 'numero'})
            df = df.iloc[::-1].reset_index(drop=True)
            if len(df) < 5: return None
            dados = []
            for _, row in df.iterrows():
                try:
                    num = int(float(row['numero']))
                    if num == 0: cor = 'B'
                    elif 1 <= num <= 7: cor = 'V'
                    elif 8 <= num <= 14: cor = 'P'
                    else: continue
                    dados.append({"numero": num, "cor": cor})
                except: continue
            return dados if len(dados) >= 5 else None
        except Exception as e:
            print(f"[LeitorXLS] Erro: {e}")
            return None


class SequenciaOperacional:
    def __init__(self, lista_resultados):
        self.cronologia = lista_resultados
        self.numerica = [int(r['numero']) for r in self.cronologia]
        self.polaridades = [str(r['cor']).upper() for r in self.cronologia]
        self.total = len(self.numerica)


class MotorV1Completo:
    def __init__(self, lista_dados_xls, ia_existente=None):
        self.seq = SequenciaOperacional(lista_dados_xls)
        self.dados_longo = lista_dados_xls
        
        # UNIFICAÇÃO DE CÉREBROS: Impede que o TIPO D crie um "Cérebro Zerado" ao auditar Recência.
        global motor_unificado
        if ia_existente is not None: 
            self.ia = ia_existente
        elif 'motor_unificado' in globals() and motor_unificado.ia is not None and len(lista_dados_xls) <= 1000:
            self.ia = motor_unificado.ia
        else:
            base_recencia = None
            if os.path.exists("base_recencia_ativa.xlsx"):
                try: base_recencia = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
                except: pass
            self.ia = IAPreditivaV1(self.dados_longo, base_recencia if base_recencia else [])
            
        self.historico_regras = defaultdict(fabrica_historico_regras_auditado)
        self.stats = {"G0": 0, "G1": 0, "G2": 0, "FALHA": 0, "NO CALL": 0}

    def processar_auditoria(self):
        idx = 0
        memorias = []
        stats = {"G0": 0, "G1": 0, "G2": 0, "FALHA": 0, "NO CALL": 0}

        while idx + 12 < self.seq.total:
            sub_num = self.seq.numerica[idx:idx+12]
            sub_pol = self.seq.polaridades[idx:idx+12]
            analise = MotorAnalise.analisar_janela(sub_num, sub_pol, self.ia, eh_sinal_real=False)

            regra_id = "NENHUMA"

            if analise["no_call"]["ativo"]:
                sinal = "NO CALL"
                justificativa = analise["no_call"]["motivo"]
                regra_id = "SISTEMA_TRAVADO"
            else:
                geometria = analise["geometria"]
                expectativas = analise["regras_posicionais"]
                direcao_ia = analise["ia"]["direcao"]
                conf_ia = analise["ia"]["confianca"]
                raciocinio_ia = analise["ia"]["raciocinio"]
                streak = analise["contexto_reversao"]["streak"]
                xadrez_len = analise["contexto_reversao"]["xadrez_len"]
                xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
                contexto_exaustao = analise["contexto_reversao"]["exaustao"]
                modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
                
                sinal, justificativa, regra_id = JuizHierarquicoModificado.arbitrar_sinal(
                    no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, 
                    geometria_mercado=geometria, previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), 
                    status_inversao=None, historico_regras=self.historico_regras, modo_mercado=modo_mercado,
                    streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
                    contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
                    ia_modelo=self.ia, entropia_shannon=analise.get("entropia", 0.0)
                )

            correcoes = self.seq.polaridades[idx+12 : idx+15]
            classificacao = "FALHA"
            salto = 3

            if sinal == "NO CALL":
                classificacao = "NO CALL"
                salto = 1
            else:
                letra = "V" if sinal == "VERMELHO" else "P"
                for g, cor in enumerate(correcoes):
                    if cor == letra or cor == "B":
                        classificacao = f"G{g}"
                        salto = g + 1
                        break

            stats[classificacao] = stats.get(classificacao, 0) + 1

            # =========================================================
            # INJEÇÃO RL (Q-LEARNING) DURANTE A AUDITORIA HISTÓRICA
            # =========================================================
            if self.ia is not None:
                entropia_shannon_atual = analise.get("entropia", 0.0)
                modo_mercado_atual = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
                
                estado_rl_historico = f"HMM_{modo_mercado_atual}_Entropia_{round(entropia_shannon_atual, 1)}"
                acao_rl_historico = "APOSTAR" if sinal != "NO CALL" else "NO_CALL"
                
                recompensa = 0.0
                if classificacao in ["G0", "G1"]:
                    recompensa = 1.0
                elif classificacao == "G2":
                    recompensa = -0.5
                elif classificacao == "FALHA":
                    recompensa = -2.0
                    
                self.ia.atualizar_q_learning(estado_rl_historico, acao_rl_historico, recompensa)
            # =========================================================

            if classificacao in ["G0", "G1"]:
                contexto_analise = {
                    "geometria": analise.get("geometria"),
                    "regras_posicionais": analise.get("regras_posicionais"),
                    "controlador_retardador": analise.get("controlador_retardador", {}),
                    "contexto_avancado": {"modo_mercado": analise.get("contexto_avancado", {}).get("modo_mercado", "NEUTRO")}
                }
                self.ia.registrar_padrao_vencedor(contexto_analise, classificacao)

            if regra_id not in ["NENHUMA", "SISTEMA_TRAVADO"]:
                self.historico_regras[regra_id]["total"] += 1
                if classificacao in ["G0", "G1"]:
                    self.historico_regras[regra_id]["acertos"] += 1

            bloco = [{"numero": self.seq.numerica[k], "cor": self.seq.polaridades[k]} for k in range(idx, min(idx + 12 + salto, self.seq.total))]
            contexto_injecao = {
                "regras_posicionais": analise.get("regras_posicionais", []),
                "controlador_retardador": analise.get("controlador_retardador", {}),
                "geometria": analise.get("geometria", "ESTÁVEL")
            }
            self.ia.injetar_aprendizado_imediato(bloco, 4, contexto_injecao, salvar_na_recencia=False)
            memorias.append(f"Janela {len(memorias)+1}: {sub_num} -> {sinal} | {justificativa} | {classificacao}")
            idx += 12 + salto

        self.stats = stats
        total_janelas = sum(stats.values())
        denom = total_janelas if total_janelas > 0 else 1
        
        output = "[MEMÓRIA DE CÁLCULO DAS JANELAS MÓVEIS]\n"
        output += "\n".join(memorias) + "\n\n"
        output += "[RESULTADO FINAL TIPO D]\n"
        output += f"CRONOLOGIA VALIDADA: {self.seq.total} Resultados\n"
        output += f"TOTAL DE JANELAS AUDITADAS: {len(memorias)}\n"
        output += f" - Taxa G0: {stats.get('G0',0)} Ocorrências ({(stats.get('G0',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa G1: {stats.get('G1',0)} Ocorrências ({(stats.get('G1',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa G2: {stats.get('G2',0)} Ocorrências ({(stats.get('G2',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa de Falha: {stats.get('FALHA',0)} Ocorrências ({(stats.get('FALHA',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa de NO CALL: {stats.get('NO CALL',0)} Ocorrências ({(stats.get('NO CALL',0)/denom)*100:.2f}%)\n\n"
        
        if stats.get("FALHA", 0) >= 25:
            condicao = "MERCADO EM DEGRADAÇÃO"
        elif stats.get("G0", 0) >= 50:
            condicao = "MERCADO PAGADOR"
        else:
            condicao = "MERCADO INSTÁVEL"
            
        output += f"ESTADO ATUAL DO MERCADO: {condicao}\n"
        return output


class ProcessadorTipoB:
    def __init__(self, sequencia_12_numeros, caminho_base_dados):
        self.entrada = sequencia_12_numeros
        self.caminho_base = caminho_base_dados
        self.polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12_numeros]

    def executar_sinal_real(self):
        if len(self.entrada) != 12: return {"erro": "Necessário exatamente 12 números"}
        ia = carregar_modelo_longo_prazo()
        if ia is None:
            base = LeitorXLS(self.caminho_base).ler_e_validar()
            if not base: return {"erro": "Base de dados não encontrada"}
            ia = IAPreditivaV1(base, None)
        regime_rec = None
        if os.path.exists("base_recencia_ativa.xlsx"):
            base_rec = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
            if base_rec:
                ia = integrating_recencia_no_modelo(base_rec, 5)
                regime_rec = ia.regime_recencia
                
        analise = MotorAnalise.analisar_janela(self.entrada, self.polaridades, ia, eh_sinal_real=True)
        
        nc_ativo = analise["no_call"]["ativo"]
        motivo_nc = analise["no_call"]["motivo"]
        geometria = analise["geometria"]
        expectativas = analise["regras_posicionais"]
        direcao_ia = analise["ia"]["direcao"] if not nc_ativo else "NEUTRO"
        conf_ia = analise["ia"]["confianca"] if not nc_ativo else 0.0
        raciocinio_ia = analise["ia"]["raciocinio"] if not nc_ativo else motivo_nc
        streak = analise["contexto_reversao"]["streak"]
        xadrez_len = analise["contexto_reversao"]["xadrez_len"]
        xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
        contexto_exaustao = analise["contexto_reversao"]["exaustao"]
        modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
        raciocinio_trace = analise["camadas"]
        
        if nc_ativo:
            return {
                "sinal": "NO CALL", "justificativa": motivo_nc, "no_call": True, "regime_recencia": regime_rec,
                "motivo_real": f"NO CALL: {motivo_nc}", "regra_id": "SISTEMA_TRAVADO",
                "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")
            }
            
        sinal_final, justificativa_final, regra_id_final = JuizHierarquicoModificado.arbitrar_sinal(
            no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, geometria_mercado=geometria,
            previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), status_inversao=None, historico_regras=ia.historico_regras if ia else {},
            modo_mercado=modo_mercado, streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
            contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
            ia_modelo=ia, entropia_shannon=analise.get("entropia", 0.0)
        )

        if sinal_final != "NO CALL" and streak >= 6:
            sinal_final = "NO CALL"
            justificativa_final = f"Veto de streak {streak}x (segurança anti-tendência)"
            regra_id_final = "VETO_STREAK"
            
        return {
            "sinal": sinal_final, "justificativa": justificativa_final, "confianca_ia": round(conf_ia, 2),
            "no_call": False, "regime_recencia": regime_rec, "motivo_real": justificativa_final,
            "raciocinio_trace": raciocinio_trace, "decisao_final": {"sinal": sinal_final, "justificativa": justificativa_final, "regra_id": regra_id_final},
            "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")
        }


class EngineMatematicoAvancado:
    @staticmethod
    def calcular_entropia_shannon(sub_pol):
        if not sub_pol: return 0.0
        total = len(sub_pol)
        counts = {'V': sub_pol.count('V'), 'P': sub_pol.count('P'), 'B': sub_pol.count('B')}
        entropia = 0.0
        for cor, count in counts.items():
            if count > 0:
                p = count / total
                entropia -= p * math.log2(p)
        return round(entropia, 3)

    @staticmethod
    def calcular_kelly(probabilidade_vitoria_percent, house_edge_compensacao=False):
        if probabilidade_vitoria_percent < 50.0: return 0.0
        prob = probabilidade_vitoria_percent / 100.0
        q = 1.0 - prob
        b = 1.0 
        f_star = (prob * b - q) / b
        return round(max(0.0, f_star / 2.0) * 100.0, 2)

    @staticmethod
    def calcular_raridade_sequencia(sub_pol):
        if not sub_pol: return {"streak": 0, "probabilidade": 100.0, "status": "SEM DADOS"}
        ultima_cor = sub_pol[-1]
        if ultima_cor not in ['V', 'P']: return {"streak": 0, "probabilidade": 100.0, "status": "BRANCO NO FECHAMENTO"}
        streak = 0
        for cor in reversed(sub_pol):
            if cor == ultima_cor: streak += 1
            else: break
        probabilidade_sequencia = ((7 / 15) ** streak) * 100
        status = "SATURAÇÃO CRÍTICA" if streak >= 5 else ("DESVIO PADRÃO EM CURSO" if streak >= 3 else "ESTRUTURA DENTRO DA NORMALIDADE")
        return {"streak": streak, "cor_sequencia": "VERMELHO" if ultima_cor == 'V' else "PRETO", "probabilidade": round(probabilidade_sequencia, 2), "status": status}

    @staticmethod
    def calcular_vies_surfe(caminho_base, janela=100):
        leitor = LeitorXLS(caminho_base)
        dados = leitor.ler_e_validar()
        if not dados: return {"vies": "INDISPONÍVEL", "desvio_v": 0.0, "desvio_p": 0.0, "frequencia_v": 46.67, "frequencia_p": 46.67, "frequencia_b": 6.67}
        ultimos = dados[-janela:]
        v = sum(1 for d in ultimos if d['cor'] == 'V')
        p = sum(1 for d in ultimos if d['cor'] == 'P')
        b = sum(1 for d in ultimos if d['cor'] == 'B')
        pct_v = (v / len(ultimos)) * 100
        pct_p = (p / len(ultimos)) * 100
        pct_b = (b / len(ultimos)) * 100
        desvio_v = round(pct_v - 46.67, 2)
        desvio_p = round(pct_p - 46.67, 2)
        vies = "SURFE DE MACROFREQUÊNCIA: VIÁS PARA VERMELHO ATIVO" if pct_v >= 53.0 else ("SURFE DE MACROFREQUÊNCIA: VIÁS PARA PRETO ATIVO" if pct_p >= 53.0 else "MACROANÁLISE EQUILIBRADA")
        return {"frequencia_v": round(pct_v, 2), "frequencia_p": round(pct_p, 2), "frequencia_b": round(pct_b, 2), "desvio_v": desvio_v, "desvio_p": desvio_p, "vies": vies}

    @staticmethod
    def simular_split_stake_cobertura(stake_principal=10.0):
        stake_branco_ideal = round(stake_principal / 7.0, 2)
        stake_branco_conservador = round(stake_principal / 10.0, 2)
        custo_total = stake_principal + stake_branco_ideal
        lucro_liquido = round((stake_branco_ideal * 14) - custo_total, 2)
        return {"stake_cor": stake_principal, "cobertura_b_ideal_1_7": stake_branco_ideal, "cobertura_b_matematica_1_10": stake_branco_conservador, "lucro_liquido_se_der_branco": lucro_liquido, "custo_total_operacao": round(custo_total, 2), "house_edge_estatico": "-6.67%"}


# ============================================================
# MOTOR UNIFICADO V1 (COMPLETO - SEM CORTES)
# ============================================================

class MotorUnificadoV1:
    def __init__(self):
        self.ia = None
        self.regime_recencia = None
        self.ultima_atualizacao = None
        self.base_longa_carregada = False
        self.recencia_injetada = False

    def carregar_tudo(self, forcar_recencia=True):
        print("[MOTOR UNIFICADO] Iniciando carregamento completo...")
        self.ia = carregar_modelo_longo_prazo()
        
        if self.ia and len(self.ia.dados_recencia) > 1500:
            self.ia.dados_recencia = []
            
        if self.ia is None:
            if os.path.exists(NOME_BASE_DEFINITIVA):
                dados_longos = LeitorXLS(NOME_BASE_DEFINITIVA).ler_e_validar()
                if dados_longos and len(dados_longos) >= 50:
                    relatorio = treinar_base_longo_prazo_com_janelas(dados_longos)
                    self.ia = relatorio.get("ia_treinada")
                    self.base_longa_carregada = True
        else:
            self.base_longa_carregada = True
            
        if forcar_recencia:
            if self.ia and not getattr(self.ia, "recencia_foi_injetada_na_sessao", False):
                self._carregar_e_injetar_recencia()
                
        self.ultima_atualizacao = datetime.now()
        print("[MOTOR UNIFICADO] Carregamento concluído.")

    def _carregar_e_injetar_recencia(self):
        if getattr(self, "recencia_injetada", False): return
        if not os.path.exists("base_recencia_ativa.xlsx"): return
        dados_rec = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
        if not dados_rec or len(dados_rec) < 20: return
            
        print(f"[MOTOR UNIFICADO] Injetando {len(dados_rec)} registros de recência com peso alto...")
        if self.ia is None: self.ia = IAPreditivaV1([], dados_rec)
        else:
            self.ia.dados_recencia = []
            self.ia.injetar_aprendizado_imediato(dados_rec, multiplicador_peso=6)
            
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = self.regime_recencia
        self.ia.recencia_foi_injetada_na_sessao = True
        self.recencia_injetada = True

    def absorver_base_longa(self, dados_novos):
        if not dados_novos or len(dados_novos) < 30: return {"sucesso": False, "mensagem": "Base muito pequena."}
        relatorio = treinar_base_longo_prazo_com_janelas(dados_novos)
        self.ia = relatorio.get("ia_treinada")
        self.base_longa_carregada = True
        if os.path.exists("base_recencia_ativa.xlsx"): self._carregar_e_injetar_recencia()
        sucesso = salvar_modelo_longo_prazo(self.ia)
        return {"sucesso": True, "registros_absorvidos": len(dados_novos), "modelo_salvo": sucesso, "mensagem": "Absorvido."}

    def processar_recencia(self, dados_recencia):
        if not dados_recencia or len(dados_recencia) < 20: return {"sucesso": False, "mensagem": "Base de recência muito pequena."}
        if self.ia is None: self.carregar_tudo(forcar_recencia=False)
        self.ia.dados_recencia = []
        self.ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=6)
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = self.regime_recencia
        self.recencia_injetada = True
        
        dados_limpos_para_base = [{"numero": d["numero"], "cor": d["cor"]} for d in dados_recencia]
        adicionar_a_base_longo_prazo(dados_limpos_para_base)
        self.carregar_tudo(forcar_recencia=False)
        self.ia.dados_recencia = []
        self.ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=6)
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        
        return {"sucesso": True, "registros_processados": len(dados_recencia), "regime_recencia": self.regime_recencia, "mensagem": "Processado com sucesso."}

    def gerar_sinal_tipo_b(self, sequencia_12):
        if len(sequencia_12) != 12: return {"erro": "Necessário exatamente 12 números"}
        if self.ia is None: self.carregar_tudo()
        polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12]
        
        analise = MotorAnalise.analisar_janela(sequencia_12, polaridades, self.ia, eh_sinal_real=True)
        
        if analise["no_call"]["ativo"]:
            return {"sinal": "NO CALL", "justificativa": analise["no_call"]["motivo"], "no_call": True, "regime_recencia": self.regime_recencia, "motivo_real": f"NO CALL: {analise['no_call']['motivo']}", "regra_id": "SISTEMA_TRAVADO", "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")}
            
        geometria = analise["geometria"]
        expectativas = analise["regras_posicionais"]
        direcao_ia = analise["ia"]["direcao"]
        conf_ia = analise["ia"]["confianca"]
        raciocinio_ia = analise["ia"]["raciocinio"]
        streak = analise["contexto_reversao"]["streak"]
        xadrez_len = analise["contexto_reversao"]["xadrez_len"]
        xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
        contexto_exaustao = analise["contexto_reversao"]["exaustao"]
        modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
        
        sinal_final, justificativa_final, regra_id_final = JuizHierarquicoModificado.arbitrar_sinal(
            no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, geometria_mercado=geometria,
            previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), status_inversao=None, historico_regras=self.ia.historico_regras if self.ia else {},
            modo_mercado=modo_mercado, streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
            contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
            ia_modelo=self.ia, entropia_shannon=analise.get("entropia", 0.0)
        )

        if sinal_final != "NO CALL" and streak >= 6:
            sinal_final = "NO CALL"
            justificativa_final = f"Veto de streak {streak}x (segurança anti-tendência)"
            regra_id_final = "VETO_STREAK"

        kelly_fraction = 0.0
        if sinal_final != "NO CALL":
            kelly_fraction = EngineMatematicoAvancado.calcular_kelly(conf_ia)
            
        return {
            "sinal": sinal_final,
            "justificativa": justificativa_final,
            "confianca_ia": round(conf_ia, 2),
            "no_call": False,
            "regime_recencia": self.regime_recencia,
            "motivo_real": justificativa_final,
            "raciocinio_trace": analise["camadas"],
            "regra_id": regra_id_final,
            "entropia": analise.get("entropia"),
            "probabilidade_markov": analise.get("probabilidade_markov"),
            "kelly": kelly_fraction
        }

    def processar_feedback_real(self, sequencia_12, sinal_indicado, regra_id, numeros_saidos, classificacao, entropia_shannon=0.0, probabilidade_markov=None):
        if self.ia is None: self.carregar_tudo()
        polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12]
        analise = MotorAnalise.analisar_janela(sequencia_12, polaridades, self.ia)
        
        modo_mercado = analise.get("contexto_avancado", {}).get("modo_mercado", "NEUTRO")
        geometria = analise.get("geometria", "ESTÁVEL")
        expectativas = analise.get("regras_posicionais", [])
        
        classificacao_limpa = classificacao.split(" ")[0].upper()
        if "LOSS" in classificacao_limpa or "FALHA" in classificacao_limpa: classificacao_limpa = "FALHA"
            
        estado_rl = f"HMM_{modo_mercado}_Entropia_{round(entropia_shannon, 1)}"
        acao_rl = "APOSTAR" if sinal_indicado != "NO CALL" else "NO_CALL"
        if classificacao_limpa in ["G0", "G1"]: recompensa = 1.0
        elif classificacao_limpa == "G2": recompensa = -0.5 
        elif classificacao_limpa == "FALHA": recompensa = -2.0 
        else: recompensa = 0.0
        
        self.ia.atualizar_q_learning(estado_rl, acao_rl, recompensa)
            
        contexto_analise = {
            "geometria": geometria, "regras_posicionais": expectativas, "controlador_retardador": analise.get("controlador_retardador", {}),
            "contexto_avancado": {"modo_mercado": modo_mercado}, "entropia_shannon": entropia_shannon, "monte_carlo_indicou": probabilidade_markov
        }
        
        if classificacao_limpa in ["G0", "G1"]: self.ia.registrar_padrao_vencedor(contexto_analise, classificacao_limpa)
        if regra_id and regra_id not in ["NENHUMA", "SISTEMA_TRAVADO"]:
            self.ia.historico_regras[regra_id]["total"] += 1
            if classificacao_limpa in ["G0", "G1", "G2"]: self.ia.historico_regras[regra_id]["acertos"] += 1
                
        dados_novos_completos = []
        for n in sequencia_12:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_completos.append({"numero": n, "cor": cor})
            
        for n in numeros_saidos:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_completos.append({"numero": n, "cor": cor})
            
        contexto_injecao = {"regras_posicionais": expectativas, "controlador_retardador": analise.get("controlador_retardador", {}), "geometria": geometria}
        self.ia.injetar_aprendizado_imediato(dados_novos_completos, 4, contexto_injecao)
        
        dados_novos_para_arquivo = []
        for n in numeros_saidos:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_para_arquivo.append({"numero": n, "cor": cor})
            
        recencia_atual = self.ia.dados_recencia.copy() if self.ia else []
        rel = adicionar_a_base_longo_prazo(dados_novos_para_arquivo)
        self.carregar_tudo(forcar_recencia=False)
        
        if self.ia:
            self.ia.dados_recencia = recencia_atual
            self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
            self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
            self.ia.regime_recencia = self.regime_recencia
        return rel

    def status(self):
        volume_longo = len(self.ia.dados_longo) if self.ia and self.ia.dados_longo else 0
        volume_rec = len(self.ia.dados_recencia) if self.ia and self.ia.dados_recencia else 0
        return {"ia_carregada": self.ia is not None, "base_longa_carregada": self.base_longa_carregada, "recencia_injetada": self.recencia_injetada, "regime_recencia": self.regime_recencia, "volume_longo_prazo": volume_longo, "volume_recencia": volume_rec, "ultima_atualizacao": self.ultima_atualizacao.isoformat() if self.ultima_atualizacao else None}

motor_unificado = MotorUnificadoV1()
