Snapshot imutável do `main.py` original usado como referência da Fase 1.
