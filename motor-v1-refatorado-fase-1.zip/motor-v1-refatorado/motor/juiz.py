import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

class JuizHierarquicoModificado:
    @staticmethod
    def arbitrar_sinal(no_call_ativo, motivo_nc, expectations, inclinacao_num, geometria_mercado, 
                       previsao_ia, status_inversao, historico_regras,
                       modo_mercado="NEUTRO", 
                       streak_atual=0, xadrez_len=0, xadrez_quebrou=False,
                       contexto_exaustao=False, sintese_evidencias=None,
                       probabilidade_markov=None, ia_modelo=None, entropia_shannon=0.0):
        if no_call_ativo:
            return "NO CALL", motivo_nc, "SISTEMA_TRAVADO"
            
        if ia_modelo and hasattr(ia_modelo, 'q_table'):
            estado_rl = f"HMM_{modo_mercado}_Entropia_{round(entropia_shannon, 1)}"
            if estado_rl in ia_modelo.q_table:
                q_apostar = ia_modelo.q_table[estado_rl]["APOSTAR"]
                q_no_call = ia_modelo.q_table[estado_rl]["NO_CALL"]
                if q_no_call > q_apostar + 0.3:
                    return "NO CALL", f"Agente RL Autônomo VETOU: Operar nesse cenário tem ROI negativo histórico (Q-Value: {q_apostar:.2f})", "VETO_RL"

        direcao_ia, confianca_ia, raciocinio_ia = previsao_ia
        
        # TRATAMENTO DA COLISÃO DE MOTORES (NO CALL) DO CONSENSO DINÂMICO
        if direcao_ia == "NO CALL":
            return "NO CALL", raciocinio_ia, "COLISAO_MOTORES"
        
        bonus_memoria = 0
        if direcao_ia == "NEUTRO" and ia_modelo and hasattr(ia_modelo, 'calcular_bonus_memoria'):
            contexto_memoria = {
                "geometria": geometria_mercado,
                "regras_posicionais": expectations,
                "entropia_shannon": entropia_shannon
            }
            bonus_memoria = ia_modelo.calcular_bonus_memoria(contexto_memoria)

        sinal_preliminar = "NEUTRO"
        motivo_preliminar = ""
        regra_preliminar = ""
        
        tem_quebrador_historico = any("QUEBRADOR" in e.get("tipo_regra", "") for e in expectations)
        
        if direcao_ia != "NEUTRO" and confianca_ia >= 52.5:
            sinal_preliminar = direcao_ia
            motivo_preliminar = raciocinio_ia
            regra_preliminar = "IA_PREDITIVA"
        elif tem_quebrador_historico:
            dir_inversao = next((e["direcao"] for e in expectations if "QUEBRADOR" in e["tipo_regra"] and e["direcao"] != "NEUTRO"), "NO CALL")
            if dir_inversao != "NO CALL":
                sinal_preliminar = dir_inversao
                motivo_preliminar = "Ação de Quebrador Histórico (O número rompe o padrão atual)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "QUEBRADOR_HISTORICO"
        elif geometria_mercado == "CICLO_FECHADO_VPPV":
            sinal_preliminar = "PRETO"
            motivo_preliminar = "Geometria VPPV Clássica"
            if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
            regra_preliminar = "GEOMETRIA_FORTE"
        elif geometria_mercado == "CICLO_FECHADO_PVVP":
            sinal_preliminar = "VERMELHO"
            motivo_preliminar = "Geometria PVVP Clássica"
            if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
            regra_preliminar = "GEOMETRIA_FORTE"
        elif expectations:
            peso_v = 0
            peso_p = 0
            for item in expectations:
                peso_regra = 1
                if any(key in item["tipo_regra"] for key in ["CONTINUIDADE", "ASSUNCAO", "QUEBRADOR"]):
                    peso_regra = 3
                
                if item["direcao"] == "VERMELHO":
                    peso_v += peso_regra
                elif item["direcao"] == "PRETO":
                    peso_p += peso_regra

            if peso_v > peso_p:
                sinal_preliminar = "VERMELHO"
                motivo_preliminar = "Regra posicional majoritária (Ponderada)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "REGRA_POSICIONAL"
            elif peso_p > peso_v:
                sinal_preliminar = "PRETO"
                motivo_preliminar = "Regra posicional majoritária (Ponderada)"
                if bonus_memoria > 0: motivo_preliminar += f" [Impulsionado por Memória de Sucesso: +{bonus_memoria}pts]"
                regra_preliminar = "REGRA_POSICIONAL"
                
        if sinal_preliminar == "NEUTRO":
            return "NO CALL", "Ausência de dominância clara. Sistema abortou a entrada por neutralidade.", "FALLBACK_NO_CALL"
            
        return sinal_preliminar, motivo_preliminar, regra_preliminar
