import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

try:
    import numpy as np
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.neural_network import MLPClassifier
    from hmmlearn.hmm import CategoricalHMM
    HAS_ML = True
except ImportError:
    HAS_ML = False
    print("Aviso: Bibliotecas ML não encontradas. O Motor funcionará no modo Estatístico Avançado. Instale com: pip install numpy scikit-learn hmmlearn")

from motor.regras import MotorNoCall, MotorContagensProjetivas, AnalisadorContextoAvancado
from matematica.engine import EngineMatematicoAvancado

class MotorAnalise:
    @staticmethod
    def analisar_janela(sub_num, sub_pol, ia_modelo, base_longa=None, eh_sinal_real=False):
        resultado = {
            "camadas": [],
            "no_call": None,
            "geometria": None,
            "regras_posicionais": [],
            "contexto_avancado": {},
            "ia": {},
            "contexto_reversao": {},
            "controlador_retardador": {}
        }
        
        nc_ativo, motivo_nc = MotorNoCall.checar_no_call(sub_num, sub_pol)
        
        if eh_sinal_real and not nc_ativo and len(sub_num) >= 2:
            risco_ativo, motivo_risco = MotorNoCall.checar_risco_preditivo_g0(sub_num, ia_modelo)
            if risco_ativo:
                nc_ativo = True
                motivo_nc = motivo_risco
        
        entropia = 0.0
        if eh_sinal_real:
            entropia = EngineMatematicoAvancado.calcular_entropia_shannon(sub_pol)
            resultado["entropia"] = entropia
            if entropia > 1.52 and not nc_ativo:
                nc_ativo = True
                motivo_nc = f"Bloqueio de Segurança HMM: Entropia de Shannon em Nível Crítico de Caos ({entropia} Bits). O Mercado está Aleatório."
            
        resultado["no_call"] = {"ativo": nc_ativo, "motivo": motivo_nc}
        resultado["camadas"].append({
            "camada": 1, "nome": "Segurança e Proteção de Saldo (NO CALL)",
            "resultado": f"Ativo={nc_ativo}", "detalhe": motivo_nc,
            "impacto": "BLOQUEIO" if nc_ativo else "APROVADO"
        })
        
        if nc_ativo:
            resultado["probabilidade_markov"] = ia_modelo.calcular_probabilidade_exata_markov(sub_pol)
            return resultado
            
        modo_mercado = AnalisadorContextoAvancado.detectar_modo_mercado(sub_pol, eh_sinal_real, ia_modelo)
        geometria = AnalisadorContextoAvancado.mapear_padroes_geometria(sub_pol)
        
        resultado["geometria"] = geometria
        resultado["camadas"].append({
            "camada": 2, "nome": "Geometria de Mercado",
            "resultado": geometria, "detalhe": "Padrão geométrico detectado no gráfico",
            "impacto": "FORTE" if geometria in ["CICLO_FECHADO_VPPV", "CICLO_FECHADO_PVVP"] else "NEUTRO"
        })
        
        expectativas = MotorContagensProjetivas.mapear_janela(sub_num, sub_pol, geometria, ia_modelo)
        resultado["regras_posicionais"] = expectativas
        resultado["camadas"].append({
            "camada": 3, "nome": "Regras Posicionais Ativadas (Volumes 2 e 3)",
            "resultado": f"{len(expectativas)} regras ativas",
            "detalhe": [e["tipo_regra"] for e in expectativas] if expectativas else "Nenhuma detecção volumétrica",
            "impacto": "ALTO" if expectativas else "BAIXO"
        })
        
        resultado["contexto_avancado"] = {"modo_mercado": modo_mercado}
        resultado["camadas"].append({
            "camada": 4, "nome": "Contexto Avançado HMM (Hidden Markov Model)",
            "resultado": f"Modo: {modo_mercado}", "detalhe": "Detecção matemática de fase do algoritmo", "impacto": "MÉDIO"
        })
        
        contexto_para_ia = {
            "geometria": geometria,
            "regras_posicionais": expectativas,
            "controlador_retardador": {},
            "contexto_avancado": resultado["contexto_avancado"]
        }
        
        direcao_ia, conf_ia, raciocinio_ia = ia_modelo.predizer_proxima_casa(sub_num, sub_pol, contexto_para_ia)
        resultado["ia"] = {
            "direcao": direcao_ia,
            "confianca": conf_ia,
            "raciocinio": raciocinio_ia
        }
        resultado["camadas"].append({
            "camada": 5, "nome": "IA Preditiva Híbrida (XGBoost, LSTM, Z-Score)",
            "resultado": f"{direcao_ia} ({conf_ia}%)",
            "detalhe": raciocinio_ia,
            "impacto": "ALTO" if conf_ia >= 52 else "MÉDIO"
        })
        
        probabilidade_markov = ia_modelo.calcular_probabilidade_exata_markov(sub_pol)
        resultado["probabilidade_markov"] = probabilidade_markov
        
        if eh_sinal_real:
            resultado["camadas"].append({
                "camada": 5.5, "nome": "Validação Determinística (Cadeia de Markov Exata)",
                "resultado": f"V: {probabilidade_markov['V']}% | P: {probabilidade_markov['P']}%",
                "detalhe": "Cálculo matemático fechado do arquivo base (sem simulações aleatórias)",
                "impacto": "ALTO"
            })
            
        streak, xadrez_len, xadrez_quebrou, exaustao = MotorAnalise._calcular_contexto_reversao(sub_pol)
        resultado["contexto_reversao"] = {
            "streak": streak, "xadrez_len": xadrez_len,
            "xadrez_quebrou": xadrez_quebrou, "exaustao": exaustao
        }
        resultado["camadas"].append({
            "camada": 6, "nome": "Contexto de Reversão e Exaustão",
            "resultado": f"Streak atual: {streak}x | Tamanho do Xadrez: {xadrez_len}",
            "detalhe": f"Sinal de Exaustão de Padrão: {exaustao}",
            "impacto": "ALTO" if exaustao else "BAIXO"
        })
        
        ctrl_ret = MotorAnalise._detectar_controlador_retardador(
            sub_num, sub_pol, expectativas, geometria, modo_mercado, eh_sinal_real
        )
        resultado["controlador_retardador"] = ctrl_ret
        resultado["camadas"].append({
            "camada": 7, "nome": "Balança de Forças Operacionais (Controlador vs Retardador)",
            "resultado": ctrl_ret["dominancia"],
            "detalhe": f"Forças de Controle: {ctrl_ret['controladores']} | Forças de Retardo: {ctrl_ret['retardadores']}",
            "impacto": "ALTO"
        })
        return resultado

    @staticmethod
    def _calcular_contexto_reversao(sub_pol):
        streak = 0
        if sub_pol:
            ultima_cor = sub_pol[-1]
            for c in reversed(sub_pol):
                if c == ultima_cor:
                    streak += 1
                else:
                    break
        
        xadrez_len = 0
        for i in range(len(sub_pol)-1, 0, -1):
            if sub_pol[i] != sub_pol[i-1]:
                xadrez_len += 1
            else:
                break
        xadrez_quebrou = (sub_pol[-1] == sub_pol[-2]) if len(sub_pol) >= 2 else False
        exaustao = (streak >= 5) or (xadrez_len >= 5 and xadrez_quebrou)
        return streak, xadrez_len, xadrez_quebrou, exaustao

    @staticmethod
    def _detectar_controlador_retardador(sub_num, sub_pol, expectativas, geometria, modo_mercado, eh_sinal_real=False):
        controladores = []
        retardadores = []
        if geometria in ["CICLO_FECHADO_VPPV", "CICLO_FECHADO_PVVP"]:
            controladores.append("Geometria forte")
        if expectativas:
            controladores.append("Regras posicionais ativas")
            
        if eh_sinal_real:
            if "RECOLHIMENTO" in modo_mercado or "CAOS" in modo_mercado:
                retardadores.append("HMM Oculto detecta alta aleatoriedade (Modo Recolhimento da Máquina)")
        else:
            if "CHUVA" in modo_mercado:
                retardadores.append("Alta alternância (modo Chuva clássico)")
                
        if len(controladores) > len(retardadores):
            dominancia = "CONTROLADOR"
        elif len(retardadores) > len(controladores):
            dominancia = "RETARDADOR"
        else:
            dominancia = "NEUTRO"
        return {
            "controladores": controladores,
            "retardadores": retardadores,
            "dominancia": dominancia
        }
