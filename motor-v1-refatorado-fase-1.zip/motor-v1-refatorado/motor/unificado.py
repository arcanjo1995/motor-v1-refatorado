import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

try:
    import numpy as np
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.neural_network import MLPClassifier
    from hmmlearn.hmm import CategoricalHMM
    HAS_ML = True
except ImportError:
    HAS_ML = False
    print("Aviso: Bibliotecas ML não encontradas. O Motor funcionará no modo Estatístico Avançado. Instale com: pip install numpy scikit-learn hmmlearn")

NOME_BASE_DEFINITIVA = "resultados_blaze.xlsx"
from dados.persistencia import fabrica_historico_regras_auditado, carregar_modelo_longo_prazo, salvar_modelo_longo_prazo
from dados.leitor_xls import LeitorXLS
from dados.recencia import analisar_regime_recencia
from dados.base import adicionar_a_base_longo_prazo
from ia.treinamento import treinar_base_longo_prazo_com_janelas
from ia.preditiva import IAPreditivaV1
from motor.analise import MotorAnalise
from motor.juiz import JuizHierarquicoModificado
from matematica.engine import EngineMatematicoAvancado

class SequenciaOperacional:
    def __init__(self, lista_resultados):
        self.cronologia = lista_resultados
        self.numerica = [int(r['numero']) for r in self.cronologia]
        self.polaridades = [str(r['cor']).upper() for r in self.cronologia]
        self.total = len(self.numerica)

class MotorV1Completo:
    def __init__(self, lista_dados_xls, ia_existente=None):
        self.seq = SequenciaOperacional(lista_dados_xls)
        self.dados_longo = lista_dados_xls
        
        # UNIFICAÇÃO DE CÉREBROS: Impede que o TIPO D crie um "Cérebro Zerado" ao auditar Recência.
        global motor_unificado
        if ia_existente is not None: 
            self.ia = ia_existente
        elif 'motor_unificado' in globals() and motor_unificado.ia is not None and len(lista_dados_xls) <= 1000:
            self.ia = motor_unificado.ia
        else:
            base_recencia = None
            if os.path.exists("base_recencia_ativa.xlsx"):
                try: base_recencia = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
                except: pass
            self.ia = IAPreditivaV1(self.dados_longo, base_recencia if base_recencia else [])
            
        self.historico_regras = defaultdict(fabrica_historico_regras_auditado)
        self.stats = {"G0": 0, "G1": 0, "G2": 0, "FALHA": 0, "NO CALL": 0}

    def processar_auditoria(self):
        idx = 0
        memorias = []
        stats = {"G0": 0, "G1": 0, "G2": 0, "FALHA": 0, "NO CALL": 0}

        while idx + 12 < self.seq.total:
            sub_num = self.seq.numerica[idx:idx+12]
            sub_pol = self.seq.polaridades[idx:idx+12]
            analise = MotorAnalise.analisar_janela(sub_num, sub_pol, self.ia, eh_sinal_real=False)

            regra_id = "NENHUMA"

            if analise["no_call"]["ativo"]:
                sinal = "NO CALL"
                justificativa = analise["no_call"]["motivo"]
                regra_id = "SISTEMA_TRAVADO"
            else:
                geometria = analise["geometria"]
                expectativas = analise["regras_posicionais"]
                direcao_ia = analise["ia"]["direcao"]
                conf_ia = analise["ia"]["confianca"]
                raciocinio_ia = analise["ia"]["raciocinio"]
                streak = analise["contexto_reversao"]["streak"]
                xadrez_len = analise["contexto_reversao"]["xadrez_len"]
                xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
                contexto_exaustao = analise["contexto_reversao"]["exaustao"]
                modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
                
                sinal, justificativa, regra_id = JuizHierarquicoModificado.arbitrar_sinal(
                    no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, 
                    geometria_mercado=geometria, previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), 
                    status_inversao=None, historico_regras=self.historico_regras, modo_mercado=modo_mercado,
                    streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
                    contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
                    ia_modelo=self.ia, entropia_shannon=analise.get("entropia", 0.0)
                )

            correcoes = self.seq.polaridades[idx+12 : idx+15]
            classificacao = "FALHA"
            salto = 3

            if sinal == "NO CALL":
                classificacao = "NO CALL"
                salto = 1
            else:
                letra = "V" if sinal == "VERMELHO" else "P"
                for g, cor in enumerate(correcoes):
                    if cor == letra or cor == "B":
                        classificacao = f"G{g}"
                        salto = g + 1
                        break

            stats[classificacao] = stats.get(classificacao, 0) + 1

            # =========================================================
            # INJEÇÃO RL (Q-LEARNING) DURANTE A AUDITORIA HISTÓRICA
            # =========================================================
            if self.ia is not None:
                entropia_shannon_atual = analise.get("entropia", 0.0)
                modo_mercado_atual = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
                
                estado_rl_historico = f"HMM_{modo_mercado_atual}_Entropia_{round(entropia_shannon_atual, 1)}"
                acao_rl_historico = "APOSTAR" if sinal != "NO CALL" else "NO_CALL"
                
                recompensa = 0.0
                if classificacao in ["G0", "G1"]:
                    recompensa = 1.0
                elif classificacao == "G2":
                    recompensa = -0.5
                elif classificacao == "FALHA":
                    recompensa = -2.0
                    
                self.ia.atualizar_q_learning(estado_rl_historico, acao_rl_historico, recompensa)
            # =========================================================

            if classificacao in ["G0", "G1"]:
                contexto_analise = {
                    "geometria": analise.get("geometria"),
                    "regras_posicionais": analise.get("regras_posicionais"),
                    "controlador_retardador": analise.get("controlador_retardador", {}),
                    "contexto_avancado": {"modo_mercado": analise.get("contexto_avancado", {}).get("modo_mercado", "NEUTRO")}
                }
                self.ia.registrar_padrao_vencedor(contexto_analise, classificacao)

            if regra_id not in ["NENHUMA", "SISTEMA_TRAVADO"]:
                self.historico_regras[regra_id]["total"] += 1
                if classificacao in ["G0", "G1"]:
                    self.historico_regras[regra_id]["acertos"] += 1

            bloco = [{"numero": self.seq.numerica[k], "cor": self.seq.polaridades[k]} for k in range(idx, min(idx + 12 + salto, self.seq.total))]
            contexto_injecao = {
                "regras_posicionais": analise.get("regras_posicionais", []),
                "controlador_retardador": analise.get("controlador_retardador", {}),
                "geometria": analise.get("geometria", "ESTÁVEL")
            }
            self.ia.injetar_aprendizado_imediato(bloco, 4, contexto_injecao, salvar_na_recencia=False)
            memorias.append(f"Janela {len(memorias)+1}: {sub_num} -> {sinal} | {justificativa} | {classificacao}")
            idx += 12 + salto

        self.stats = stats
        total_janelas = sum(stats.values())
        denom = total_janelas if total_janelas > 0 else 1
        
        output = "[MEMÓRIA DE CÁLCULO DAS JANELAS MÓVEIS]\n"
        output += "\n".join(memorias) + "\n\n"
        output += "[RESULTADO FINAL TIPO D]\n"
        output += f"CRONOLOGIA VALIDADA: {self.seq.total} Resultados\n"
        output += f"TOTAL DE JANELAS AUDITADAS: {len(memorias)}\n"
        output += f" - Taxa G0: {stats.get('G0',0)} Ocorrências ({(stats.get('G0',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa G1: {stats.get('G1',0)} Ocorrências ({(stats.get('G1',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa G2: {stats.get('G2',0)} Ocorrências ({(stats.get('G2',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa de Falha: {stats.get('FALHA',0)} Ocorrências ({(stats.get('FALHA',0)/denom)*100:.2f}%)\n"
        output += f" - Taxa de NO CALL: {stats.get('NO CALL',0)} Ocorrências ({(stats.get('NO CALL',0)/denom)*100:.2f}%)\n\n"
        
        if stats.get("FALHA", 0) >= 25:
            condicao = "MERCADO EM DEGRADAÇÃO"
        elif stats.get("G0", 0) >= 50:
            condicao = "MERCADO PAGADOR"
        else:
            condicao = "MERCADO INSTÁVEL"
            
        output += f"ESTADO ATUAL DO MERCADO: {condicao}\n"
        return output

class MotorUnificadoV1:
    def __init__(self):
        self.ia = None
        self.regime_recencia = None
        self.ultima_atualizacao = None
        self.base_longa_carregada = False
        self.recencia_injetada = False

    def carregar_tudo(self, forcar_recencia=True):
        print("[MOTOR UNIFICADO] Iniciando carregamento completo...")
        self.ia = carregar_modelo_longo_prazo()
        
        if self.ia and len(self.ia.dados_recencia) > 1500:
            self.ia.dados_recencia = []
            
        if self.ia is None:
            if os.path.exists(NOME_BASE_DEFINITIVA):
                dados_longos = LeitorXLS(NOME_BASE_DEFINITIVA).ler_e_validar()
                if dados_longos and len(dados_longos) >= 50:
                    relatorio = treinar_base_longo_prazo_com_janelas(dados_longos)
                    self.ia = relatorio.get("ia_treinada")
                    self.base_longa_carregada = True
        else:
            self.base_longa_carregada = True
            
        if forcar_recencia:
            if self.ia and not getattr(self.ia, "recencia_foi_injetada_na_sessao", False):
                self._carregar_e_injetar_recencia()
                
        self.ultima_atualizacao = datetime.now()
        print("[MOTOR UNIFICADO] Carregamento concluído.")

    def _carregar_e_injetar_recencia(self):
        if getattr(self, "recencia_injetada", False): return
        if not os.path.exists("base_recencia_ativa.xlsx"): return
        dados_rec = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
        if not dados_rec or len(dados_rec) < 20: return
            
        print(f"[MOTOR UNIFICADO] Injetando {len(dados_rec)} registros de recência com peso alto...")
        if self.ia is None: self.ia = IAPreditivaV1([], dados_rec)
        else:
            self.ia.dados_recencia = []
            self.ia.injetar_aprendizado_imediato(dados_rec, multiplicador_peso=6)
            
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = self.regime_recencia
        self.ia.recencia_foi_injetada_na_sessao = True
        self.recencia_injetada = True

    def absorver_base_longa(self, dados_novos):
        if not dados_novos or len(dados_novos) < 30: return {"sucesso": False, "mensagem": "Base muito pequena."}
        relatorio = treinar_base_longo_prazo_com_janelas(dados_novos)
        self.ia = relatorio.get("ia_treinada")
        self.base_longa_carregada = True
        if os.path.exists("base_recencia_ativa.xlsx"): self._carregar_e_injetar_recencia()
        sucesso = salvar_modelo_longo_prazo(self.ia)
        return {"sucesso": True, "registros_absorvidos": len(dados_novos), "modelo_salvo": sucesso, "mensagem": "Absorvido."}

    def processar_recencia(self, dados_recencia):
        if not dados_recencia or len(dados_recencia) < 20: return {"sucesso": False, "mensagem": "Base de recência muito pequena."}
        if self.ia is None: self.carregar_tudo(forcar_recencia=False)
        self.ia.dados_recencia = []
        self.ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=6)
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = self.regime_recencia
        self.recencia_injetada = True
        
        dados_limpos_para_base = [{"numero": d["numero"], "cor": d["cor"]} for d in dados_recencia]
        adicionar_a_base_longo_prazo(dados_limpos_para_base)
        self.carregar_tudo(forcar_recencia=False)
        self.ia.dados_recencia = []
        self.ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=6)
        self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
        self.ia.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
        
        return {"sucesso": True, "registros_processados": len(dados_recencia), "regime_recencia": self.regime_recencia, "mensagem": "Processado com sucesso."}

    def gerar_sinal_tipo_b(self, sequencia_12):
        if len(sequencia_12) != 12: return {"erro": "Necessário exatamente 12 números"}
        if self.ia is None: self.carregar_tudo()
        polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12]
        
        analise = MotorAnalise.analisar_janela(sequencia_12, polaridades, self.ia, eh_sinal_real=True)
        
        if analise["no_call"]["ativo"]:
            return {"sinal": "NO CALL", "justificativa": analise["no_call"]["motivo"], "no_call": True, "regime_recencia": self.regime_recencia, "motivo_real": f"NO CALL: {analise['no_call']['motivo']}", "regra_id": "SISTEMA_TRAVADO", "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")}
            
        geometria = analise["geometria"]
        expectativas = analise["regras_posicionais"]
        direcao_ia = analise["ia"]["direcao"]
        conf_ia = analise["ia"]["confianca"]
        raciocinio_ia = analise["ia"]["raciocinio"]
        streak = analise["contexto_reversao"]["streak"]
        xadrez_len = analise["contexto_reversao"]["xadrez_len"]
        xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
        contexto_exaustao = analise["contexto_reversao"]["exaustao"]
        modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
        
        sinal_final, justificativa_final, regra_id_final = JuizHierarquicoModificado.arbitrar_sinal(
            no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, geometria_mercado=geometria,
            previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), status_inversao=None, historico_regras=self.ia.historico_regras if self.ia else {},
            modo_mercado=modo_mercado, streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
            contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
            ia_modelo=self.ia, entropia_shannon=analise.get("entropia", 0.0)
        )

        if sinal_final != "NO CALL" and streak >= 6:
            sinal_final = "NO CALL"
            justificativa_final = f"Veto de streak {streak}x (segurança anti-tendência)"
            regra_id_final = "VETO_STREAK"

        kelly_fraction = 0.0
        if sinal_final != "NO CALL":
            kelly_fraction = EngineMatematicoAvancado.calcular_kelly(conf_ia)
            
        return {
            "sinal": sinal_final,
            "justificativa": justificativa_final,
            "confianca_ia": round(conf_ia, 2),
            "no_call": False,
            "regime_recencia": self.regime_recencia,
            "motivo_real": justificativa_final,
            "raciocinio_trace": analise["camadas"],
            "regra_id": regra_id_final,
            "entropia": analise.get("entropia"),
            "probabilidade_markov": analise.get("probabilidade_markov"),
            "kelly": kelly_fraction
        }

    def processar_feedback_real(self, sequencia_12, sinal_indicado, regra_id, numeros_saidos, classificacao, entropia_shannon=0.0, probabilidade_markov=None):
        if self.ia is None: self.carregar_tudo()
        polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12]
        analise = MotorAnalise.analisar_janela(sequencia_12, polaridades, self.ia)
        
        modo_mercado = analise.get("contexto_avancado", {}).get("modo_mercado", "NEUTRO")
        geometria = analise.get("geometria", "ESTÁVEL")
        expectativas = analise.get("regras_posicionais", [])
        
        classificacao_limpa = classificacao.split(" ")[0].upper()
        if "LOSS" in classificacao_limpa or "FALHA" in classificacao_limpa: classificacao_limpa = "FALHA"
            
        estado_rl = f"HMM_{modo_mercado}_Entropia_{round(entropia_shannon, 1)}"
        acao_rl = "APOSTAR" if sinal_indicado != "NO CALL" else "NO_CALL"
        if classificacao_limpa in ["G0", "G1"]: recompensa = 1.0
        elif classificacao_limpa == "G2": recompensa = -0.5 
        elif classificacao_limpa == "FALHA": recompensa = -2.0 
        else: recompensa = 0.0
        
        self.ia.atualizar_q_learning(estado_rl, acao_rl, recompensa)
            
        contexto_analise = {
            "geometria": geometria, "regras_posicionais": expectativas, "controlador_retardador": analise.get("controlador_retardador", {}),
            "contexto_avancado": {"modo_mercado": modo_mercado}, "entropia_shannon": entropia_shannon, "monte_carlo_indicou": probabilidade_markov
        }
        
        if classificacao_limpa in ["G0", "G1"]: self.ia.registrar_padrao_vencedor(contexto_analise, classificacao_limpa)
        if regra_id and regra_id not in ["NENHUMA", "SISTEMA_TRAVADO"]:
            self.ia.historico_regras[regra_id]["total"] += 1
            if classificacao_limpa in ["G0", "G1", "G2"]: self.ia.historico_regras[regra_id]["acertos"] += 1
                
        dados_novos_completos = []
        for n in sequencia_12:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_completos.append({"numero": n, "cor": cor})
            
        for n in numeros_saidos:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_completos.append({"numero": n, "cor": cor})
            
        contexto_injecao = {"regras_posicionais": expectativas, "controlador_retardador": analise.get("controlador_retardador", {}), "geometria": geometria}
        self.ia.injetar_aprendizado_imediato(dados_novos_completos, 4, contexto_injecao)
        
        dados_novos_para_arquivo = []
        for n in numeros_saidos:
            cor = 'B' if n == 0 else ('V' if 1 <= n <= 7 else 'P')
            dados_novos_para_arquivo.append({"numero": n, "cor": cor})
            
        recencia_atual = self.ia.dados_recencia.copy() if self.ia else []
        rel = adicionar_a_base_longo_prazo(dados_novos_para_arquivo)
        self.carregar_tudo(forcar_recencia=False)
        
        if self.ia:
            self.ia.dados_recencia = recencia_atual
            self.ia.analise_recencia = self.ia.analisar_comportamento_pos_numero_recencia(self.ia.dados_recencia)
            self.regime_recencia = analisar_regime_recencia(self.ia.dados_recencia)
            self.ia.regime_recencia = self.regime_recencia
        return rel

    def status(self):
        volume_longo = len(self.ia.dados_longo) if self.ia and self.ia.dados_longo else 0
        volume_rec = len(self.ia.dados_recencia) if self.ia and self.ia.dados_recencia else 0
        return {"ia_carregada": self.ia is not None, "base_longa_carregada": self.base_longa_carregada, "recencia_injetada": self.recencia_injetada, "regime_recencia": self.regime_recencia, "volume_longo_prazo": volume_longo, "volume_recencia": volume_rec, "ultima_atualizacao": self.ultima_atualizacao.isoformat() if self.ultima_atualizacao else None}

motor_unificado = MotorUnificadoV1()
