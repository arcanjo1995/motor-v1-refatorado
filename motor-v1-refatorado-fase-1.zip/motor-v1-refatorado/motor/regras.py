import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

class MotorNoCall:
    @staticmethod
    def checar_no_call(sub_num, sub_pol):
        cenarios_duplas = [(7, 8), (8, 9), (9, 10), (10, 11)]
        for idx1, idx2 in cenarios_duplas:
            if sub_num[idx1] == sub_num[idx2]:
                return True, "Volume 2 Cap 6: Trava das Duplas Ativa"
        posicoes_criticas_6 = [5, 8, 9, 10, 11]
        for pos in posicoes_criticas_6:
            if sub_num[pos] == 6:
                return True, "Volume 2 Cap 4: Trava Número 6 (Posição de No Call Ativa)"
        posicoes_criticas_2 = [8, 9, 10, 11]
        for pos in posicoes_criticas_2:
            if sub_num[pos] == 2:
                return True, "Volume 2 Cap 3: Trava Número 2"
        posicoes_criticas_b = [5, 8, 9, 10, 11]
        for pos in posicoes_criticas_b:
            if sub_pol[pos] == "B":
                return True, "Volume 2 Cap 5: Trava do Branco"
        return False, "Evento Neutro Operacional"

    @staticmethod
    def checar_risco_preditivo_g0(sub_num, ia_modelo):
        if len(sub_num) < 2 or not hasattr(ia_modelo, 'bigramas_numericos'): return False, ""
        penultimo_num, ultimo_num = sub_num[-2], sub_num[-1]
        chave_dupla = f"{penultimo_num}-{ultimo_num}"
        stats_dupla = ia_modelo.bigramas_numericos.get(chave_dupla)
        if not stats_dupla or stats_dupla["total"] == 0: return False, ""
        total_ocorrencias = stats_dupla["total"]
        prox_numeros_historico = stats_dupla.get("prox_numero", {})
        chance_6 = (prox_numeros_historico.get(6, 0) / total_ocorrencias) * 100
        chance_2 = (prox_numeros_historico.get(2, 0) / total_ocorrencias) * 100
        chance_repeticao = (prox_numeros_historico.get(ultimo_num, 0) / total_ocorrencias) * 100
        LIMITE_RISCO = 15.0
        if chance_6 >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco crítico de {chance_6:.1f}% do número 6 cair no G0."
        if chance_2 >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco crítico de {chance_2:.1f}% do número 2 cair no G0."
        if chance_repeticao >= LIMITE_RISCO: return True, f"Radar de Ameaça Numérica: Detectado risco de {chance_repeticao:.1f}% de dupla repetida."
        return False, ""

class MotorContagensProjetivas:
    @staticmethod
    def mapear_janela(sub_num, sub_pol, geometry_mercado, ia_modelo=None):
        lista_bruta = []
        REGRAS_PROJECAO = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7}
        for i in range(12):
            num_atual = sub_num[i]
            if num_atual in REGRAS_PROJECAO:
                passo = REGRAS_PROJECAO[num_atual]
                alvo_idx = i + passo
                if alvo_idx in (11, 12) and not any(sub_num[k] == 0 for k in range(i, 12)):
                    lista_bruta.append({"direcao": "VERMELHO", "tipo_regra": f"V3_ATIVADOR_{num_atual}", "origem": f"Volume 3"})
        par_fechamento = (sub_num[10], sub_num[11])
        continuidade_preta_validas = [(8,9), (9,10), (10,11), (11,12), (12,13), (13,14), (14,13), (13,12), (12,11), (11,10)]
        continuidade_vermelha_validas = [(1,2), (2,3), (3,4), (4,5), (5,6), (6,7), (7,6), (6,5), (5,4), (4,3)]
        if par_fechamento in continuidade_preta_validas: lista_bruta.append({"direcao": "PRETO", "tipo_regra": "V2_CONTINUIDADE_PRETA", "origem": "Volume 2"})
        elif par_fechamento in continuidade_vermelha_validas: lista_bruta.append({"direcao": "VERMELHO", "tipo_regra": "V2_CONTINUIDADE_VERMELHA", "origem": "Volume 2"})
        if sub_num[11] in [3, 4, 5] and sub_pol[10] == sub_pol[11]:
            direcao = "VERMELHO" if sub_pol[11] == "V" else "PRETO"
            lista_bruta.append({"direcao": direcao, "tipo_regra": "ASSUNCAO_CONTAGEM_FINAL", "origem": "Assunção"})
        
        if ia_modelo and hasattr(ia_modelo, 'verificar_quebrador_historico'):
            eh_quebrador, dir_quebra, motivo_quebra = ia_modelo.verificar_quebrador_historico(sub_num, sub_pol)
            if eh_quebrador:
                lista_bruta.append({"direcao": dir_quebra, "tipo_regra": "QUEBRADOR_HISTORICO_ATIVO", "origem": "IA_Quebradores"})
        
        return lista_bruta

class AnalisadorContextoAvancado:
    @staticmethod
    def mapear_padroes_geometria(sub_pol):
        texto = "".join(sub_pol)
        if texto.endswith("VPPV"): return "CICLO_FECHADO_VPPV"
        if texto.endswith("PVVP"): return "CICLO_FECHADO_PVVP"
        if "VVVV" in texto: return "SATURAÇÃO ESTRUTURAL (V)"
        if "PPPP" in texto: return "SATURAÇÃO ESTRUTURAL (P)"
        if "VPVP" in texto or "PVPV" in texto: return "XADREZ ATIVO"
        return "ESTÁVEL"

    @staticmethod
    def detectar_modo_mercado(sub_pol, eh_sinal_real=False, ia_modelo=None):
        if ia_modelo and getattr(ia_modelo, 'ml_ready', False) and HAS_ML and getattr(ia_modelo, 'ml_hmm', None):
            try:
                c_map = {'P': 0, 'V': 1, 'B': 2}
                seq = [[c_map.get(c, 2)] for c in sub_pol]
                estado_oculto = ia_modelo.ml_hmm.predict(seq)[-1]
                regimes = {0: "HMM_CONSOLIDACAO (Estável)", 1: "HMM_TENDENCIA (Surfe)", 2: "HMM_CAOS (Recolhimento)"}
                return regimes.get(estado_oculto, "NEUTRO")
            except: pass

        texto = "".join(sub_pol)
        alternancias = sum(1 for i in range(len(texto)-1) if texto[i] != texto[i+1])
        if eh_sinal_real:
            if alternancias >= 7: return "REGIME_RECOLHIMENTO"
            elif alternancias <= 3: return "REGIME_PAGADOR"
            return "NEUTRO"
        else:
            if alternancias >= 7: return "CHUVA"
            elif alternancias <= 3: return "RECUPERACAO"
            return "NEUTRO"
