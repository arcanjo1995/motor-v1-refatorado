# MOTOR V1 — Refatorado

Refatoração conservadora do `motor-v1-app`.

## Fase 1

Esta fase reorganiza o código por responsabilidade sem alterar deliberadamente regras operacionais, pesos, thresholds, NO CALL, juiz hierárquico, recência ou critérios G0/G1/G2.

O `baseline/main_original.py` é um snapshot imutável do `main.py` recebido do repositório original.

## Estrutura

```text
app.py
main.py                       # camada de compatibilidade
baseline/main_original.py     # snapshot do legado

dados/
  base.py
  leitor_xls.py
  persistencia.py
  recencia.py

ia/
  preditiva.py
  treinamento.py

matematica/
  engine.py

motor/
  analise.py
  juiz.py
  regras.py
  unificado.py

operacional/
  tipo_b.py
  tipo_d.py

tests/
  test_estrutura.py
  test_invariantes.py
```

## Compatibilidade

`main.py` continua exportando os nomes públicos usados pelo painel e por pickles legados. O `app.py` passa a importar os módulos responsáveis diretamente.

Os corpos das classes centrais migradas são comparados ao snapshot original por teste de regressão estrutural.

## Invariantes

- `0 = B`
- `1..7 = V`
- `8..14 = P`
- Tipo B exige exatamente 12 números.
- `idx += 12 + salto` permanece inalterado nesta fase.
- peso `6` da recência permanece inalterado nesta fase.
- persistência de ML permanece com o comportamento legado nesta fase.

## Execução

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Testes

```bash
pytest -q
```

`pytest` pode ser instalado apenas no ambiente de desenvolvimento. Ele não foi adicionado ao `requirements.txt` de produção para preservar as dependências originais nesta fase.
