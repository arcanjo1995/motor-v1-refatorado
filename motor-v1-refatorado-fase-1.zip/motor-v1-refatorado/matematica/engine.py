import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

from dados.leitor_xls import LeitorXLS

class EngineMatematicoAvancado:
    @staticmethod
    def calcular_entropia_shannon(sub_pol):
        if not sub_pol: return 0.0
        total = len(sub_pol)
        counts = {'V': sub_pol.count('V'), 'P': sub_pol.count('P'), 'B': sub_pol.count('B')}
        entropia = 0.0
        for cor, count in counts.items():
            if count > 0:
                p = count / total
                entropia -= p * math.log2(p)
        return round(entropia, 3)

    @staticmethod
    def calcular_kelly(probabilidade_vitoria_percent, house_edge_compensacao=False):
        if probabilidade_vitoria_percent < 50.0: return 0.0
        prob = probabilidade_vitoria_percent / 100.0
        q = 1.0 - prob
        b = 1.0 
        f_star = (prob * b - q) / b
        return round(max(0.0, f_star / 2.0) * 100.0, 2)

    @staticmethod
    def calcular_raridade_sequencia(sub_pol):
        if not sub_pol: return {"streak": 0, "probabilidade": 100.0, "status": "SEM DADOS"}
        ultima_cor = sub_pol[-1]
        if ultima_cor not in ['V', 'P']: return {"streak": 0, "probabilidade": 100.0, "status": "BRANCO NO FECHAMENTO"}
        streak = 0
        for cor in reversed(sub_pol):
            if cor == ultima_cor: streak += 1
            else: break
        probabilidade_sequencia = ((7 / 15) ** streak) * 100
        status = "SATURAÇÃO CRÍTICA" if streak >= 5 else ("DESVIO PADRÃO EM CURSO" if streak >= 3 else "ESTRUTURA DENTRO DA NORMALIDADE")
        return {"streak": streak, "cor_sequencia": "VERMELHO" if ultima_cor == 'V' else "PRETO", "probabilidade": round(probabilidade_sequencia, 2), "status": status}

    @staticmethod
    def calcular_vies_surfe(caminho_base, janela=100):
        leitor = LeitorXLS(caminho_base)
        dados = leitor.ler_e_validar()
        if not dados: return {"vies": "INDISPONÍVEL", "desvio_v": 0.0, "desvio_p": 0.0, "frequencia_v": 46.67, "frequencia_p": 46.67, "frequencia_b": 6.67}
        ultimos = dados[-janela:]
        v = sum(1 for d in ultimos if d['cor'] == 'V')
        p = sum(1 for d in ultimos if d['cor'] == 'P')
        b = sum(1 for d in ultimos if d['cor'] == 'B')
        pct_v = (v / len(ultimos)) * 100
        pct_p = (p / len(ultimos)) * 100
        pct_b = (b / len(ultimos)) * 100
        desvio_v = round(pct_v - 46.67, 2)
        desvio_p = round(pct_p - 46.67, 2)
        vies = "SURFE DE MACROFREQUÊNCIA: VIÁS PARA VERMELHO ATIVO" if pct_v >= 53.0 else ("SURFE DE MACROFREQUÊNCIA: VIÁS PARA PRETO ATIVO" if pct_p >= 53.0 else "MACROANÁLISE EQUILIBRADA")
        return {"frequencia_v": round(pct_v, 2), "frequencia_p": round(pct_p, 2), "frequencia_b": round(pct_b, 2), "desvio_v": desvio_v, "desvio_p": desvio_p, "vies": vies}

    @staticmethod
    def simular_split_stake_cobertura(stake_principal=10.0):
        stake_branco_ideal = round(stake_principal / 7.0, 2)
        stake_branco_conservador = round(stake_principal / 10.0, 2)
        custo_total = stake_principal + stake_branco_ideal
        lucro_liquido = round((stake_branco_ideal * 14) - custo_total, 2)
        return {"stake_cor": stake_principal, "cobertura_b_ideal_1_7": stake_branco_ideal, "cobertura_b_matematica_1_10": stake_branco_conservador, "lucro_liquido_se_der_branco": lucro_liquido, "custo_total_operacao": round(custo_total, 2), "house_edge_estatico": "-6.67%"}
