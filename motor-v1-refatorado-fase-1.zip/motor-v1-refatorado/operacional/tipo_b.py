import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

from dados.persistencia import carregar_modelo_longo_prazo
from dados.leitor_xls import LeitorXLS
from ia.preditiva import IAPreditivaV1
from motor.analise import MotorAnalise
from motor.juiz import JuizHierarquicoModificado

class ProcessadorTipoB:
    def __init__(self, sequencia_12_numeros, caminho_base_dados):
        self.entrada = sequencia_12_numeros
        self.caminho_base = caminho_base_dados
        self.polaridades = ['B' if n == 0 else ('V' if 1 <= n <= 7 else 'P') for n in sequencia_12_numeros]

    def executar_sinal_real(self):
        if len(self.entrada) != 12: return {"erro": "Necessário exatamente 12 números"}
        ia = carregar_modelo_longo_prazo()
        if ia is None:
            base = LeitorXLS(self.caminho_base).ler_e_validar()
            if not base: return {"erro": "Base de dados não encontrada"}
            ia = IAPreditivaV1(base, None)
        regime_rec = None
        if os.path.exists("base_recencia_ativa.xlsx"):
            base_rec = LeitorXLS("base_recencia_ativa.xlsx").ler_e_validar()
            if base_rec:
                ia = integrating_recencia_no_modelo(base_rec, 5)
                regime_rec = ia.regime_recencia
                
        analise = MotorAnalise.analisar_janela(self.entrada, self.polaridades, ia, eh_sinal_real=True)
        
        nc_ativo = analise["no_call"]["ativo"]
        motivo_nc = analise["no_call"]["motivo"]
        geometria = analise["geometria"]
        expectativas = analise["regras_posicionais"]
        direcao_ia = analise["ia"]["direcao"] if not nc_ativo else "NEUTRO"
        conf_ia = analise["ia"]["confianca"] if not nc_ativo else 0.0
        raciocinio_ia = analise["ia"]["raciocinio"] if not nc_ativo else motivo_nc
        streak = analise["contexto_reversao"]["streak"]
        xadrez_len = analise["contexto_reversao"]["xadrez_len"]
        xadrez_quebrou = analise["contexto_reversao"]["xadrez_quebrou"]
        contexto_exaustao = analise["contexto_reversao"]["exaustao"]
        modo_mercado = analise["contexto_avancado"].get("modo_mercado", "NEUTRO")
        raciocinio_trace = analise["camadas"]
        
        if nc_ativo:
            return {
                "sinal": "NO CALL", "justificativa": motivo_nc, "no_call": True, "regime_recencia": regime_rec,
                "motivo_real": f"NO CALL: {motivo_nc}", "regra_id": "SISTEMA_TRAVADO",
                "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")
            }
            
        sinal_final, justificativa_final, regra_id_final = JuizHierarquicoModificado.arbitrar_sinal(
            no_call_ativo=False, motivo_nc="", expectations=expectativas, inclinacao_num=None, geometria_mercado=geometria,
            previsao_ia=(direcao_ia, conf_ia, raciocinio_ia), status_inversao=None, historico_regras=ia.historico_regras if ia else {},
            modo_mercado=modo_mercado, streak_atual=streak, xadrez_len=xadrez_len, xadrez_quebrou=xadrez_quebrou,
            contexto_exaustao=contexto_exaustao, probabilidade_markov=analise.get("probabilidade_markov"),
            ia_modelo=ia, entropia_shannon=analise.get("entropia", 0.0)
        )

        if sinal_final != "NO CALL" and streak >= 6:
            sinal_final = "NO CALL"
            justificativa_final = f"Veto de streak {streak}x (segurança anti-tendência)"
            regra_id_final = "VETO_STREAK"
            
        return {
            "sinal": sinal_final, "justificativa": justificativa_final, "confianca_ia": round(conf_ia, 2),
            "no_call": False, "regime_recencia": regime_rec, "motivo_real": justificativa_final,
            "raciocinio_trace": raciocinio_trace, "decisao_final": {"sinal": sinal_final, "justificativa": justificativa_final, "regra_id": regra_id_final},
            "entropia": analise.get("entropia"), "probabilidade_markov": analise.get("probabilidade_markov")
        }
