from motor.unificado import MotorV1Completo

__all__ = ["MotorV1Completo"]
