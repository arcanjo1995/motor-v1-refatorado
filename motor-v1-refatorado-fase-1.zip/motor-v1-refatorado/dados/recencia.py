import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

from dados.persistencia import carregar_modelo_longo_prazo, salvar_modelo_longo_prazo

def analisar_regime_recencia(dados_recencia):
    if not dados_recencia or len(dados_recencia) < 20:
        return {
            "viés_atual": "INDEFINIDO",
            "modo_dominante": "NEUTRO",
            "xadrez_frequencia": 0.0,
            "streak_medio": 0,
            "confianca_regime": 0
        }
    
    janela_termometro = min(len(dados_recencia), 100)
    recorte_termometro = dados_recencia[-janela_termometro:]
    
    cores = [d['cor'] for d in recorte_termometro]
    total = len(cores)
    
    if total == 0:
        return {
            "viés_atual": "INDEFINIDO",
            "modo_dominante": "NEUTRO",
            "xadrez_frequencia": 0.0,
            "streak_medio": 0,
            "confianca_regime": 0
        }
        
    v = cores.count('V')
    p = cores.count('P')
    pct_v = (v / total) * 100
    pct_p = (p / total) * 100
    
    if pct_v >= 52.5:
        viés = "VERMELHO"
    elif pct_p >= 52.5:
        viés = "PRETO"
    else:
        viés = "EQUILIBRADO"
        
    alternancias = sum(1 for i in range(1, total) if cores[i] != cores[i-1] and cores[i] != 'B' and cores[i-1] != 'B')
    xadrez_freq = (alternancias / (total - 1)) * 100 if total > 1 else 0
    
    streaks = []
    atual = 1
    for i in range(1, total):
        if cores[i] == cores[i-1] and cores[i] != 'B':
            atual += 1
        else:
            if atual >= 2:
                streaks.append(atual)
            atual = 1
            
    streak_medio = sum(streaks) / len(streaks) if streaks else 0
    
    if xadrez_freq >= 55.0:
        modo = "XADREZ_DOMINANTE"
    elif streak_medio >= 3.0:
        modo = "STREAK_DOMINANTE"
    else:
        modo = "MISTO"
        
    confianca = min(85, int(abs(pct_v - 50) + abs(pct_p - 50)))
    
    return {
        "viés_atual": viés,
        "modo_dominante": modo,
        "xadrez_frequencia": round(xadrez_freq, 1),
        "streak_medio": round(streak_medio, 1),
        "confianca_regime": confianca,
        "pct_vermelho_recencia": round(pct_v, 1),
        "pct_preto_recencia": round(pct_p, 1)
    }

def integrar_recencia_no_modelo(dados_recencia, multiplicador=5):
    ia = carregar_modelo_longo_prazo()
    if ia is None:
        ia = IAPreditivaV1([], dados_recencia)
    else:
        ia.injetar_aprendizado_imediato(dados_recencia, multiplicador_peso=multiplicador)
    ia.analise_recencia = ia.analisar_comportamento_pos_numero_recencia(dados_recencia)
    ia.regime_recencia = analisar_regime_recencia(dados_recencia)
    salvar_modelo_longo_prazo(ia)
    return ia
