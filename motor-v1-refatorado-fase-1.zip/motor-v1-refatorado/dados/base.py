import os
import pandas as pd
from collections import defaultdict
import pickle
import json
from datetime import datetime
import time
import tempfile
import math
import random

NOME_BASE_DEFINITIVA = "resultados_blaze.xlsx"
from dados.leitor_xls import LeitorXLS

def adicionar_a_base_longo_prazo(novos_dados):
    if not novos_dados:
        return {"sucesso": False, "mensagem": "Nenhum dado novo foi fornecido."}
    base_existente = []
    if os.path.exists(NOME_BASE_DEFINITIVA):
        try:
            base_existente = LeitorXLS(NOME_BASE_DEFINITIVA).ler_e_validar() or []
        except:
            return {"sucesso": False, "mensagem": "Não foi possível ler a base antiga."}
    dados_combinados = base_existente + novos_dados
    if os.path.exists(NOME_BASE_DEFINITIVA):
        try:
            backup_name = NOME_BASE_DEFINITIVA.replace(".xlsx", f"_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            os.rename(NOME_BASE_DEFINITIVA, backup_name)
        except:
            pass
    try:
        df = pd.DataFrame([{"numero": d["numero"], "cor": d["cor"]} for d in dados_combinados])
        df.to_excel(NOME_BASE_DEFINITIVA, index=False)
    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro ao salvar o arquivo: {e}"}
    return treinar_base_longo_prazo_com_janelas(dados_combinados)
