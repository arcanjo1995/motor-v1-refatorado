from dados.leitor_xls import LeitorXLS
from motor.regras import MotorNoCall

def _cor(numero):
    if numero == 0:
        return "B"
    if 1 <= numero <= 7:
        return "V"
    return "P"

def test_mapeamento_imutavel_de_cores():
    assert _cor(0) == "B"
    assert all(_cor(n) == "V" for n in range(1, 8))
    assert all(_cor(n) == "P" for n in range(8, 15))

def test_leitor_xls_preserva_cronologia_e_mapeamento(tmp_path):
    import pandas as pd
    caminho = tmp_path / "base.xlsx"
    pd.DataFrame({"Número": [14, 8, 7, 1, 0]}).to_excel(caminho, index=False)
    dados = LeitorXLS(str(caminho)).ler_e_validar()
    assert [d["numero"] for d in dados] == [0, 1, 7, 8, 14]
    assert [d["cor"] for d in dados] == ["B", "V", "V", "P", "P"]
