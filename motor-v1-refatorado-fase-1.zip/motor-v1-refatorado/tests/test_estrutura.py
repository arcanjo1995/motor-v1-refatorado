import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def _definitions(path):
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    return {
        node.name: ast.get_source_segment(source, node)
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef))
    }

def test_corpos_migrados_permanecem_identicos_ao_baseline():
    baseline = _definitions(ROOT / "baseline" / "main_original.py")
    manifest = json.loads((ROOT / "tests" / "definition_hashes.json").read_text(encoding="utf-8"))
    for relative_path, expected in manifest.items():
        migrated = _definitions(ROOT / relative_path)
        for name, expected_hash in expected.items():
            assert name in migrated
            assert name in baseline
            assert hashlib.sha256(migrated[name].encode()).hexdigest() == expected_hash
            assert migrated[name] == baseline[name]

def test_main_de_compatibilidade_importa():
    import main
    assert main.NOME_BASE_DEFINITIVA == "resultados_blaze.xlsx"
    assert main.motor_unificado is not None
