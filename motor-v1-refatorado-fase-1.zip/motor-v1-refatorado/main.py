"""Compatibilidade do MOTOR V1 após a refatoração estrutural da Fase 1."""

from dados.leitor_xls import LeitorXLS, NOME_BASE_DEFINITIVA
from dados.persistencia import (
    fabrica_padrao_detalhado, fabrica_historico_regras_zerado,
    fabrica_historico_regras_auditado, salvar_log_json,
    salvar_modelo_longo_prazo, carregar_modelo_longo_prazo,
)
from dados.recencia import analisar_regime_recencia, integrar_recencia_no_modelo
from dados.base import adicionar_a_base_longo_prazo
from ia.treinamento import reforcar_aprendizado_tipo_d, treinar_base_longo_prazo_com_janelas
from ia.preditiva import IAPreditivaV1
from motor.regras import MotorNoCall, MotorContagensProjetivas, AnalisadorContextoAvancado
from motor.juiz import JuizHierarquicoModificado
from motor.analise import MotorAnalise
from motor.unificado import SequenciaOperacional, MotorV1Completo, MotorUnificadoV1, motor_unificado
from operacional.tipo_b import ProcessadorTipoB
from matematica.engine import EngineMatematicoAvancado

__all__ = [name for name in globals() if not name.startswith("_")]
